"""Read-only collection of the Stiprā issue backlog for independent audit."""
import json, subprocess, time
from pathlib import Path

OUT = Path(r"C:\Users\yigit\Documents\repos\stipra-backlog-audit-d033ce7\audit-data")
OUT.mkdir(parents=True, exist_ok=True)
REPO = "yigit-denktas/stipra"


def gh(*args):
    return subprocess.run(["gh", *args], capture_output=True, text=True, encoding='utf-8', errors='replace', check=True).stdout


def get_all(path):
    # --slurp yields one JSON array across paginated pages (gh >= 2.40).
    raw = gh("api", "--paginate", "--slurp", f"repos/{REPO}/{path}")
    data = json.loads(raw)
    if isinstance(data, list) and data and isinstance(data[0], list):
        return [item for page in data for item in page]
    return data


started = time.strftime("%Y-%m-%dT%H:%M:%S%z")
raw_issues = get_all("issues?state=all&per_page=100")
issues = [i for i in raw_issues if "pull_request" not in i]
prs = []
for page in range(1, 20):
    data = json.loads(gh("api", f"repos/{REPO}/pulls?state=all&per_page=100&page={page}"))
    prs.extend(data)
    if len(data) < 100:
        break
milestones = json.loads(gh("api", f"repos/{REPO}/milestones?state=all&per_page=100"))
labels = json.loads(gh("api", f"repos/{REPO}/labels?per_page=100"))
for issue in issues:
    for page in range(1, 10):
        data = json.loads(gh("api", f"repos/{REPO}/issues/{issue['number']}/comments?per_page=100&page={page}"))
        issue.setdefault("_comments", []).extend(data)
        if len(data) < 100:
            break
finished = time.strftime("%Y-%m-%dT%H:%M:%S%z")
payload = {
    "repo": REPO,
    "retrievalStarted": started,
    "retrievalFinished": finished,
    "api": "GitHub REST via authenticated gh CLI; --paginate --slurp",
    "issues": issues,
    "pulls": prs,
    "milestones": milestones,
    "labels": labels,
}
(OUT / "backlog-raw.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

lines = ["# Stiprā genuine issue backlog — full retrieval", "",
         f"Repository: {REPO}", f"Retrieved: {started} to {finished}", "",
         f"Genuine issues: {len(issues)}; open: {sum(i['state']=='open' for i in issues)}; "
         f"closed: {sum(i['state']=='closed' for i in issues)}; comments: {sum(len(i['_comments']) for i in issues)}", "",
         f"Merged PRs in repository API: {sum(p.get('merged_at') is not None for p in prs)}; all PRs: {len(prs)}", "",
         f"Milestones: {[(m['title'], m['state'], m['open_issues'], m['closed_issues']) for m in milestones]}", ""]
for issue in sorted(issues, key=lambda i: i["number"]):
    lines += ["", f"## #{issue['number']} — {issue['title']}", "",
              f"- state: {issue['state']} / {issue.get('state_reason')}",
              f"- author: {issue['user']['login']}; labels: {[l['name'] for l in issue['labels']]}; "
              f"milestone: {(issue.get('milestone') or {}).get('title')}; assignees: {[a['login'] for a in issue.get('assignees') or []]}",
              f"- createdAt: {issue['created_at']}; closedAt: {issue.get('closed_at')}; comments: {len(issue['_comments'])}",
              f"- url: {issue['html_url']}", "", "### Body", "", issue.get("body") or "(empty)", ""]
    for comment in issue["_comments"]:
        lines += [f"### Comment by {comment['user']['login']} at {comment['created_at']} ({comment['html_url']})", "",
                  comment.get("body") or "(empty)", ""]
(OUT / "issues-full.md").write_text("\n".join(lines), encoding="utf-8")

summary = {"retrievalFinished": finished, "issues": len(issues), "open": sum(i["state"] == "open" for i in issues),
           "closed": sum(i["state"] == "closed" for i in issues),
           "comments": sum(len(i["_comments"]) for i in issues), "pulls": len(prs),
           "mergedPulls": sum(p.get("merged_at") is not None for p in prs)}
(OUT / "coverage.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
print(json.dumps(summary, indent=2))
print("numbers:", [i["number"] for i in sorted(issues, key=lambda x: x["number"])])
