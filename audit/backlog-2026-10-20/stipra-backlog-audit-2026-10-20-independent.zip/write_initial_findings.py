"""Write the independent first-pass backlog findings before reading the cloud audit.

Read-only audit snapshot; dispositions are proposals, not applied changes.
"""
import json
from pathlib import Path

A = Path(r"C:\Users\yigit\Documents\repos\stipra-backlog-audit-d033ce7")
D = A / "audit-data"
raw = json.loads((D / "backlog-raw.json").read_text(encoding="utf-8"))
issues = {i["number"]: i for i in raw["issues"]}
ledger = json.loads((A / "docs/data/delivery-ledger.json").read_text(encoding="utf-8"))
tasks = {t["issue"]: t for t in ledger["tasks"]}
assert set(issues) == set(tasks)

S = {}  # number: dict(disposition, remaining, evidence, confidence, note)
def add(n, disposition, remaining, evidence, confidence, note=""):
    S[n] = dict(disposition=disposition, remaining=remaining, evidence=evidence, confidence=confidence, note=note)

# closed implementation records
for n in [1, 2, 5, 6, 7, 11, 17, 18, 21, 22, 24, 29, 32, 35, 37, 44, 45, 52, 54, 56, 60, 62, 65, 71, 72, 73, 74, 81, 82, 83, 84, 85, 86, 90]:
    add(n, "keep closed; implementation/research record complete", "none shown in scope",
        f"ledger delivery={tasks[n].get('deliveryState')}; issue closure record; supporting docs/tests present", "high")
# special closed rows
add(39, "keep closed; it deliberately closed on the acceptance specification", "owner-photo package execution remains under #13/new acceptance child",
    "body states closes on specification not engine or three-photo pass; fixture/acceptance docs present", "high")
add(8, "keep closed implementation; open one owner-photo G01-G06 acceptance child under #13; annotate closure scope", "owner-photo G01-G06 package verification; visual/physical quality belongs #13",
    "PR #93 delivered software; docs/PRINT-PACKAGE-ACCEPTANCE.md says NOT YET RUN / 0 of 3; tests/fixtures/owner-photo-fixtures.json status=SPECIFICATION_ONLY_NOT_EVALUATED; #8 comment said keep open until real fixtures verify", "medium-high",
    "needs owner/cloud agreement; do not silently treat closed as acceptance")
add(9, "keep closed implementation; route owner-photo G07-G08 to the same #13 acceptance child; annotate closure scope", "owner-photo G07-G08 verification and intended-size human review; physical remains #13",
    "#9 reconciliation records report-generation acceptance; acceptance doc still NOT RUN/0 of 3; private owner report review recorded in #63 but no G07-G08 matrix", "medium",
    "needs owner/cloud agreement; implementation is real")
add(12, "keep closed implementation; route owner-photo G09-G11 to the same #13 acceptance child; annotate closure scope", "owner-photo G09-G11 package/replay verification; physical remains #13",
    "#93 closes format/ZIP implementation; acceptance doc still NOT RUN/0 of 3; #12 comment said keep open for owner-photo canonical QA", "medium-high",
    "needs owner/cloud agreement")
# open issues
add(3, "keep open as parked optional case-study polish; no release blocker", "facet seam/contour/gem criteria unchanged", "issue scope decision 2026-10-16; ledger planned/optional", "high")
add(4, "keep open as parked optional style extension; no release blocker", "paper fiber/debris realism criteria unchanged", "scope decision says optional, nonblocking; ledger planned/optional", "high")
add(10, "keep open narrowed to optional advanced reference diagnostics; basic diagnostics already #56", "HSL/CIELAB reference segmentation, overlays, IoU/anchor metrics; optional", "scope decision nonblocking; #56 delivered shared diagnostics; ledger planned", "high")
add(13, "keep open as acceptance parent; split children for owner-photo G01-G11, Windows portability, human accessibility and physical operator record", "actual human accessibility; physical-print observations; owner-photo acceptance; Windows portability",
    "docs/PHYSICAL-PRINT-CHECK.md status not performed; docs/ARTIST-TRIAL.md no submitted trial; issue comments record deferred human/physical; acceptance matrix not run", "high")
add(14, "keep open for the single native Skia compiled-component notice inventory", "attributable native notices/review; native bundle release gate", "upstream samizdatco/skia-canvas#309 open with 0 comments (retrieved read-only); docs/DEPENDENCY-AUDIT.md; ledger partial", "high")
add(28, "keep open as planned optional vector extension", "true analytic vector facet/screen geometry and parity criteria; no raster-vector claim", "ledger planned/optional; no analytic vector implementation found in src; #5 scope explicitly excludes it", "high")
add(31, "keep open for remaining owner-directed workspace/identity design; split identity decisions to #57", "workspace hierarchy/visual direction, mobile/accessibility interaction review; owner sign-off", "ledger review; many bounded studio follow-ups merged (#111/#115) but broader design undecided", "high")
add(34, "propose close as superseded by #47 + #13 after owner confirmation; account for future-family ideas in #47 or a new research note", "family-wide aesthetic/physical suitability; faux-CMYK/photocopy later ideas not promised",
    "stock contract and four families shipped through #47; ledger keeps #34 partial and #47 is acceptance owner; owner approved only digital forest/beach specimens", "medium",
    "needs owner decision; do not close a design proposal unilaterally")
add(43, "propose close after owner confirmation: digital forest/beach recipe approval is recorded; physical/independent evidence transfers to #13/#70", "physical/operator and independent artist evidence; broader family suitability stays #47",
    "docs/OWNER-VISUAL-APPROVAL-2026-10-19.md approves supplied digital forest-balanced/coast-tonal specimens; physical/artist explicitly deferred", "medium",
    "needs owner decision; closure is not a physical pass")
add(46, "propose close as superseded by #57 wordmark identity study; preserve parked #46 artifacts as historical, no adoption", "final owner identity choice and small-size/physical review remain #57",
    "ledger review; #46 branch parked; current identity focus documented in #57/BRAND-IDENTITY-STUDY-v2; owner has not selected", "medium",
    "needs owner decision")
add(47, "keep open for family-wide style suitability and any remaining owner/artist review; do not claim all families artistically proven", "four-family quality/suitability; physical/independent artist evidence #13/#70", "issue comments; ledger review; owner approval is scoped to digital forest/beach specimens", "high")
add(57, "keep open; owner must select final identity / small-print judgment", "owner visual choice, small-size/physical review, adoption decision; README logo remains unchanged", "ledger review; BRAND-IDENTITY-STUDY-v2; issue comments", "high")
add(70, "keep open for independent artist usefulness; publication and software acceptance are already complete", "at least one genuine independent artist trial/record; human/physical separate #13", "alpha.1 published and registry-verified; docs/ARTIST-TRIAL.md status prepared-not-performed; issue comments", "high")
add(75, "keep open as deferred optional Processing Java feasibility", "feasibility note and handoff only if prioritized; no Java rewrite", "ledger planned/optional; no implementation found", "high")
add(109, "keep open; Study 01 is bounded evidence, not adapter/human acceptance; no rerun or Experiment 2", "independent usefulness/adoption; Windows portability; human/physical acceptance; Experiment 2 decision separate", "PR #119 merged at d033ce7; docs/RECONSTRUCTION-STUDY-01.md; issue comments; owner instruction", "high")
add(113, "keep open as proposed optional operator proof kit; scope with #8/#9 contracts", "annotations/registrations/test sheets criteria; physical acceptance #13; no implementation yet", "body proposal; ledger planned; no implementation found", "high")
add(114, "keep open as deferred process research; no implementation/version promised", "process taxonomy, shortlist spikes, adopt/defer/reject; physical workshop evidence if later", "body proposal; ledger planned; no implementation found", "high")

conf = {}
for n, s in S.items():
    conf[n] = s

def status(n):
    i = issues[n]
    return f"#{n} {'OPEN' if i['state'] == 'open' else 'CLOSED'}"

lines = []
lines += ["# Independent Stiprā backlog audit — first-pass findings", "",
          "**Recorded before reading any cloud-agent recommendation file.** Read-only audit; no issue/PR mutation.", "",
          "## Coverage manifest", "",
          f"- Repository: {raw['repo']}",
          f"- Exact inspected main SHA: `d033ce7c923507c607786ca141fb532500964c60` (merge of PR #119, parents `4312d7a`; fetched from origin `main`)",
          "- Inspection worktree: `C:\\Users\\yigit\\Documents\\repos\\stipra-backlog-audit-d033ce7` (detached at main; source inspection only)",
          f"- Retrieval: {raw['retrievalStarted']} → {raw['retrievalFinished']}, GitHub REST API via authenticated `gh api --paginate --slurp`",
          f"- Genuine issues read: **{len(issues)}** (open **{sum(i['state']=='open' for i in issues.values())}**, closed **{sum(i['state']=='closed' for i in issues.values())}**); comments read: **{sum(len(i['_comments']) for i in issues.values())}**",
          f"- PRs: {len(raw['pulls'])} total, all merged; open PR count: 0 (GitHub), PR #119 merged at d033ce7 on 2026-10-19T22:03:02Z",
          "- Environment: Windows NT 10.0.26300.0 (Windows 11 host), Node v22.15.0, npm 11.7.0, git 2.49.0.windows.1, gh 2.89.0, Python 3.12.14",
          "- Issue state reasons: all closed rows reported `state_reason=completed`; no duplicate/not-planned closures observed in this snapshot.",
          f"- Milestone: `v0.9` exists (milestone #1), description v0.9 acceptance; **API counters report 0 open/0 closed while 14 issues reference it (5 open, 9 closed) — record as GitHub/API inconsistency, not inferred progress**.",
          "- Private GitHub Project #3 and its views are owner-only; not accessible from this audit. Do not invent Project IDs/Status values. Issue bodies that say 'pending #17' are planning text, not verified Project links.",
          "- Not inspectable here: owner photographs (private; must stay private), private PDF/report/ZIP review bundles, physical prints, independent artist/accessibility observations, maintainer response to upstream skia-canvas #309.",
          "- Upstream read-only check: samizdatco/skia-canvas#309 is OPEN with 0 comments as of retrieval (created 2026-10-19T08:10:59Z); no maintainer response/clearance observed.",
          "- Registry/release read-only checks: `v0.9.0-rc.1` experimental prerelease exists; npm `@yigit-denktas/stipra-core@0.1.0-alpha.1` resolves with the documented integrity. No new publication/merge performed.",
          "- Code/tests/docs inspected: root `README.md`, `ROADMAP.md`, `AGENTS.md`, `docs/data/delivery-ledger.json`, `docs/data/changelog.json`, `docs/data/product-history.json`, `docs/PRINT-PACKAGE-ACCEPTANCE.md`, `docs/PHYSICAL-PRINT-CHECK.md`, `docs/ARTIST-TRIAL.md`, `docs/RELEASE-CANDIDATE.md`, `docs/OWNER-VISUAL-APPROVAL-2026-10-19.md`, `docs/ACCEPTANCE-2026-10-19.md`, `docs/PROJECT-TRACKING.md`, `tests/fixtures/owner-photo-fixtures.json`, `tests/owner-print-acceptance.test.js`, `scripts/owner-photo-batch.js`, `src/` inventory, package/test inventory.",
          "- Not executed in this audit: Windows test suite, Python metric tests, rendering/browser/CI reruns, private owner-fixture runs, physical printing, human trials. Claims below rely on repository records and public API state; unexecuted items are marked NOT RUN, not passed.", ""]
lines += ["## Disposition vocabulary", "",
          "`keep closed` = delivered implementation/research record remains closed; `keep open` = genuine remaining criteria; `close-after-owner` = proposal needing owner/cloud confirmation; `new child` = new issue under an existing acceptance parent; `needs-owner` = product/acceptance decision. No changes applied.", ""]
lines += ["## Per-issue rows", "",
          "| Issue | State | Scope / implementation evidence | Remaining criteria | Proposed disposition | Dependencies | Confidence |",
          "|---|---|---|---|---|---|---|"]
for n in sorted(issues):
    s = S[n]
    i = issues[n]
    scope = (i["title"] + " — " + tasks[n].get("note", ""))[:220].replace("|", "/")
    rem = s["remaining"].replace("|", "/")
    disp = s["disposition"] + (" — " + s["note"] if s["note"] else "")
    deps = ", ".join("#" + str(d) for d in tasks[n].get("dependsOn", [])) or "—"
    lines.append(f"| {status(n)} | {'open' if i['state']=='open' else 'closed'} | {scope} | {rem} | {disp} | {deps} | {s['confidence']} |")
lines += ["", "## First-pass observations and proposed split", "",
          "1. **Owner-photo acceptance is the main closure/documentation gap.** `#8` is closed but `docs/PRINT-PACKAGE-ACCEPTANCE.md` still says `NOT YET RUN`, every G/A/B/C box is unchecked, and `tests/fixtures/owner-photo-fixtures.json` says `SPECIFICATION_ONLY_NOT_EVALUATED` (0 of 3 packages). `#9` and `#12` are similarly closed on implementation while their G07-G08/G09-G11 owner-photo criteria are not formally evaluated. Do not treat implementation closure as acceptance; keep the three closed implementation records but create one explicit #13 child for G01-G11 owner-photo verification (private evidence, no public photos), or reopen #8/#9/#12 if the owner prefers. This is a needs-owner/cloud decision.",
          "2. **#13 is an acceptance parent and should remain open.** It currently mixes software QA, human accessibility, physical print, and now Windows portability. Split without closing the parent: (a) owner-photo package acceptance G01-G11; (b) human accessibility observations; (c) physical operator record; (d) Windows portability reproduction/fixes. #70 remains the independent artist usefulness track; do not merge those two human gates.",
          "3. **Windows portability is inadequately tracked.** The 14 Windows failures reported at 3deeab8 mix code-portable issues (npm subprocess resolution, non-study vendor CRLF hashes, README newline counting) with host-sensitive TEMP ACL/symlink failures. The latter are not proven application defects. Create a dedicated Windows reproduction issue with per-test triage, not a blanket 'Windows broken' claim and not a Linux-CI pass inference.",
          "4. **#34/#43/#46 are good owner-decision closure candidates, not silent closures.** Digital forest/beach approval is recorded (scoped), #47 remains the family acceptance owner, and #57 is the identity decision owner. Close only after owner confirmation; transfer physical/independent-artist evidence to #13/#70.",
          "5. **#3/#4/#10/#28/#75 are genuinely optional/parked; keep them open or owner-close as not-planned.** They are explicitly nonblocking and do not justify reopening delivered work. #113/#114 are proposed research with no implementation; keep open/deferred or owner-close separately.",
          "6. **#14 stays open for native notices.** Browser/lean inventories are scoped; the upstream request is posted and unanswered. Do not describe it as refusal, permission denial, or clearance.",
          "7. **#109 stays open by explicit owner instruction.** Study 01 v2 is bounded digital evidence; original evidence is preserved; no rerun/Experiment 2; Windows/human/physical remain open. The small requirements-test follow-up is separate from #119 artifact identities.",
          "8. **Documentation/ledger reconciliation needed, not evidence rewriting:** acceptance records currently contradict closed implementation issues (#8/#9/#12); README/ROADMAP/ledger/changelog should label implementation closure vs acceptance clearly; fix only after ownership agreement. Do not rewrite delivered evidence or archives.",
          "", "## Proposed work allocation (not started; needs both agents' agreement)", "",
          "| Owner | Scope | Branch / file claim | Gate |",
          "|---|---|---|---|",
          "| Local agent (this host) | Reproduce the 14 Windows failures on an isolated Windows worktree; triage code-portable vs host-sensitive; bounded fixes + tests; optional requirements-test/archive .txt follow-up after ownership | `fix/windows-portability-<issue>` touching `src/import/*`, `scripts/*`, `.gitattributes`, `package.json` test wiring, `examples/reconstruction-study/requirements-test.txt`, `package.py`; no docs/issue edits | owner approves scope; no merge; no production-default change |",
          "| Cloud agent (Linux) | Independent patch review + Linux checks; one coordinated issue/ledger/README/roadmap/changelog reconciliation after agreement | docs/metadata surfaces (`docs/data/*`, `README.md`, `ROADMAP.md`, issue text proposals), no concurrent edit of local code branch | agreement + owner approval; no closure/merge during audit |",
          "| Owner / human reviewers | Private owner-photo G01-G11 execution, physical operator record, independent artist trial, final identity/style decisions, issue relabel/closure | private evidence only; no public photo uploads; **no agent may fabricate records** | actual observations only |",
          "", "## Confidence notes", "",
          "- High confidence: state/scope facts from issues, comments, ledger, docs, tests, releases, npm/upstream read-only checks.",
          "- Medium confidence: whether closing #8/#9/#12 is acceptable as implementation-only, and whether #34/#43/#46 should be owner-closed now.",
          "- Low/unknown: private owner-photo results, physical prints, independent artist/accessibility observations, Project #3 fields/statuses, milestone counters, and the cloud agent's recommendations (intentionally not yet read).", ""]

(D / "initial-findings.md").write_text("\n".join(lines), encoding="utf-8")
print("wrote", D / "initial-findings.md", "rows", len(S))
(D / "dispositions.json").write_text(json.dumps(S, indent=2), encoding="utf-8")
