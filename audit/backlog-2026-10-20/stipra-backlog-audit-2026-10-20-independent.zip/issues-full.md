# Stiprā genuine issue backlog — full retrieval

Repository: yigit-denktas/stipra
Retrieved: 2026-10-20T00:29:43+0200 to 2026-10-20T00:30:13+0200

Genuine issues: 55; open: 17; closed: 38; comments: 123

Merged PRs in repository API: 64; all PRs: 64

Milestones: [('v0.9', 'open', 0, 0)]


## #1 — [Foundation] Adopt Prehnite v8 as Stipra's executable case study

- state: closed / completed
- author: yigit-denktas; labels: ['enhancement']; milestone: v0.9; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T20:14:58Z; closedAt: 2026-10-16T20:18:34Z; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/1

### Body

**Type:** Chore · **Priority:** P0 · **Target:** v0.9 foundation · **Area:** Core / repository
**Proposed branch:** `feat/stipra-foundation-v9` · **Project:** Stipra (attach when created) · **Milestone:** v0.9 (attach when available)

## Why
Preserve the functioning six-palette procedural renderer and CLI while establishing Stipra's general-purpose product brief, source provenance, and license constraints.

## Acceptance criteria
- [ ] Source-only v8 engine and browser studio committed under `examples/prehnite-v8/` (no reference photos embedded)
- [ ] Original `logo_for_Readme.svg` is preserved and displayed in the README
- [ ] Banner matches dark-background Stipra identity in the supplied visual reference
- [ ] MIT source licensing and Inter OFL notices committed
- [ ] Node CLI entry point, deterministic tests, and PR CI workflow included
- [ ] PR links back to this issue; merge only after checks pass

**Follow-up:** Generic separation and report features must not hard-code the Prehnite geometry. See `docs/BRIEF-v9.md`.
## Native delivery tracking

Milestone: [v0.9](https://github.com/yigit-denktas/stipra/milestone/1) · Project: [Stipra](https://github.com/users/yigit-denktas/projects/3) (existing private project; access unchanged). Release scope and dependencies: [ROADMAP.md](https://github.com/yigit-denktas/stipra/blob/main/ROADMAP.md).



## #2 — [Engine] Define generic scene, plate and deterministic recipe schema

- state: closed / completed
- author: yigit-denktas; labels: ['enhancement']; milestone: v0.9; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T20:16:13Z; closedAt: 2026-10-16T20:35:35Z; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/2

### Body

**Type:** Feature  
**Priority:** P0  
**Area:** Core  
**Target:** v0.9  
**Assignee:** @yigit-denktas  
**Project:** [Stipra](https://github.com/users/yigit-denktas/projects/3) (private) · **Milestone:** [v0.9](https://github.com/yigit-denktas/stipra/milestone/1)  
**Development branch (planned):** `feat/2-scene-contract`  
**Dependencies:** #1

## Scope
Define generic scene, plate and deterministic recipe schema.

## Acceptance criteria
- [ ] Create versioned recipe schema: canvas/trim/bleed, substrates, N spot inks, plate roles, transform, clipping, provenance and per-system seeds
- [ ] Prehnite-specific geometry is an adapter, not an engine invariant
- [ ] Same recipe resolves identically in browser and Node
- [ ] JSON schema or validator rejects invalid dimensions/ink mappings and reports actionable errors

## Traceability
- [ ] Link implementing PR with `Closes #2`
- [ ] Attach before/after artwork/plates or CLI output evidence
- [ ] Record tests and reviewed licensing impact

See [v0.9 brief](../blob/main/docs/BRIEF-v9.md) and [AGENTS.md](../blob/main/AGENTS.md).
## Native delivery tracking

Milestone: [v0.9](https://github.com/yigit-denktas/stipra/milestone/1) · Project: [Stipra](https://github.com/users/yigit-denktas/projects/3) (existing private project; access unchanged). Release scope and dependencies: [ROADMAP.md](https://github.com/yigit-denktas/stipra/blob/main/ROADMAP.md).



## #3 — [Geometry] Crisp contours, shared facet seams and calibrated gem proportions

- state: open / None
- author: yigit-denktas; labels: ['enhancement']; milestone: v0.9; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T20:16:15Z; closedAt: None; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/3

### Body

**Type:** Bug / Feature  
**Priority:** P2 — nonblocking case-study polish  
**Area:** Geometry  
**Target:** v0.9  
**Assignee:** @yigit-denktas  
**Project:** [Stipra](https://github.com/users/yigit-denktas/projects/3) (private) · **Milestone:** [v0.9](https://github.com/yigit-denktas/stipra/milestone/1)  
**Development branch (planned):** `fix/3-crisp-facet-geometry`  
**Dependencies:** #2

**Scope decision (2026-10-16):** This work is preserved for the *Prehnite example*, not a prerequisite for v0.9 image separation, masks, the browser studio or print exports. If it distracts from #7/#5/#8/#9/#22, defer it.

## Scope
Crisp contours, shared facet seams and calibrated gem proportions.

## Acceptance criteria
- [ ] Stop random vertex displacement for print imperfection effects
- [ ] Shared seam topology must match between touching facets with no gaps
- [ ] Correct lower-right Prehnite polygon contour against approved reference
- [ ] Outer silhouette and seams remain straight at every export size; ink registration may offset colors without bending paths
- [ ] Add geometry-only debug view and regression fixture

## Traceability
- [ ] Link implementing PR with `Closes #3`
- [ ] Attach before/after artwork/plates or CLI output evidence
- [ ] Record tests and reviewed licensing impact

See [v0.9 brief](../blob/main/docs/BRIEF-v9.md) and [AGENTS.md](../blob/main/AGENTS.md).
## Native delivery tracking

Milestone: [v0.9](https://github.com/yigit-denktas/stipra/milestone/1) · Project: [Stipra](https://github.com/users/yigit-denktas/projects/3) (existing private project; access unchanged). Release scope and dependencies: [ROADMAP.md](https://github.com/yigit-denktas/stipra/blob/main/ROADMAP.md).



## #4 — [Paper] Clustered contamination, fibers and separately seeded ink debris

- state: open / None
- author: yigit-denktas; labels: ['enhancement']; milestone: v0.9; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T20:16:17Z; closedAt: None; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/4

### Body

**Type:** Feature  
**Priority:** P2 — nonblocking style extension  
**Area:** Substrate  
**Target:** v0.9  
**Assignee:** @yigit-denktas  
**Project:** [Stipra](https://github.com/users/yigit-denktas/projects/3) (private) · **Milestone:** [v0.9](https://github.com/yigit-denktas/stipra/milestone/1)  
**Development branch (planned):** `feat/4-paper-contamination`  
**Dependencies:** #2

**Scope decision (2026-10-16):** Authentic paper fibers/dirt remain an optional print-texture style. Basic paper/ink substrate separation is already a required contract, but realistic clustered debris is **not** a v0.9 release blocker; don't make it a dependency for actual image separations.

## Scope
Clustered contamination, fibers and separately seeded ink debris.

## Acceptance criteria
- [ ] Implement fiber/pulp, small dark flecks, colored debris and rare clustered larger contaminants with quiet regions
- [ ] Expose stock palette and density/cluster/size/opacity controls; preserve all six colorways
- [ ] Split intrinsic paper dirt (substrate-only) from deposited ink flecks (on respective plates)
- [ ] Independently seeded paper, ink debris, geometry and screens; deterministic repeat tests
- [ ] Document coverage impacts, display 100% previews and remove uniform noise artifacts

## Traceability
- [ ] Link implementing PR with `Closes #4`
- [ ] Attach before/after artwork/plates or CLI output evidence
- [ ] Record tests and reviewed licensing impact

See [v0.9 brief](../blob/main/docs/BRIEF-v9.md) and [AGENTS.md](../blob/main/AGENTS.md).
## Native delivery tracking

Milestone: [v0.9](https://github.com/yigit-denktas/stipra/milestone/1) · Project: [Stipra](https://github.com/users/yigit-denktas/projects/3) (existing private project; access unchanged). Release scope and dependencies: [ROADMAP.md](https://github.com/yigit-denktas/stipra/blob/main/ROADMAP.md).



## #5 — [Ink] Dot-native, reverse, hybrid and overprint screening with real plate masks

- state: closed / completed
- author: yigit-denktas; labels: ['enhancement']; milestone: v0.9; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T20:16:19Z; closedAt: 2026-10-16T22:25:07Z; comments: 1
- url: https://github.com/yigit-denktas/stipra/issues/5

### Body

**Type:** Feature  
**Priority:** P0  
**Area:** Print model  
**Target:** v0.9  
**Assignee:** @yigit-denktas  
**Project:** [Stipra](https://github.com/users/yigit-denktas/projects/3) (private) · **Milestone:** [v0.9](https://github.com/yigit-denktas/stipra/milestone/1)  
**Development branch (planned):** `feat/5-dot-screen-model`  
**Dependencies:** #2, #7 (both complete)

**Scope decision (2026-10-16):** Keep native geometry screens and controlled registration, but for imported photographs operate on actual **separation coverage masks from #7**, after #7's unscreened grayscale masks work. Reuse compatible standard algorithms; do not fork/rewrite p5.riso into MIT. No press-calibration claim absent measurement.

## Scope
Deliver deterministic **raster** screening for real imported-image ink coverage masks, with true per-ink editable screen parameters, no geometry deformation, and optional registration shift.

**Scope split (2026-10-17):** The original facet-level, true-vector SVG dot-geometry requirements belong to [#28](https://github.com/yigit-denktas/stipra/issues/28) and remain **open**. Issue #5 can close on verified raster capability; it must not claim SVG vector screening is implemented.

## Acceptance criteria
- [ ] Positive dots, reverse knockout holes, dense solid, paper-only, dual spot overprint and hybrid screens
- [ ] Per-ink raster coverage, angle, pitch, dot scale, deterministic jitter and screened coverage stats (facet-level vector control tracked in #28)
- [ ] Geometry remains fixed while halftone settings change
- [ ] Registration is per-plate translation/rotation; no geometry warping
- [ ] Validate identical full-frame pixel masks in Node and browser; true-vector equivalence tracked in #28

## Traceability
- [ ] Link implementing PR with `Closes #5`
- [ ] Attach before/after artwork/plates or CLI output evidence
- [ ] Record tests and reviewed licensing impact

See [v0.9 brief](../blob/main/docs/BRIEF-v9.md) and [AGENTS.md](../blob/main/AGENTS.md).
## Native delivery tracking

Milestone: [v0.9](https://github.com/yigit-denktas/stipra/milestone/1) · Project: [Stipra](https://github.com/users/yigit-denktas/projects/3) (existing private project; access unchanged). Release scope and dependencies: [ROADMAP.md](https://github.com/yigit-denktas/stipra/blob/main/ROADMAP.md).


### Comment by yigit-denktas at 2026-10-16T22:05:42Z (https://github.com/yigit-denktas/stipra/issues/5#issuecomment-6225595525)

## Ready for screening implementation — #7 merged

[PR #26](https://github.com/yigit-denktas/stipra/pull/26) merged into `main`: `src/separation.js` now produces per-ink **Uint8Array(width × height)** continuous-tone coverage values (0 no ink, 255 full ink) from real imported image pixels. Recipe mode `spot` or `cmyk`, independent ink settings, source alpha, optional spot blackHold, and actual CLI/browser outputs are implemented and tested. Use these masks as **inputs** to screening; do not reimplement RGB/CMYK mapping or alter the raster origin.

Next #5 tests should use 1:1 same-size masks and add separate deterministic modes for solid, positive dots, reverse/knockout holes, line/halftone and hybrid; keep random grain/registration independent of original geometry, compare unscreened coverage versus screened dots, and preserve fine black linework with optional unscreened routing. Screens must not silently add substrate as physical ink. Provide spot and CMYK reference fixtures, browser/Node parity and performance limits. Pure masking/halftoning is not equivalent to measured Risograph dot gain. This is a handoff, not a completion claim.


## #6 — [Import] Accept PNG, JPEG, WebP and structured SVG without disturbing layout

- state: closed / completed
- author: yigit-denktas; labels: ['enhancement']; milestone: v0.9; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T20:16:22Z; closedAt: 2026-10-16T21:10:53Z; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/6

### Body

**Type:** Feature  
**Priority:** P0  
**Area:** Input  
**Target:** v0.9  
**Assignee:** @yigit-denktas  
**Project:** [Stipra](https://github.com/users/yigit-denktas/projects/3) (private) · **Milestone:** [v0.9](https://github.com/yigit-denktas/stipra/milestone/1)  
**Development branch (planned):** `feat/6-image-import`  
**Dependencies:** #2

## Scope
Accept PNG, JPEG, WebP and structured SVG without disturbing layout.

## Acceptance criteria
- [ ] Browser drag/drop + CLI file paths for raster and safe SVG input
- [ ] Preserve intrinsic aspect, orientation, trim, alpha/transparency, color profile metadata when available
- [ ] Separate upload processing from procedural scene generation; no arbitrary reference tracing
- [ ] Warn about unsupported SVG filters/fonts and display fallback accurately
- [ ] Use local processing only; memory limits and malformed files have tests

## Traceability
- [ ] Link implementing PR with `Closes #6`
- [ ] Attach before/after artwork/plates or CLI output evidence
- [ ] Record tests and reviewed licensing impact

See [v0.9 brief](../blob/main/docs/BRIEF-v9.md) and [AGENTS.md](../blob/main/AGENTS.md).

## Implementation notes after #2 (2026-10-16)

The shipped v1 `src/core.js` defines immutable canvas/trim/bleed, spot plate IDs, origin and provenance. **Do not** coerce a raster file into fake `rect`/`polygon` geometry or change the v1 contract in place; define an explicit asset adapter and versioned migration/extension when a raster-backed scene is introduced.

Proposed import boundary:
1. **Probe:** sniff by file signature, validate byte/pixel budgets, extract intrinsic size, format, alpha, EXIF orientation and available ICC/profile flags. Reject malformed payloads and unsupported formats with field-level errors.
2. **Decode:** platform adapters for browser `File` / `ImageBitmap` and Node local image decoder; normalize orientation once, preserve source/provenance and original aspect ratio, never upload input to a service.
3. **Scene mapping:** preserve the intrinsic image grid and alpha under a single source transform. Feed an explicit pixel buffer to #7 separation without silently resampling or making the image a new print plate.
4. **SVG:** only accept a precisely documented safe structured subset; reject scripts, external references, unsafe attributes and unsupported filters/fonts or offer an explicit deterministic raster fallback with warnings. Do not claim regex-only sanitization is a security boundary.

Golden tests: transparent PNG, EXIF-rotated JPEG, alpha WebP, a safe vector SVG, malicious/unsupported SVG, dimensions/trim mismatches, malformed images and memory-budget rejection. Keep #6 open until browser drag/drop **and** CLI paths work and layout/orientation preservation is verified.

## Native delivery tracking

Milestone: [v0.9](https://github.com/yigit-denktas/stipra/milestone/1) · Project: [Stipra](https://github.com/users/yigit-denktas/projects/3) (existing private project; access unchanged). Release scope and dependencies: [ROADMAP.md](https://github.com/yigit-denktas/stipra/blob/main/ROADMAP.md).



## #7 — [Separation] Editable spot-ink and CMYK image decomposition

- state: closed / completed
- author: yigit-denktas; labels: ['enhancement']; milestone: v0.9; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T20:16:24Z; closedAt: 2026-10-16T22:05:01Z; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/7

### Body

**Type:** Feature  
**Priority:** P0  
**Area:** Color  
**Target:** v0.9  
**Assignee:** @yigit-denktas  
**Project:** [Stipra](https://github.com/users/yigit-denktas/projects/3) (private) · **Milestone:** [v0.9](https://github.com/yigit-denktas/stipra/milestone/1)  
**Development branch (planned):** `feat/7-spot-cmyk`  
**Dependencies:** #6 (completed); #5 consumes this coverage-mask model for later optional screening

**Scope decision (2026-10-16):** Implement correct, adjustable grayscale spot/CMYK **coverage masks first**, independently from halftoning: per-channel mappings, thresholds/curves, overlap and preserved alpha/origin. Masks feed #5 screening, #8 full-frame masters and #22 browser controls. A different preview ink color without a changed coverage mask is not a valid separation. Avoid p5.riso source; original MIT algorithms and legal provenance review #14.

## Scope
Editable spot-ink and CMYK image decomposition.

## Acceptance criteria
- [ ] Support user-selected N spot colors independently from default CMYK recipe
- [ ] Raster separations are labeled estimates; allow mask/threshold/channel/mapping edits
- [ ] Preserve solid black text and linework through selective non-halftone options
- [ ] Ink plate coverage may overlap; paper is never counted as a printable ink
- [ ] Compare digital overprint preview with inputs and export metadata

## Traceability
- [ ] Link implementing PR with `Closes #7`
- [ ] Attach before/after artwork/plates or CLI output evidence
- [ ] Record tests and reviewed licensing impact

See [v0.9 brief](../blob/main/docs/BRIEF-v9.md) and [AGENTS.md](../blob/main/AGENTS.md).
## Native delivery tracking

Milestone: [v0.9](https://github.com/yigit-denktas/stipra/milestone/1) · Project: [Stipra](https://github.com/users/yigit-denktas/projects/3) (existing private project; access unchanged). Release scope and dependencies: [ROADMAP.md](https://github.com/yigit-denktas/stipra/blob/main/ROADMAP.md).



## #8 — [Prepress] Full-frame aligned monochrome ink masters and registration metadata

- state: closed / completed
- author: yigit-denktas; labels: ['enhancement']; milestone: v0.9; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T20:16:26Z; closedAt: 2026-10-17T20:15:12Z; comments: 4
- url: https://github.com/yigit-denktas/stipra/issues/8

### Body

**Type:** Feature  
**Priority:** P0  
**Area:** Prepress  
**Target:** v0.9  
**Assignee:** @yigit-denktas  
**Project:** [Stipra](https://github.com/users/yigit-denktas/projects/3) (private) · **Milestone:** [v0.9](https://github.com/yigit-denktas/stipra/milestone/1)  
**Development branch (planned):** `feat/11-compare-batch-exports`  
**Dependencies:** #7

## Scope
Full-frame aligned monochrome ink masters and registration metadata.

## Acceptance criteria
- [x] One physical ink = one full-canvas grayscale coverage plate (black full ink, white empty)
- [x] All plates preserve exact width/height, trim, origin and component placement
- [x] Raster (PNG) + true-vector plate SVG where supportable
- [x] Optional crop/registration marks outside trim area and correct bleed metadata
- [x] Coverage estimates calculated from plate intensity in trim region; validate against exported masters

## Traceability
- [x] Link implementing PR with `Closes #8`
- [x] Attach before/after artwork/plates or CLI output evidence
- [x] Record tests and reviewed licensing impact

See [v0.9 brief](../blob/main/docs/BRIEF-v9.md) and [AGENTS.md](../blob/main/AGENTS.md).
## CLI/export integration — PR #93

Implemented by `feat/11-compare-batch-exports`, with `Closes` links in PR #93. Reproduction and bounds: docs/CLI-WORKFLOWS.md. No new runtime dependencies, restricted code, owner photographs or external binaries were added; #14’s three upstream provenance findings remain open.

Validation: 155 local Node tests passed with zero skipped before the final focused QA fixes; those fixes also pass their targeted suites. Exact final-head CI and the `cli-export-workflow-evidence` artifact are linked from PR #93. The artifact contains original procedural 2/3/4-ink sources, packages, source/proof comparisons, JSON verification, A4 reports and browser parity. Physical observations remain #13; no registry publication/tag or final identity approval is implied.

SVG masters for image masks are pure sampled-run paths with native frame, grayscale values and physical dimensions; they embed no bitmap. They are explicitly not recovered curves or analytic halftone circles. Marked PNGs preserve trim pixels exactly; generated bleed is explicitly zero. #28 remains a separate analytic-vector extension.

## Native delivery tracking

Milestone: [v0.9](https://github.com/yigit-denktas/stipra/milestone/1) · Project: [Stipra](https://github.com/users/yigit-denktas/projects/3) (existing private project; access unchanged). Release scope and dependencies: [ROADMAP.md](https://github.com/yigit-denktas/stipra/blob/main/ROADMAP.md).


### Comment by yigit-denktas at 2026-10-16T22:25:38Z (https://github.com/yigit-denktas/stipra/issues/8#issuecomment-6225860676)

## Handoff from merged raster screening #5

[PR #27](https://github.com/yigit-denktas/stipra/pull/27) landed real full-frame raster dot/reverse/line/hybrid screening on the #7 spot/CMYK coverage masks. The CLI now exports both unscreened `plate-<id>.png` and screened `screened-<id>-plate.png`, plus their previews/normalized recipes/provenance. Node and browser use the same MIT `src/screening.js` math, and independent registration offsets preserve the shared raster grid.

**Next #8:** print-size/DPI/trim/bleed decisions, registration/crop marks, plate naming/orientation guarantees, proper 1:1 and physical scale tests, optional printable vectors where originally vector, and fail-closed validations. Do not represent the current screen pitch **in pixels** as lines/inch or imply spectral dot gain is calibrated. Include realistic 300 DPI fixtures and physical test workflow. Native SVG facet screening is independently tracked in [#28](https://github.com/yigit-denktas/stipra/issues/28).

### Comment by yigit-denktas at 2026-10-16T22:59:12Z (https://github.com/yigit-denktas/stipra/issues/8#issuecomment-6226268602)

## Physical output reference: separate digital proof simulation from actual masters

The [Dizzy Ink field notes](https://github.com/yigit-denktas/stipra/blob/main/docs/references/DIZZY-INK.md) and [rules R06–R08](https://github.com/yigit-denktas/stipra/blob/main/docs/PRINT-DESIGN-RULES.md) are live.

Important preflight requirements: nominally aligned full-frame **production** masters by default; optional simulated registration only in colored proof (do not bake it into masters by default); express intended physical shifts in **mm**, screen frequency in **LPI** and export raster in **DPI** with explicit conversion and rounding. A 5mm border and ~50mm feed-edge risk appear in Dizzy Ink's guidance as **shop/machine-specific examples**, not universal constants. Require a printer profile to issue hard exclusions/press-readiness claims. A4 process report ≠ A4 production plate.

### Comment by yigit-denktas at 2026-10-16T23:20:40Z (https://github.com/yigit-denktas/stipra/issues/8#issuecomment-6226517407)

## Owner-photo acceptance handoff — 17 Oct 2026

[#39](https://github.com/yigit-denktas/stipra/issues/39) delivered a [cross-fixture specification](https://github.com/yigit-denktas/stipra/blob/main/docs/PRINT-PACKAGE-ACCEPTANCE.md) and [SHA-256/pixel metadata](https://github.com/yigit-denktas/stipra/blob/main/tests/fixtures/owner-photo-fixtures.json) for A sculpture (805×644), B forest (2048×1365), C beach (1152×2048). **No image binaries committed.**

Implement automated **G01–G06**: original-byte SHA preservation, 2/3/2 actual distinct physical ink masks, identical full-frame plate grids, correct grayscale polarity, lossless registration/trim baseline, and truthful pixel→mm at an *explicit* 300 DPI. Native-size constraints: A 68.16×54.53mm, B 173.40×115.57mm, C 97.54×173.40mm. B has a 72dpi metadata tag but target print DPI must be explicitly selected; C has an ICC profile that must be accounted for. *Do not close #8 until all real package fixtures verify these checks.*

### Comment by yigit-denktas at 2026-10-16T23:57:55Z (https://github.com/yigit-denktas/stipra/issues/8#issuecomment-6226966448)

Print masters handoff (merged PR #42): [CLI guide](https://github.com/yigit-denktas/stipra/blob/main/docs/PRINT-PACKAGE-v1.md) now documents source-frame raster grayscale masters, actual PNG density metadata, zero production registration and optional separate marks outside trim. Synthetic CI tests passed. [Private batch runner](https://github.com/yigit-denktas/stipra/blob/main/scripts/owner-photo-batch.js) checks three original SHA fingerprints. Keep #8 open until canonical Node runs against the owner images plus full-size/physical verification. Local Python reference proofs were visually reviewed separately; B forest still looks muddy. No user images committed.


## #9 — [Reports] A4 landscape print-separation sheet in HTML and PDF

- state: closed / completed
- author: yigit-denktas; labels: ['enhancement']; milestone: v0.9; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T20:16:28Z; closedAt: 2026-10-17T16:18:16Z; comments: 7
- url: https://github.com/yigit-denktas/stipra/issues/9

### Body

**Type:** Feature  
**Priority:** P0  
**Area:** Reports  
**Target:** v0.9  
**Assignee:** @yigit-denktas  
**Project:** [Stipra](https://github.com/users/yigit-denktas/projects/3) (private) · **Milestone:** [v0.9](https://github.com/yigit-denktas/stipra/milestone/1)  
**Development branch (planned):** `feat/9-separation-report`  
**Dependencies:** #8

## Scope
A4 landscape print-separation sheet in HTML and PDF.

## Acceptance criteria
- [x] Match approved layout: full artwork, paper card, one card per physical ink, swatches, tags and estimates
- [x] Same full-art layout in each miniature; ink removal does not trigger any reflow
- [x] Responsive browser report and paginated printable A4 landscape PDF; keep extra plates on subsequent pages
- [x] Accurate dimensions/scale/DPI/trim/seed/color designation labels
- [x] Generate both presentation sheet and independent full-resolution masters in one ZIP

## Traceability
- [x] Link implementing PR with `Closes #9`
- [x] Attach before/after artwork/plates or CLI output evidence
- [x] Record tests and reviewed licensing impact

See [v0.9 brief](../blob/main/docs/BRIEF-v9.md) and [AGENTS.md](../blob/main/AGENTS.md).

## Acceptance reconciliation — 17 October 2026

Report implementation and owner-reviewed layout are integrated through #45/#61/#63/#67/#69 and reconciled in #91 (Closes #9). Tests in tests/report-layout.test.js exercise real 2/3/8-ink PDFs in landscape/portrait, pagination, minimum text/bounds, source-frame preservation, physical screen labels, byte stability and real Plex macron outlines. Print-package/browser/alpha tests verify shared report/master ZIPs, geometry, hashes and embedded recipes. Private owner-image report review is recorded in #63; photographs and derived documents remain private. Public procedural fixtures and CI artifacts provide reproducible digital evidence.

This closes report generation/inspection acceptance only. Physical printing remains #13, generic/vector export acceptance remains #8/#12, and three distribution-provenance findings remain #14. No press-calibration or final-brand claim.

## Native delivery tracking

Milestone: [v0.9](https://github.com/yigit-denktas/stipra/milestone/1) · Project: [Stipra](https://github.com/users/yigit-denktas/projects/3) (existing private project; access unchanged). Release scope and dependencies: [ROADMAP.md](https://github.com/yigit-denktas/stipra/blob/main/ROADMAP.md).


### Comment by yigit-denktas at 2026-10-16T22:25:40Z (https://github.com/yigit-denktas/stipra/issues/9#issuecomment-6225861076)

## Handoff from merged #5 + #7

Real continuous-tone and screened grayscale plates now exist: `src/separation.js` and `src/screening.js`, plus the optional CLI `--screen` recipe, reviewed under [PR #27](https://github.com/yigit-denktas/stipra/pull/27). The A4 separation sheet must consume these **same immutable masks, same canvas origin and source dimensions**—not another color segmentation algorithm or an artistically simplified thumbnail.

Include original, simulated overprint, substrate, and one preview/mono layer per selected physical ink, labeled screen recipe/angle/pitch/registration, effective DPI/crop, mean ink coverage, source hash and an explicit uncalibrated caveat. Handle CMYK and 2–8 spot inks, with overflow pages; do not scale or reflow artwork inside plate panels. Keep source artwork rights out of bundled examples unless cleared.

### Comment by yigit-denktas at 2026-10-16T22:59:14Z (https://github.com/yigit-denktas/stipra/issues/9#issuecomment-6226268963)

## Separation report should teach how the print is made

The original [Dizzy Ink print guide](https://risograph.co.uk/) makes individual grayscale masters, ink names/densities, overprinting and registration easier to understand. Stipra's [annotated reference](https://github.com/yigit-denktas/stipra/blob/main/docs/references/DIZZY-INK.md) and [design rules](https://github.com/yigit-denktas/stipra/blob/main/docs/PRINT-DESIGN-RULES.md) are merged.

For #9 include original vs proof, each grayscale master at identical geometry, assigned ink swatch, paper, overlap/coverage indicators, output DPI/physical dimensions, optional screen details, explicitly labeled proof registration and provenance; clearly state RGB proof ≠ calibrated physical color. Keep machine-specific safe area labeled by source profile. Report must describe existing masks, **not generate a new separation**.

### Comment by yigit-denktas at 2026-10-16T23:20:42Z (https://github.com/yigit-denktas/stipra/issues/9#issuecomment-6226517794)

## Owner-photo report handoff — 17 Oct 2026

Use [#39's acceptance document](https://github.com/yigit-denktas/stipra/blob/main/docs/PRINT-PACKAGE-ACCEPTANCE.md) for **G07–G08**. A4 *landscape inspection* PDF **297×210mm** must show original/composite/substrate and identical-composition thumbnail for **every ink** (A 2, B 3, C 2) with names, real grayscale contributions, paper, screen recipe/seed, source provenance, output scale, and an uncalibrated-proof notice. HTML and PDF need the same information/ordering and no internal cropping/reflow of the source. Beach is a portrait input: don't stretch it into the landscape report; allow a narrower panel or additional sheet. *An A4 report is not an A4 production master.* All tests currently NOT RUN.

### Comment by yigit-denktas at 2026-10-16T23:57:57Z (https://github.com/yigit-denktas/stipra/issues/9#issuecomment-6226966896)

A4 report implementation landed in PR #42. The package CLI creates a 297×210mm PDF and matching HTML with original/overprint hero, paper and per-ink grayscale cards, print dimensions, swatches, hashes and screening labels. Synthetic PDF/ZIP CI passed. Keep #9 open for canonical Node A/B/C image outputs, actual-A4 legibility, portrait layout and manual/physical review. Report page is distinct from full-size masters.

### Comment by yigit-denktas at 2026-10-17T02:01:29Z (https://github.com/yigit-denktas/stipra/issues/9#issuecomment-6228252074)

Follow-up design QA scope is now tracked in [#54](https://github.com/yigit-denktas/stipra/issues/54): extract the **actual four original SVG fills** (#006043, #FF665D, #0D4DAD, #E2A523); compare real lowercase `stiprā` in IBM Plex Sans Bold / Plex Mono Bold / Paper Mono Regular / ExtraBold; choose one documented finalist per family; render **only three private PDFs**, two matched pages each, from the owner’s verified sculpture / forest / beach source files. Square *page* for sculpture without changing its source ratio, landscape forest, portrait beach; consistent ink plates and recipes, embedded metadata, no generated placeholder images. The old #52 font-proof experiment was a technical precursor, not the finished art-direction evaluation. Original README dotmark stays untouched pending approval.

### Comment by yigit-denktas at 2026-10-17T02:14:32Z (https://github.com/yigit-denktas/stipra/issues/9#issuecomment-6228376483)

Implemented in PR #55: four authentic stiprā outlines, SVG-derived brand tokens, IBM Plex Sans Bold and Paper Mono ExtraBold finalists, and three private owner-photo PDFs (square A / landscape B / portrait C), two pages each. Original-photo hashes match the fixture catalog; normalized recipes and actual fonts are embedded. Paired pages have identical image pixels and nontext drawing geometry. Separate-directory builds reproduce PDF and recipe hashes. Local validation: 76 Node tests + 9 private Python checks passed. Images/PDFs are delivered privately, never committed or uploaded to Pages. See docs/TYPE-COMPARISON.md in #55 for evaluation and replay instructions. Owner aesthetic approval and physical-print verification remain open; no brand direction adopted. Public CI status is separate from private fixture verification.

### Comment by yigit-denktas at 2026-10-17T10:22:16Z (https://github.com/yigit-denktas/stipra/issues/9#issuecomment-6232764404)

Takeover implemented in PR #61, preserving merged #58/#59 and the separate #55 typography study. Canonical PDFs now use regular/bold/mono roles with a 9pt minimum, full input SHA-256, all 2–8 plates with pagination, actual LPI/screen-off labels, existing overlap warnings and linked guide QRs. Fixed a verified missing-glyph box for ā by merging authentic Latin Extended outlines. Build and 93 Node tests pass (no skips). Three private A4 owner reports each have two pages, match hashes across separate output directories, and all six pages were visually reviewed at 144dpi. Owner photos/report images remain private. No final wordmark or default separation adopted; physical print and owner aesthetic approval remain open.


## #10 — [QA] Reference HSL/coverage masks, registration overlays and per-layer metrics

- state: open / None
- author: yigit-denktas; labels: ['enhancement']; milestone: v0.9; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T20:16:30Z; closedAt: None; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/10

### Body

**Type:** Feature  
**Priority:** P1 — optional expanded diagnostics; not a v0.9 release blocker  
**Area:** Diagnostics  
**Target:** v0.9  
**Assignee:** @yigit-denktas  
**Project:** [Stipra](https://github.com/users/yigit-denktas/projects/3) (private) · **Milestone:** [v0.9](https://github.com/yigit-denktas/stipra/milestone/1)  
**Development branch (planned):** `feat/10-reference-diagnostics`  
**Dependencies:** #8

**Scope decision (2026-10-16):** Basic plate solo/coverage statistics are part of #7/#22. Advanced reference HSL/registration overlays are optional follow-on diagnostics and must not block CLI (#11) or printing exports (#8/#9/#12).

## Scope
Reference HSL/coverage masks, registration overlays and per-layer metrics.

## Acceptance criteria
- [ ] Estimated reference plate segmentation by editable HSL/CIELAB thresholds
- [ ] Cyan/magenta difference view for reference vs render; per-plate tinted overlays and structural bbox comparisons
- [ ] Report per-element and per-ink occupancy/IoU and geometry anchor offsets, not a misleading single aesthetic score
- [ ] Fix alignment before calculating overlap; preserve reference aspect and origin
- [ ] Emit JSON metrics plus a labeled diagnostic sheet with reproducible recipe/seeds

## Traceability
- [ ] Link implementing PR with `Closes #10`
- [ ] Attach before/after artwork/plates or CLI output evidence
- [ ] Record tests and reviewed licensing impact

See [v0.9 brief](../blob/main/docs/BRIEF-v9.md) and [AGENTS.md](../blob/main/AGENTS.md).
## Native delivery tracking

Milestone: [v0.9](https://github.com/yigit-denktas/stipra/milestone/1) · Project: [Stipra](https://github.com/users/yigit-denktas/projects/3) (existing private project; access unchanged). Release scope and dependencies: [ROADMAP.md](https://github.com/yigit-denktas/stipra/blob/main/ROADMAP.md).



## #11 — [CLI] Agent-safe import, separate, sheet, compare and batch commands

- state: closed / completed
- author: yigit-denktas; labels: ['enhancement']; milestone: v0.9; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T20:16:33Z; closedAt: 2026-10-17T20:15:13Z; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/11

### Body

**Type:** Feature  
**Priority:** P1  
**Area:** Automation  
**Target:** v0.9  
**Assignee:** @yigit-denktas  
**Project:** [Stipra](https://github.com/users/yigit-denktas/projects/3) (private) · **Milestone:** [v0.9](https://github.com/yigit-denktas/stipra/milestone/1)  
**Development branch (planned):** `feat/11-compare-batch-exports`  
**Dependencies:** #6, #7, #8, #9; #10 advanced overlays optional

**Scope decision (2026-10-16):** Prioritize the genuinely useful agent loop: same source + versioned recipe from browser and CLI, parameterized mask edits, deterministic repeat renders, comparable outputs and structured error/result manifests. No general p5.js runtime or arbitrary untrusted JS execution.

## Scope
Agent-safe import, separate, sheet, compare and batch commands.

## Acceptance criteria
- [x] Documented CLI with import/separate/sheet/compare/batch/render commands and --json output
- [x] Same plate masks, dimensions and recipe semantics as browser
- [x] Versioned machine-readable manifests, exit codes, deterministic seeds and safe output paths
- [x] Batch jobs produce individually auditable artifacts with no external API calls
- [x] Include examples and automated end-to-end CLI smoke tests

## Traceability
- [x] Link implementing PR with `Closes #11`
- [x] Attach before/after artwork/plates or CLI output evidence
- [x] Record tests and reviewed licensing impact

See [v0.9 brief](../blob/main/docs/BRIEF-v9.md) and [AGENTS.md](../blob/main/AGENTS.md).
## CLI/export integration — PR #93

Implemented by `feat/11-compare-batch-exports`, with `Closes` links in PR #93. Reproduction and bounds: docs/CLI-WORKFLOWS.md. No new runtime dependencies, restricted code, owner photographs or external binaries were added; #14’s three upstream provenance findings remain open.

Validation: 155 local Node tests passed with zero skipped before the final focused QA fixes; those fixes also pass their targeted suites. Exact final-head CI and the `cli-export-workflow-evidence` artifact are linked from PR #93. The artifact contains original procedural 2/3/4-ink sources, packages, source/proof comparisons, JSON verification, A4 reports and browser parity. Physical observations remain #13; no registry publication/tag or final identity approval is implied.

Batch and comparison plans are inert, bounded local JSON. Outputs use fresh directories; partial jobs remain individually inspectable and exit nonzero. `--json` wraps results/errors. Existing scene/render output files are never rewritten with different content.

## Native delivery tracking

Milestone: [v0.9](https://github.com/yigit-denktas/stipra/milestone/1) · Project: [Stipra](https://github.com/users/yigit-denktas/projects/3) (existing private project; access unchanged). Release scope and dependencies: [ROADMAP.md](https://github.com/yigit-denktas/stipra/blob/main/ROADMAP.md).



## #12 — [Exports] Reproducible PNG, JPG, WebP, pure SVG, PDF and plate bundles

- state: closed / completed
- author: yigit-denktas; labels: ['enhancement']; milestone: v0.9; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T20:16:35Z; closedAt: 2026-10-17T20:15:13Z; comments: 3
- url: https://github.com/yigit-denktas/stipra/issues/12

### Body

**Type:** Feature  
**Priority:** P1  
**Area:** Export  
**Target:** v0.9  
**Assignee:** @yigit-denktas  
**Project:** [Stipra](https://github.com/users/yigit-denktas/projects/3) (private) · **Milestone:** [v0.9](https://github.com/yigit-denktas/stipra/milestone/1)  
**Development branch (planned):** `feat/11-compare-batch-exports`  
**Dependencies:** #8, #9

## Scope
Reproducible PNG, JPG, WebP, pure SVG, PDF and plate bundles.

## Acceptance criteria
- [x] Raster exports at native and selected scale/DPI with explicit alpha/profile behavior
- [x] Pure vector SVG containing paths/dots/glyph outlines; no embedded bitmap unless explicitly chosen as hybrid
- [x] PDF separation sheets plus appropriately aligned printable masters
- [x] ZIP includes recipe, manifests, plate files, color names, paper metadata and hashes
- [x] SVG/raster parity and round-trip dimensions verified by tests

## Traceability
- [x] Link implementing PR with `Closes #12`
- [x] Attach before/after artwork/plates or CLI output evidence
- [x] Record tests and reviewed licensing impact

See [v0.9 brief](../blob/main/docs/BRIEF-v9.md) and [AGENTS.md](../blob/main/AGENTS.md).
## CLI/export integration — PR #93

Implemented by `feat/11-compare-batch-exports`, with `Closes` links in PR #93. Reproduction and bounds: docs/CLI-WORKFLOWS.md. No new runtime dependencies, restricted code, owner photographs or external binaries were added; #14’s three upstream provenance findings remain open.

Validation: 155 local Node tests passed with zero skipped before the final focused QA fixes; those fixes also pass their targeted suites. Exact final-head CI and the `cli-export-workflow-evidence` artifact are linked from PR #93. The artifact contains original procedural 2/3/4-ink sources, packages, source/proof comparisons, JSON verification, A4 reports and browser parity. Physical observations remain #13; no registry publication/tag or final identity approval is implied.

Proof PNG/JPG/WebP/SVG derivatives support explicit 1/2/3 scale and source/paper alpha semantics; JPEG flattens to paper and lossy codec bytes may vary. Native PNG masters are unchanged by derivative settings. Real browser/Node tests compare decoded lossless pixels and SVG paths and check lossy signatures/dimensions. Sampled SVG and analytic scene output are distinguished.

## Native delivery tracking

Milestone: [v0.9](https://github.com/yigit-denktas/stipra/milestone/1) · Project: [Stipra](https://github.com/users/yigit-denktas/projects/3) (existing private project; access unchanged). Release scope and dependencies: [ROADMAP.md](https://github.com/yigit-denktas/stipra/blob/main/ROADMAP.md).


### Comment by yigit-denktas at 2026-10-16T23:20:44Z (https://github.com/yigit-denktas/stipra/issues/12#issuecomment-6226518154)

## Owner-photo ZIP/replay handoff — 17 Oct 2026

Follow [#39's package contract](https://github.com/yigit-denktas/stipra/blob/main/docs/PRINT-PACKAGE-ACCEPTANCE.md) for **G09–G11**: for each of the three private, source-hashed images, build a portable ZIP with original bytes, proof, ink plates, screened masters, A4 HTML/PDF, normalized ink/screen recipes, immutable manifest and per-file hashes. Refuse unsafe archive paths; test open/read, no duplicate/missing entries, no silent overwrite and reproducibility of decoded images with the same seed/versions. Distinguish byte-identical pixel data from nondeterministic PDF metadata. Preserve the ICC source handling note for beach. No user originals in the public repo without explicit rights. Current status 0/3 complete packages verified.

### Comment by yigit-denktas at 2026-10-16T23:57:59Z (https://github.com/yigit-denktas/stipra/issues/12#issuecomment-6226967288)

Raster ZIP pipeline merged in PR #42: source bytes, normalized image, proof/paper, individual grayscale masters/screens, optional marked plates, HTML/PDF report, normalized recipes and hash-indexed manifest. Uses MIT-path JSZip and MIT pdf-lib. Synthetic tests cover ZIP hashes/geometry/no-overwrite. Keep #12 open for broader JPG/WebP/true SVG format matrix, owner-photo canonical visual QA, large-image performance and real printing.

### Comment by yigit-denktas at 2026-10-17T13:47:53Z (https://github.com/yigit-denktas/stipra/issues/12#issuecomment-6234648072)

#69 is merged. #77 additionally verifies original-byte retention, source ICC/policy metadata, normalized-pixel retention and embedded-font OFL text in the package. Existing shared screen/master tests and actual browser ZIP checks remain active. Local suite: 116 passing, no skips; public build passes. Broader vector/format acceptance and physical print evidence remain open; this update does not close #12.


## #13 — [QA] Golden images, browser accessibility and physical print validation plan

- state: open / None
- author: yigit-denktas; labels: ['enhancement']; milestone: v0.9; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T20:16:37Z; closedAt: None; comments: 11
- url: https://github.com/yigit-denktas/stipra/issues/13

### Body

## Experimental Studio prerelease published — 19 October 2026

[Stiprā Studio v0.9.0-rc.1](https://github.com/yigit-denktas/stipra/releases/tag/v0.9.0-rc.1) was published by the owner at 15:57:16 UTC. Release ID 417461374 has draft=false and prerelease=true. The created tag points exactly to `aec0c23d6cc538e4e00352c66ee9543eba7694cd`.

Attached browser build: 3,714,250 bytes; GitHub asset digest `sha256:a07cb05d0f14945b69870c6b6fb1e084cf62cb0e10674cfb2caac72eabce32b3`, matching the previously independently downloaded and verified archive. Release notes now record publication and the verified owner-supplied live print package; stale draft instructions were removed.

The genuine release.published event triggered [release-history run 39281781549](https://github.com/yigit-denktas/stipra/actions/runs/39281781549). Its status was queued at verification; website-history deployment is not yet claimed successful. No native executable, npm version bump, physical print, human accessibility or independent artist acceptance follows from this experimental release. Keep #13 open for remaining acceptance.

---

## Owner-supplied live download verified — 19 October 2026

The owner supplied the actual downloaded print package after browser download-event capture failed. ZIP SHA-256: `958351a32dec4953e82fe9a7aa26bd58c2eb2246f97aa13de20981552fcb0148`; 2,771,434 bytes. The CLI verifier returns `VERIFIED_DIGITAL_NOT_PHYSICALLY_VALIDATED`.

All 16 manifest-listed payloads pass bytes/SHA-256 checks; no missing, unlisted or duplicate entries. Two grayscale ink passes retain 1200 × 420 px, 300 DPI, zero registration and 101.6 × 35.56 mm native trim. The two-page A4 landscape PDF embeds its fonts; JSON-decoded recipe and diagnostic attachments agree with the ZIP. Both rendered report pages were visually reviewed without clipping or overlap. Archived source bytes match the candidate build's public outlined wordmark SVG.

Together with observed live import, candidate preview/adoption and plate inspection, this completes the bounded live-host import-to-download specimen check. Exact deployed application bytes, physical prints, human accessibility and independent artist acceptance are not established by this evidence.

The [GitHub releases page](https://github.com/yigit-denktas/stipra/releases) contains draft release ID 417461374; GitHub changes its temporary untagged URL on saving, so use the releases index rather than old temporary links. Draft notes now record this verification. Attaching and verifying the exact browser build ZIP remains before publication; the supplied print package is not that build archive. Keep #13 open for its remaining human/physical scope.

---

## Live-host retry after permission enabled — 19 October 2026

File-upload permission is no longer the blocker. Downloading the public outlined SVG onto the browser device and selecting that actual local file succeeded: 1200 × 420 px, two plates, original/proof framing and native physical dimensions displayed. Candidate comparison retained current settings until explicit Use candidate; adoption and solo/all-ink inspection worked.

The ZIP export completed and showed “Print package saved locally,” with no visible app error. Browser download-event capture timed out for both proof and ZIP; downloaded bytes were not independently inspected. A later PNG import had different dimensions, so it is not accepted as proof of this export. Browser-side acquisition of the exact Actions candidate ZIP also timed out. Do not claim the complete saved-download check passed.

The existing [prerelease draft](https://github.com/yigit-denktas/stipra/releases/tag/untagged-49b6232d2b539737ec8a) has updated notes. It remains unpublished with no verified release asset attached. Finish saved-export verification and attach the exact previously verified archive before publication. Human, physical and artist acceptance remain unchanged.

---

## Earlier retry and saved GitHub draft — 19 October 2026 (superseded blocker)

The browser connection is working again. A real [GitHub prerelease draft](https://github.com/yigit-denktas/stipra/releases/tag/untagged-49b6232d2b539737ec8a) is saved: release ID 417461374, proposed tag v0.9.0-rc.1, target aec0c23d6cc538e4e00352c66ee9543eba7694cd, draft=true, prerelease=true, published_at=null, zero attached assets. No publication or created Git tag is claimed.

The public two-ink SVG was acquired through the supported page-asset export. Actual fileChooser.setFiles was rejected because the ChatGPT extension requires its **Allow access to file URLs** setting. This specific permission blocks the live import/download check and browser asset attachment. No permission setting was changed. Human/physical/artist gates remain as recorded below.

---

## Studio candidate verification — 19 October 2026

Merged PR #116 prepares the bounded experimental browser candidate; merged [PR #117](https://github.com/yigit-denktas/stipra/pull/117) independently verifies the main archive and prepares release notes. The exact candidate source is aec0c23d6cc538e4e00352c66ee9543eba7694cd: its main CI passes all 77 steps and Pages deployment succeeded. The archive SHA-256 and all 78 listed site files match; there are no missing, unlisted or duplicate entries. Follow-up PR #117 also passes 77 CI steps / 189 Node tests and the separate public-page review. [Verification and limits](https://github.com/yigit-denktas/stipra/blob/main/docs/evidence/studio-candidate-follow-up-2026-10-19.json).

The formal proposed GitHub tag is v0.9.0-rc.1; v0.9-rc.1 is only the earlier planning label. No tag, GitHub release or npm change is claimed. The live-host import/download check remains incomplete: file-transfer helpers failed, then Edge reported another extension UI requiring a person to dismiss it. Initial Studio/guide/Canvas states and frame advance were observed; CI's complete built-site checks are separate evidence.

Human keyboard/screen-reader observations remain open. Physical prints and independent artist testing are explicitly owner-deferred, not passed. Owner approval covers the supplied digital forest/beach specimens only. Keep #13 open.

---

## Prior acceptance — 18 October 2026

All 74 CI steps pass in PR #102, including nine-route real Chromium axe checks, real Tab/Enter skip-link checks, geometry/golden and export parity checks. These do not establish a human accessibility review or a physical print.

Still needed: an operator prints the photo-free kit at 100%, measures the two 100 mm rules and 101.6 × 76.2 mm master, records actual stock/printer/driver and observed legibility/registration, and returns evidence with the completed observation record. A home-printer check cannot calibrate Riso inks. Independent artist and human screen-reader/keyboard observations are also not performed. Procedures: docs/PHYSICAL-PRINT-CHECK.md and docs/ARTIST-TRIAL.md. No acceptance fields have been filled with expected or simulated results.

---

**Type:** Chore  
**Priority:** P1  
**Area:** Quality  
**Target:** v0.9  
**Assignee:** @yigit-denktas  
**Project:** [Stipra](https://github.com/users/yigit-denktas/projects/3) (private) · **Milestone:** [v0.9](https://github.com/yigit-denktas/stipra/milestone/1)  
**Development branch (planned):** `test/13-print-quality-gates`  
**Dependencies:** #5, #7, #8, #9, #11, #12, #22; #3/#4 optional case-study quality

**Scope decision (2026-10-16):** Release acceptance: first usable two-ink separation; image fidelity/linework; identical origin/trim/DPI/registration of full plates; reproducible outputs, actual time/memory/file size and physical home-print validation. Don't mark the owner-supplied acceptance checkboxes as tested until evidence exists.

## Scope
Golden images, browser accessibility and physical print validation plan.

## Acceptance criteria
- [x] Golden regression snapshots for six Prehnite palettes and generic 2/3/4-ink sources — saved native vector composite/active-plate hashes plus generic continuous/screened pixel-mask hashes; this is not cross-rasterizer or physical acceptance.
- [x] Assert straight shared edges and deterministic geometry/plate separation with independently seeded paper noise — PR #96, all six palettes; defaults unchanged.
- [x] Headless Chrome editor interactions (import, facet controls, sheet previews, export) and accessible UI labels — bounded automated evidence; human accessibility acceptance remains open.
- [x] CI uploads representative reports and ink masks for review
- [x] Document non-calibrated simulation limits and manual physical press checklist — docs/PHYSICAL-PRINT-CHECK.md; actual printing remains not performed.

## Traceability
- [ ] Link implementing PR with `Closes #13`
- [ ] Attach before/after artwork/plates or CLI output evidence
- [ ] Record tests and reviewed licensing impact

See [v0.9 brief](../blob/main/docs/BRIEF-v9.md) and [AGENTS.md](../blob/main/AGENTS.md).
## CLI/export integration — PR #93

Implemented by `feat/11-compare-batch-exports`, with `Closes` links in PR #93. Reproduction and bounds: docs/CLI-WORKFLOWS.md. No new runtime dependencies, restricted code, owner photographs or external binaries were added; #14’s three upstream provenance findings remain open.

Validation: 155 local Node tests passed with zero skipped before the final focused QA fixes; those fixes also pass their targeted suites. Exact final-head CI and the `cli-export-workflow-evidence` artifact are linked from PR #93. The artifact contains original procedural 2/3/4-ink sources, packages, source/proof comparisons, JSON verification, A4 reports and browser parity. Physical observations remain #13; no registry publication/tag or final identity approval is implied.

### Delivered software regression scope

- [x] Saved continuous/screened mask hashes for odd-size 2/3/4-ink original procedural fixtures.
- [x] Public CLI compare/batch/verify/sheet exercised end to end, including deterministic package replay, fresh paths, partial failures and altered metadata/bytes.
- [x] Native grayscale/DPI/trim/coverage verification, unchanged marked trim pixels and unique ink master paths.
- [x] PNG/JPG/WebP/SVG proof format/scale/alpha evidence; actual browser/Node lossless pixel and sampled SVG parity.
- [x] Six current procedural report pages reviewed visually; compact recipe rows avoid a nearly empty diagnostics page without shrinking text.

#13 stays open for remaining full acceptance and physical observations; the original broader golden/geometry criteria are not silently marked complete by this scoped fixture set.

## Saved acceptance and physical-record checks — PR #94

Branch `test/13-release-acceptance`. Six native procedural colorways and every active ink plate now have committed SHA-256/byte baselines, checked by `npm run check:goldens` and uploaded as `procedural-acceptance-goldens`. The generic vector masters remain byte-identical when paper seed/color changes. `node scripts/check-print-observations.js RECORD` rejects blank/incomplete observations, unsafe or changed evidence and reports the declared measurement tolerance without authenticating printing or claiming calibration.

The original legacy Prehnite softened/shared-seed geometry is preserved; straight shared edges and independent legacy paper-seed architecture are not declared complete. Existing Chromium interactions/labels are scoped evidence, not a complete accessibility audit. Actual operator observations and human/artist review remain open. No owner photographs, new runtime dependencies or external binary commits. Current contract: docs/RELEASE-CANDIDATE.md. Local validation: 159 Node tests passed, zero skipped; full final CI is linked from PR #94.

## Native delivery tracking

Milestone: [v0.9](https://github.com/yigit-denktas/stipra/milestone/1) · Project: [Stipra](https://github.com/users/yigit-denktas/projects/3) (existing private project; access unchanged). Release scope and dependencies: [ROADMAP.md](https://github.com/yigit-denktas/stipra/blob/main/ROADMAP.md).

## Expanded acceptance — merged PR #96

Exact head a1fd16616177189a65fb0798c66c8174a00499a3; CI 39072779691 passed all 72 steps. Real axe-core 4.10.3 WCAG A/AA checks report zero violations across studio, import studio, Prehnite, guide, sketches and regions. Actual missing labels/invalid aria usage were fixed without suppression. Contrast and one generated-guide aria check remain incomplete/manual; this is not human accessibility certification. Independent paperSeed changes substrate while native plates/facets remain identical; zero-softness actual shared paths are verified geometrically. Legacy defaults/goldens remain unchanged. Operator print observations and human/artist review remain open.


## 19 October acceptance follow-up — merged PR #110

Fresh photo-free operator kit generated, digitally verified and visually inspected; the blank observation record correctly fails. Ten-route automated checks pass. Actual printer measurements, human keyboard/screen-reader use and physical calibration remain unperformed. Keep this issue open.

Merged as `9ad3325884e58b401c188750e62169e7803073c9`; exact head `7ff2f5a` passed all [75 CI steps](https://github.com/yigit-denktas/stipra/actions/runs/39222373464). All 187 Node tests pass locally, along with scoped release gates and saved artwork/plate goldens. [Concrete handoff and review](https://github.com/yigit-denktas/stipra/blob/main/docs/ACCEPTANCE-2026-10-19.md) · [numeric evidence only](https://github.com/yigit-denktas/stipra/blob/main/docs/evidence/acceptance-quality-2026-10-19.json). Owner photos and image-bearing outputs remain private; no public image attachment or native redistribution.


### Comment by yigit-denktas at 2026-10-16T22:59:16Z (https://github.com/yigit-denktas/stipra/issues/13#issuecomment-6226269328)

## Proposed print-quality rule acceptance fixtures

Research synthesized from [Dizzy Ink's guide](https://risograph.co.uk/) into [Stipra rules R01–R10](https://github.com/yigit-denktas/stipra/blob/main/docs/PRINT-DESIGN-RULES.md) and [field notes](https://github.com/yigit-denktas/stipra/blob/main/docs/references/DIZZY-INK.md), merged PR #36.

Add QA for: plate boundary/origin parity, alpha and density semantics, near-empty/duplicate ink masks, overlap metrics without fictional universal safe caps, proof-only registration leaving actual masters unchanged, full-size trim/margin warnings under an explicit machine profile, and equivalent **physical** screen frequency across two DPI outputs. Do not treat metrics as evidence of artistic quality or press calibration; keep an owner-reviewed visual golden set and real printed samples for the final gate.

### Comment by yigit-denktas at 2026-10-16T23:20:46Z (https://github.com/yigit-denktas/stipra/issues/13#issuecomment-6226518502)

## Three real-image visual/physical acceptance targets — 17 Oct 2026

The [A/B/C acceptance spec](https://github.com/yigit-denktas/stipra/blob/main/docs/PRINT-PACKAGE-ACCEPTANCE.md) includes **15 image-specific checks** and a separate physical test protocol. A: sculpture ridge continuity, highlights, dark background and moiré. B: distant rectangle, antler silhouettes, bark/grass distinction and overprint density. C: sky gradient banding, horizon straightness, two tiny figures, coastline and ICC provenance. Review source+plates+proof and 100% detail crops, recording PASS/FAIL/NOT RUN with evidence; aesthetic success is not established by image metrics alone.

Physical validation requires real print photos, measured 100% scale, printer/paper/ink details and notes; it remains **NOT RUN** until tested. Add separate public-safe small-text/linework sample since the three owner photos don't cover typography. Link any true defects to #8/#9/#12; all three owner photos remain private pending redistribution clearance.

### Comment by yigit-denktas at 2026-10-16T23:58:01Z (https://github.com/yigit-denktas/stipra/issues/13#issuecomment-6226967674)

Owner-photo QA remains open after merged PR #42. Node implementation passes synthetic tests; separately produced private Pillow/ReportLab reference PDFs are NOT official Node fixture results or physical prints. Early visual observations: A recognizable folds but ridge moiré / high dark-background coverage; B forest still loses depth/antler contrast after tuning (do not sign off); C straight horizon, but sky and tiny people need full-scale checks and ICC conversion parity. Require canonical Node outputs and all G01–G11 plus specific visual/physical gates in [the acceptance doc](https://github.com/yigit-denktas/stipra/blob/main/docs/PRINT-PACKAGE-ACCEPTANCE.md). Nothing user-owned redistributed publicly.

### Comment by yigit-denktas at 2026-10-17T02:14:33Z (https://github.com/yigit-denktas/stipra/issues/13#issuecomment-6228376616)

Implemented in PR #55: four authentic stiprā outlines, SVG-derived brand tokens, IBM Plex Sans Bold and Paper Mono ExtraBold finalists, and three private owner-photo PDFs (square A / landscape B / portrait C), two pages each. Original-photo hashes match the fixture catalog; normalized recipes and actual fonts are embedded. Paired pages have identical image pixels and nontext drawing geometry. Separate-directory builds reproduce PDF and recipe hashes. Local validation: 76 Node tests + 9 private Python checks passed. Images/PDFs are delivered privately, never committed or uploaded to Pages. See docs/TYPE-COMPARISON.md in #55 for evaluation and replay instructions. Owner aesthetic approval and physical-print verification remain open; no brand direction adopted. Public CI status is separate from private fixture verification.

### Comment by yigit-denktas at 2026-10-17T12:11:56Z (https://github.com/yigit-denktas/stipra/issues/13#issuecomment-6233734917)

Observed intermittent existing Chromium smoke timeouts during #66/#67 verification: run 39030873739 attempt 1 timed out on PNG file input, then passed unchanged on rerun; run 39031475425 attempt 1 timed out on unsafe SVG rejection with status 'Reading local file…'. Local suites pass and the unchanged importer path is affected. The current runner uses --virtual-time-budget=12000 while smoke helpers poll asynchronously; virtual timer advancement racing real FileReader/decode work is a plausible cause, not yet proven. Track a real-time browser completion gate instead of treating rerun success as a reliability fix. No tests have been skipped or assertions weakened.

### Comment by yigit-denktas at 2026-10-17T13:15:48Z (https://github.com/yigit-denktas/stipra/issues/13#issuecomment-6234324306)

PR #69 completes the current browser hardening package. Browser Print package ZIP now reuses the CLI's package/report pipeline, preserving source, native unscreened/aligned screened masters, separate proof offsets, physical PNG DPI, recipes, diagnostics, PDF attachments and hashes. Shared geometry and a repeated-density regression are tested. The real browser test captures the UI download and verifies decoded master pixels, geometry, registration, DPI, manifest hashes and PDF recipes.

Removed virtual-time smoke execution and added explicit app readiness before file drops. CI exposed a second race: controls could exist before event handlers were installed. Both the import and built-studio smokes now wait for handlers to be ready. Run 39035645035 passed fully; final-head run 39035693892 has passed Node tests and both browser suites and is finishing its QR check. Local 110 tests passed with zero skipped.

Added scripts/physical-print-kit.js and docs/PHYSICAL-PRINT-CHECK.md. Photo-free kit: exact vector 100mm rulers, 50mm square, 8/9/10/12pt text, line-width and grayscale specimens, two 300-DPI authored-source print packages, hashes and blank observations. One scale sheet and all four report pages rendered and visually inspected. Physical printing remains NOT RUN; #13 is deliberately not closed. See docs/STUDIO-EXPORT.md for reproducibility and browser/Skia limits. No owner imagery is committed or hosted.

### Comment by yigit-denktas at 2026-10-17T20:17:26Z (https://github.com/yigit-denktas/stipra/issues/13#issuecomment-6240335651)

PR #93 is merged as 95f1cab6a22f8d47adf95e028d7a5f5b9d2ec875. #8/#11/#12 closed; this issue remains open.

Final exact-head CI 39065596684 passed all 65 steps with 156 Node tests. Added end-to-end compare/batch/verify/sheet, 2/3/4-ink saved mask goldens, odd-frame and scale/format evidence, real browser/Node lossless PNG/SVG parity, changed-byte/metadata rejection, and authored derivative replay with legacy coverage precision compatibility. Six latest procedural report pages and desktop/mobile comparison screenshots were reviewed.

Evidence: https://github.com/yigit-denktas/stipra/actions/runs/39065596684/artifacts/12112194809 . No owner photographs are included. Physical observations and the remaining broader acceptance criteria stay unverified; no press calibration or release approval is implied.

### Comment by yigit-denktas at 2026-10-17T21:03:34Z (https://github.com/yigit-denktas/stipra/issues/13#issuecomment-6241014618)

Merged PR #94 as 3d1cb3d42ab76e7c7bd8121e8d32b0fa5874a449. Exact reviewed head 4ad95c4: https://github.com/yigit-denktas/stipra/actions/runs/39069080661 passed all 67 steps. Local full suite: 159 passed, zero skipped. Review evidence: procedural-acceptance-goldens artifact 12114054416; lean-distribution-audit artifact 12114800654 contains the three tested private tarballs and library-candidate.json. Downloaded candidate archive hashes match the report and are identical between local Node24 and CI Node20. Actual operator printing, wider human/artist acceptance, the three upstream inventories and registry publication remain separate open work, as specified in docs/RELEASE-CANDIDATE.md. No owner imagery or new runtime dependencies were committed.

### Comment by yigit-denktas at 2026-10-17T22:31:59Z (https://github.com/yigit-denktas/stipra/issues/13#issuecomment-6242326471)

PR #97 is merged after all 74 CI steps passed: https://github.com/yigit-denktas/stipra/actions/runs/39075159757 . Operator kit: https://github.com/yigit-denktas/stipra/actions/runs/39075159757/artifacts/12116861436 . Downloaded and verified all seven kit manifest entries; both synthetic 1200×900 / 300 DPI packages pass production master/embedded-font checks. All four kit report pages and vector ruler PDF reviewed visually. It includes an empty observation record: physical printing remains not performed. Accessibility artifact has zero automated violations across six routes, with contrast/guide aria incomplete checks retained. Do not close physical/human acceptance from these digital checks.

### Comment by yigit-denktas at 2026-10-18T02:14:21Z (https://github.com/yigit-denktas/stipra/issues/13#issuecomment-6244616819)

Merged #99 expands actual axe coverage to nine routes and adds real Chromium Tab/Enter checks across all nine generated public destinations. CI 39089138672 passed all 74 steps; downloaded accessibility artifact 12122191171 has zero violations and all nine keyboard checks. The expanded audit caught/fixed nested issue links in roadmap disclosure headings; guide/screening labels now have valid group semantics. Guide aria-prohibited incomplete check is resolved. Color-contrast incomplete checks, human screen-reader review, independent artist feedback and actual physical observations remain open; none is inferred from these software checks. README, candidate contract, changelog and ledger are updated.

### Comment by yigit-denktas at 2026-10-19T21:40:14Z (https://github.com/yigit-denktas/stipra/issues/13#issuecomment-6277999763)

Windows review at 3deeab8 reports 14 remaining failures; integration does not claim Windows acceptance. Triage separates actual portability work (npm subprocess executable resolution, pinned vendor LF checkout, README CRLF character counting) from host-sensitive failures (TEMP ACL/access denied and symlink privilege). These Windows logs were described by the independent reviewer, not executed in this Linux integration. PR #119 fixes study-local UTF-8/LF and POSIX paths only, with four synthetic metric tests and 193 passing Node tests on Linux. Remaining Windows failures need targeted reproduction and regression fixes; do not label all 14 as environment-only or infer a Windows pass from Linux CI.


## #14 — [Research] Dependency license audit and CMYK versus spot-ink design notes

- state: open / None
- author: yigit-denktas; labels: ['documentation']; milestone: v0.9; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T20:16:39Z; closedAt: None; comments: 8
- url: https://github.com/yigit-denktas/stipra/issues/14

### Body

## Current status — 19 October 2026

One broad distribution finding remains: the exact compiled-component and third-party notice inventory for native Skia. Source revisions/build candidates are mapped in PR #100; source mapping is not binary clearance. Lean library packages exclude native Skia and the browser exporter has its separate checked inventory.

The approved inventory request was posted through the authorized browser fallback on 19 October 2026: [samizdatco/skia-canvas #309](https://github.com/samizdatco/skia-canvas/issues/309). The earlier integration HTTP 403 is resolved for the contact step. No maintainer response or notice clearance is claimed. Keep the native release gate open until attributable binary/component/notices evidence is obtained and reviewed.


The independent AI-assisted review is reconciled in PR #104 and docs/RENDER-BACKEND-REVIEW.md. The missing item is an attributable compiled-component notice inventory; no maintainer refused permission. Current CI runs non-gating `audit:licenses`, explicit lean/browser release gates and native rejection tests. The legacy broad native command still rejects redistribution. Green CI does not clear native redistribution.

Bounded follow-ups are complete in merged PR #107: fresh artifact-specific release gates and a narrow LF checkout policy for hash-pinned notice text. The exact terms/digest are unchanged, and both new/legacy native gates still reject redistribution. No backend upgrade, self-build or new native bundle. Source Cargo lockfile counts (318 versus 328 entries) are not compiled-component inventories. npm alpha.1 verification is complete separately in #70.


## Executed backend experiment — PR #105

The owner-authorized 3.0.8-versus-4.0.0 comparison now runs in isolated pinned prefixes/fresh processes against source 24f731f. 23 accepted inputs and 10 expected rejections agree; 13 JS cases and all 60 proof/plate RGBA cases match, while 36 PNG streams differ only in encoding. All 124 QR checks pass. Both versions fail loudly with the native payload omitted.

Canvas text metrics, missing-face synthetic Bold and speckled paper change. With a shared frozen paper bitmap, report pages match exactly at 150/300 DPI; text placements and embedded faces agree. Result: stop-and-review, with 19 case-level stops representing several shared causes. No dependency upgrade, native bundle, golden regeneration or notice clearance. Short CPU/RSS observations are bounded and do not prove leak freedom.

A clean preparation/replay on the same host reproduces all decode/mask/font/paper records and the same promotion verdict. Harness and measured JSON: docs/SKIA-V4-EXPERIMENT.md, scripts/experiments/skia-compare/, docs/evidence/skia-v4-comparison-2026-10-18.json. All 163 Node tests and focused documentation checks pass locally; PR CI remains separately tracked. Windows/macOS/musl/GPU parity and the complete native notice inventory remain unknown. Artifact-specific gates and LF checkout follow-ups were subsequently completed in PR #107; native notices remain unresolved.


## Independent technical replay and analyzer correction — PR #106

Merged as `a66b3cca639272598e0a242182e8a83e380a9847`. PR head `6c3b157` passed all 74 CI steps (run 39136120436); local acceptance also includes 163 Node tests, five contract tests and four actual-PDF attachment mutations. Native notices remain open.

The supplied independent review reports 272 identical decode/mask/font/paper records on a different Linux CPU host/toolchain. Production call-site audit confirms the 15 typography stops are backend probes, not current product regressions. Paper texture and PNG byte identities, plus deliberate audit-pin updates, define a later migration. Keep 3.0.8 and existing production goldens.

The reviewer found an attachment-only gap in the research analyzer. Five contract regressions and four actual-PDF mutations now verify blocking semantics while preserving page drawing streams. Only layout image-SHA leaves verified against actual pixel-equal PNG pairs are allowed. Package image identities/pixels, physical output and PDF links also block changes. Results-v2 reanalysis preserves all 19 original stops. No production licensing release gate changed.

Review identities and checks: docs/evidence/skia-v4-review-reconciliation-2026-10-18.json. The apparent source-lock mismatch equals LF versus CRLF bytes, verified locally. Future diagnostics redact host paths and preparation captures its observed environment automatically; the original archive and supplied review files remain unchanged. Full compiled native notices, non-Linux/GPU and human/physical acceptance remain open. LF checkout policy and artifact-specific release gates were subsequently completed in PR #107.


## Scoped release gates and LF checkout — merged PR #107

Merged as `d7a1a73a123817705c04a24f76302a36b7c03863`. Final head `f6f184e` passed all [75 CI steps](https://github.com/yigit-denktas/stipra/actions/runs/39147787959); all 168 Node tests pass locally. Page build, fresh exact lean tarballs/offline consumer, IIFE/ESM browser release gates and all saved artwork/plate goldens pass. CI uploads the gate reports and linked artifact inventories.

- [x] Preserve the original MIT-terms.txt bytes/digest with one LF checkout rule; verify an actual core.autocrlf=true Git checkout and CRLF control, and reject changed/CRLF notice bytes.
- [x] Add explicit `check:release:lean`, `check:release:browser` and `check:release:native` commands. Rebuild evidence rather than filter a saved broad report; bind manifests by SHA-256. Missing/unknown scope, build failures and stale evidence cannot pass.
- [x] Select reviewed artifacts from actual browser inputs before identity checks. Excluded native installations are not read; included native/WASM artifacts remain rejected. Browser notices now use the production inventory's reviewed license-selection policy, with an actual exporter rejection regression for unreviewed declarations.
- [x] Wire lean/browser release gates into CI, with native rejection tested. Preserve both new native and legacy broad exit-1 behavior.
- [ ] Obtain/review attributable compiled-component notices for the shipped native binary before bundled CLI/executable/container distribution. This finding keeps #14 open.

README, release/audit contracts, roadmap, public changelog and delivery ledger are reconciled. Production stays on skia-canvas 3.0.8; retained terms, native notice finding and saved goldens are unchanged. This work publishes no package or native bundle. Windows-style checkout behavior is tested on Linux; Windows/macOS renderer claims still need their own evidence.

---

**Type:** Research / Documentation  
**Priority:** P0  
**Area:** Licensing  
**Target:** v0.9  
**Assignee:** @yigit-denktas  
**Project:** [Stipra](https://github.com/users/yigit-denktas/projects/3) (private) · **Milestone:** [v0.9](https://github.com/yigit-denktas/stipra/milestone/1)  
**Development branch (planned):** `docs/14-license-research`  
**Dependencies:** #1

## Scope
Dependency license audit and CMYK versus spot-ink design notes.

## Acceptance criteria
- [ ] Review p5.riso Anti-Capitalist License; do not vendor restricted code into MIT project
- [ ] Document risoAtHome/Public Lab Image Sequencer inspiration and separation technique options
- [ ] Track Inter glyph SIL OFL obligations and ensure full notice is in repository
- [ ] Define ownership and redistribution restrictions for supplied/generated reference images
- [ ] Add dependency license checklist and separate code/brand/asset licensing scope

## Traceability
- [ ] Link implementing PR with `Closes #14`
- [ ] Attach before/after artwork/plates or CLI output evidence
- [ ] Record tests and reviewed licensing impact

See [v0.9 brief](../blob/main/docs/BRIEF-v9.md) and [AGENTS.md](../blob/main/AGENTS.md).

## Distribution audit follow-ups — #77

- [x] Inventory the locked/installed production npm graph and record actual notice evidence, integrity and hashes (65 package locations).
- [x] Preserve embedded fontkit/Node notice text in the browser bundle; include report font OFL text in print ZIPs.
- [x] Verify p5.grain's upstream MIT license; keep p5.riso excluded from the commercial-use implementation path.
- [x] Retain dijkstrajs's published attribution plus the complete referenced MIT terms, pinned to original notice/version hashes.
- [x] Retain string-split-by's published 2018 attribution plus complete MIT terms, pinned to original notice/version hashes.
- [x] Remove the opaque @pdf-lib/fontkit prebundle; verify the replacement fontkit 2.0.4 source-map inventory and actual browser notices (PR #95).
- [ ] Verify exact platform skia-canvas native binary/Rust/Skia/codec notices before bundling an executable.
- [x] Remove fonteditor-core and its WOFF2 WASM; embed hash-verified original IBM Plex TTFs (PR #95).

Run `npm run audit:licenses` for the report and `npm run check:release-licenses` for the fail-closed distribution gate. Findings keep this issue open. The static site does not distribute the Node native binary or fonteditor WASM; its generated bundle has a separate notice file. See docs/DEPENDENCY-AUDIT.md in #77.

## Consolidation evidence — #91

The broad production inventory still contains 65 package locations. Two incomplete-notice findings are resolved with licenses/third-party/supplements.json and full referenced terms; original notices are preserved and changed evidence fails the supplement hash check. Fontkit extraction now retains both line and block notices, including embedded base64/Node and Google/Brotli Apache notices and complete Apache terms.

Three findings remain, deliberately fail-closed: exact fontkit prebundled component attribution/versions; exact platform Skia/Rust/codec notices; WOFF2/Brotli WASM source/build provenance. licenses/third-party/artifact-review.json records actual artifact hashes, sizes and primary source gaps. This is not blanket commercial-redistribution clearance. The static site excludes native Skia and fonteditor WASM but still has the fontkit exporter; lean core/Canvas/inputs exclude all three. No external binary or owner artwork is committed.

Validation: npm run audit:licenses produces the inventory with three findings; npm run check:release-licenses intentionally exits 1. tests/license-audit.test.js checks preserved attribution/Apache terms and the unresolved gate; the audit also rejects changed published-notice bytes. See docs/DEPENDENCY-AUDIT.md and the versioned delivery ledger in #90/#91. Physical printing remains #13.

## Artifact boundary checks — #92

- [x] Inspect the actual private core/Canvas/inputs tarballs, original MIT notices and statically resolved imports with `npm run check:distribution`; retain exact archive/file hashes as CI evidence.
- [x] Emit browser-export input/package/output/notice hashes and identify the actual selected fontkit UMD artifact. Keep the exporter report `review-required`.
- [x] Reject changed reviewed upstream bytes/versions. Scope the native identity record to Linux x64 glibc and report other platforms as unrecorded.
- [x] Remove previous audit reports before rebuilding so failed checks cannot leave stale passing evidence.

Upstream investigation is documented in docs/DEPENDENCY-AUDIT.md. Fontkit's source/build map, WOFF2's unpinned source/toolchain and Skia's compiled-component inventory still leave the same three provenance findings open. Hash identity is not clearance; broad `check:release-licenses` intentionally remains exit 1. #70 publication/artist acceptance remains separate. No package publication, upstream contact, owner imagery or binary commits.

Local validation at PR head ec0d0cf: 149 Node tests passed, none skipped; page builds, packed-library check and focused rejection tests passed. Full CI evidence is attached to PR #92; do not infer its result from this local record.

## Exact candidate and source recheck — PR #94

`npm run check:library-candidate` installs the exact audited core/Canvas/inputs archives together offline with lifecycle scripts disabled, then tests public runtime/type exports and Canvas-region-core replay. It does not clear the excluded browser/native/WASM artifacts. Pinned source-file blob identities and observations are recorded in licenses/third-party/source-review.json. Correction: the WOFF2 README installs Emscripten 1.38.48 but activates latest; the compiler provenance is ambiguous, not entirely unmentioned. All three upstream findings remain open and `check:release-licenses` still exits 1. No upstream contact, restricted code, new runtime dependencies, owner photos or external binaries. See docs/RELEASE-CANDIDATE.md for artifact-specific gates.

## Native delivery tracking

Milestone: [v0.9](https://github.com/yigit-denktas/stipra/milestone/1) · Project: [Stipra](https://github.com/users/yigit-denktas/projects/3) (existing private project; access unchanged). Release scope and dependencies: [ROADMAP.md](https://github.com/yigit-denktas/stipra/blob/main/ROADMAP.md).

## Current distribution result — merged PR #95

The historical three-finding notes above are superseded for the current distribution: 74 installed production locations, one remaining finding (native Skia compiled-component inventory). Browser export has zero findings for its exact bundle/source inventory. Old opaque artifacts are retired, not cleared retrospectively. The broad release check intentionally fails for native Skia. Modern Fontkit maps match published source bytes; this is not an independent compiler attestation. Exact head 53ee72a10877f7d41872cb444be45e27840f3410; CI 39072235937 passed all 70 steps. No owner images or font binaries committed.


### Comment by yigit-denktas at 2026-10-16T21:44:27Z (https://github.com/yigit-denktas/stipra/issues/14#issuecomment-6225276987)

## License audit scope update — independent printmaking implementation (2026-10-16)

Owner decision: Stipra-authored code stays MIT; **do not fork, vendor or machine-rewrite** [p5.riso](https://github.com/antiboredom/p5.riso)'s Anti-Capitalist-licensed source into an MIT output. Record provenance of original implementations of conventional ink screening, CMYK/spot coverage, registration, dither, overprint etc. A copied code structure with renamed identifiers is not independent merely because a reverse-engineering or AI tool emitted it.

Also: [p5.js](https://github.com/processing/p5.js) uses **LGPL-2.1**, distinct from p5.riso and MIT; any future adapter must comply with LGPL obligations. Audit Skia Canvas, xmldom, native/transitive code, Inter OFL outlines, reference fixtures and branding separately. Before a corporate/public release, get jurisdiction-appropriate review of the actual source and distribution choices.

Legal sources and policy: [docs/LICENSING.md](https://github.com/yigit-denktas/stipra/blob/main/docs/LICENSING.md), [v0.9 scope](https://github.com/yigit-denktas/stipra/blob/main/ROADMAP.md), [Directive 2009/24/EC](https://eur-lex.europa.eu/eli/dir/2009/24/oj/eng), [CJEU C-406/10](https://eur-lex.europa.eu/legal-content/EN/ALL/?uri=celex%3A62010CJ0406). These are *not* a license clearance claim.

### Comment by yigit-denktas at 2026-10-17T13:47:51Z (https://github.com/yigit-denktas/stipra/issues/14#issuecomment-6234647683)

#77 adds a reproducible installed/locked production dependency inventory (65 package locations), selected licenses, package integrity and SHA-256 of actual notice evidence. It preserves embedded fontkit/Node notices in the browser bundle and includes Plex OFL text in print ZIPs. p5.grain's actual upstream LICENSE was checked: MIT (Joseph Miclaus/Gorilla Sun); it is not installed and does not require a license-driven replacement.

The inventory is complete for this npm graph, but distribution clearance is **not** complete. Five concrete findings remain: incomplete published grant terms in dijkstrajs and string-split-by; prebundled component attribution in @pdf-lib/fontkit; native platform/Rust/Skia/codec notices for skia-canvas; WOFF2/Brotli WASM provenance in fonteditor-core. npm metadata does not resolve those nested artifact questions.

`npm run audit:licenses` emits the report/notices; `npm run check:release-licenses` intentionally exits 1 while findings remain. CI uploads the inventory without owner assets. docs/DEPENDENCY-AUDIT.md records scope, evidence and remedies. Keeping #14 open rather than treating compatible SPDX labels as blanket commercial clearance.

### Comment by yigit-denktas at 2026-10-17T18:21:32Z (https://github.com/yigit-denktas/stipra/issues/14#issuecomment-6238482235)

PR #92 merged as 2c8f8d1fccb53986881b1ec5cb24891e64c23668 after full CI 39057494772 passed. The new exact-tarball gate and browser input/output evidence are on main. Downloaded CI artifact 12109649508 independently matches all three archive hashes and 21 packed-file hashes. Local suite: 149 passed, zero skipped.

This completes the scoped artifact-boundary hardening, not the three upstream provenance findings. #14 stays open; broad release check intentionally remains nonzero. No package was published. Evidence and reproduction commands are in docs/DEPENDENCY-AUDIT.md and PR #92.

### Comment by yigit-denktas at 2026-10-17T21:03:35Z (https://github.com/yigit-denktas/stipra/issues/14#issuecomment-6241014918)

Merged PR #94 as 3d1cb3d42ab76e7c7bd8121e8d32b0fa5874a449. Exact reviewed head 4ad95c4: https://github.com/yigit-denktas/stipra/actions/runs/39069080661 passed all 67 steps. Local full suite: 159 passed, zero skipped. Review evidence: procedural-acceptance-goldens artifact 12114054416; lean-distribution-audit artifact 12114800654 contains the three tested private tarballs and library-candidate.json. Downloaded candidate archive hashes match the report and are identical between local Node24 and CI Node20. Actual operator printing, wider human/artist acceptance, the three upstream inventories and registry publication remain separate open work, as specified in docs/RELEASE-CANDIDATE.md. No owner imagery or new runtime dependencies were committed.

### Comment by yigit-denktas at 2026-10-17T21:44:55Z (https://github.com/yigit-denktas/stipra/issues/14#issuecomment-6241672503)

Concrete replacement/removal work is in PR #95 (branch fix/14-distribution-provenance): removes fonteditor-core and its WOFF2 WASM; replaces opaque @pdf-lib/fontkit with exact Fontkit 2.0.4 whose browser/Node maps match all own-source files and whose dependencies are separately inventoried. Retains complete declared MIT terms and actual Google Apache decoder notices; browser build rejects unused compiled Brotli encoder code. Browser exporter audit now has zero findings; broad inventory reports one remaining native Skia binary finding. Historical opaque artifact records are retained as retired, not cleared. Original Plex TTF inputs are hash-verified directly; actual embedded PDF font stream hashes are verified. Local 160 tests pass, zero skipped; six fresh procedural report pages visually reviewed. No native executable, owner imagery, registry publication or upstream messages. This issue remains open for exact Skia compiled-component inventory; full CI is linked in the PR.

### Comment by yigit-denktas at 2026-10-18T02:08:42Z (https://github.com/yigit-denktas/stipra/issues/14#issuecomment-6244570883)

Pinned native release rechecked in PR #99. The exact GitHub v3.0.8 release metadata has ten attachments: platform gzip binaries and Lambda ZIPs, with sizes/digests; none is a compiled-component inventory/notice bundle. licenses/third-party/native-release-observation.json records release/asset IDs and observation scope. No binary was downloaded/redistributed for this recheck. Historical source-review status is corrected to historical with current single-finding resolution recorded. No new clearance is claimed; native Skia remains the one broad-distribution finding.

### Comment by yigit-denktas at 2026-10-18T02:52:59Z (https://github.com/yigit-denktas/stipra/issues/14#issuecomment-6244917327)

PR #100 adds a concrete native source-candidate map. Verified eight source-file Git blob identities. Pinned chain: Skia Canvas 042312a → Rust Skia 0.88.0 / 38fd2e7 → Skia c4cecff; 13 DEPS external revisions. Cargo.lock has 318 entries/317 registry checksums, explicitly a build/optional/cross-platform superset. Linux patches local-path Rust Skia to statically link Fontconfig 2.17.1 from its container. FreeType 2.13.3 is a minimal bootstrap for that build, not the embedded Skia FreeType version. Tarball digests/toolchain/container packages remain unpinned. Recorded actual ELF build ID and eight DT_NEEDED entries, which cannot inventory static components. This narrows the required notice/build inventory without claiming it is complete. No native binary or upstream source code committed; current release gate remains open.

### Comment by yigit-denktas at 2026-10-18T02:54:16Z (https://github.com/yigit-denktas/stipra/issues/14#issuecomment-6244927071)

Prepared upstream request (not posted to upstream maintainers):

**Title:** Component and third-party notice inventory for v3.0.8 native binaries

**Draft body:**

We are reviewing a possible redistribution of skia-canvas's native dependency and want to retain the correct third-party notices. Could you point us to the component/notice inventory associated with the v3.0.8 Linux x64 glibc artifact, or confirm the source/build mapping for that artifact?

Artifact: linux-x64-glibc.gz (GitHub asset 297283999), published gzip SHA-256 f45925290599d4b7cb5211c123fadee27bc899d7556696e2e333d0efac6937b2. Our installed uncompressed skia.node is 30,457,832 bytes, SHA-256 2363537634644a50b69d785411713d12ae62453c1238bb98842e65b9919777f9, ELF build ID c4f6b6bc00c5815e4df7a4f5fce6df505d7e763b.

The v3.0.8 source points to Rust Skia 0.88.0, Skia submodule c4cecffab004be7a901f3dd486fc5d9c27e8261f and Linux's static Fontconfig patch. We can inventory the Cargo.lock superset and DEPS revisions, but these do not establish the exact platform/feature-selected components and notices in the published binary. In particular, the Linux workflow uses a moving container and local-path patched Rust Skia.

An existing notice bundle/SBOM, a platform-selected dependency/feature record, and an attributable link between this artifact and its build inputs would help. We are not alleging a license violation or requesting new rendering behavior; we want to package the relevant notices correctly. If no such record exists for this older release, is there a later release or documented build route that supplies it?

---
The owner authorized proceeding on 18 October 2026. The GitHub integration rejected issue creation upstream with HTTP 403, `Resource not accessible by integration`. No upstream issue, email or message has been sent. Posting this approved text now needs an authorized browser fallback; native clearance remains open.


## #17 — [Project] Configure native Stipra v0.9 milestone and GitHub Project

- state: closed / completed
- author: yigit-denktas; labels: ['enhancement']; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T20:38:00Z; closedAt: 2026-10-18T02:14:20Z; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/17

### Body

**Type:** Chore  
**Priority:** P1  
**Area:** Project operations  
**Target:** v0.9  
**Assignee:** @yigit-denktas  
**Dependencies:** Repository foundation #1 (complete)

## Why
Native tracking is now partly configured and verified through the owner's signed-in GitHub browser. Remaining view/automation checks are listed below.

## Work
- [x] Create a native GitHub milestone named `v0.9` in `yigit-denktas/stipra` and link the release criteria from `ROADMAP.md`.
- [x] Assign issues #2–#14 to the native milestone, retaining completed items.
- [x] Create a native GitHub Project named `Stipra` owned by the repository owner (unless an existing suitable Project is located first).
- [x] Attach all v0.9 backlog issues to the Project.
- [x] Add minimal work fields **Priority** and **Area** with the existing issue-body values; use native **Status** and avoid duplicating it. Agree on any additional fields before adding clutter.
- [x] Configure useful views: v0.9 board by status and backlog by priority; verify automation rules rather than assuming them.
- [x] Record the real milestone and Project URLs in `ROADMAP.md` and issue references. Do not invent them.

## Verification
- [x] Native milestone and Project URLs resolve for current Project collaborators — the access page lists only the owner, with Admin access; verified in that signed-in session. No broader collaborator access is claimed or granted.
- [x] Open vs closed issue counts match GitHub; direct issue fetch verifies 9 closed / 5 open among the original 14. This is issue closure, not estimated engineering completion.

## Actual configured objects

Milestone [v0.9](https://github.com/yigit-denktas/stipra/milestone/1) contains original issues #1–#14, including completed work. Reused the existing populated [private Stipra Project #3](https://github.com/users/yigit-denktas/projects/3); access/visibility unchanged. All 14 original items have Priority and Area values, native Status is reused, and stale #9 status was corrected to Done. #13/#14 are In review. [Saved v0.9 backlog view](https://github.com/users/yigit-denktas/projects/3/views/6) filters by repository/milestone and sorts Priority ascending, with Area/Priority visible.

The owner can resolve both objects. Collaborator access has not been independently tested. A duplicated View 7 is still a draft table, not the promised status board. Seven enabled workflows were observed, but their individual rules were not verified. The browser plugin then stalled on reload and tab listing; remaining board/rule checks stay open. No access settings changed. GitHub connector milestone assignments were verified for all 14 original issues; search normalization does not expose reliable issue states, so it was not used to claim closed counts.

Final browser retry reports no connected browser for the originating instance. No alternate browser/session was opened. Remaining board/workflow/collaborator-access checks require reconnecting the original authorized browser.

## Completed configuration — PR #99

Browser reconnected. Saved and renamed [v0.9 board](https://github.com/users/yigit-denktas/projects/3/views/7): Status columns, original milestone/repository filter, Priority ascending. The existing [v0.9 backlog](https://github.com/users/yigit-denktas/projects/3/views/6) is retained. All 11 workflow configurations were inspected; seven are enabled. Auto-add is scoped to stipra, `is:issue,pr is:open`; Done auto-closes an issue. The access page lists one collaborator, the owner with Admin; visibility remains private and no access/rules changed. Configuration observations and native URLs are in docs/PROJECT-TRACKING.md in #99. This supersedes the previous browser-blocker notes. No human/physical gate is closed by completing this administration. #99 closes this issue after its CI/merge.



## #18 — [Docs] Restore original SVG dotmark and native README typography

- state: closed / completed
- author: yigit-denktas; labels: ['bug']; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T20:44:21Z; closedAt: 2026-10-16T20:46:18Z; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/18

### Body

**Type:** Bug / Documentation
**Priority:** P1
**Area:** Branding / README
**Target:** Immediate, before image import #6

## Defect
The README currently embeds `assets/stipra-header.svg`, a generated full-bleed banner containing raster-like fixed-position copy, instead of composing text in the README around the owner's original `logo_for_Readme.svg`. This causes a conspicuously rigid, oversized black rectangle. The external GitHub issues count badge also currently shows a token-pool error on GitHub.

## Acceptance criteria
- [ ] `README.md` title `stipra`, `A programmable printmaking studio.`, `Stippling + strata: dots organized into layers.`, and `Separate the inks. Keep the imperfections.` are actual README text, not SVG text.
- [ ] Use `logo_for_Readme.svg` **directly** between subtitle and explanation, centered and responsive, respecting the GitHub theme. Original dotmark blob remains byte-identical.
- [ ] Remove the redundant flattened `assets/stipra-header.svg` file and avoid displaying the original dotmark twice.
- [ ] Replace the GitHub-API-dependent issues badge with a working static badge or text link to the native issue list.
- [ ] Keep engineering documentation and claims otherwise unchanged; confirm README link to source artwork resolves.
- [ ] Verify via branch/PR checks and merge to main; close this issue through the PR.

No work on image import #6 should be mixed into this branding fix.


## #21 — [Direction] Scope Stipra v0.9 as an MIT browser printmaking studio, not a p5.js clone

- state: closed / completed
- author: yigit-denktas; labels: ['documentation']; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T21:39:17Z; closedAt: 2026-10-16T21:43:42Z; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/21

### Body

## Product decision (16 October 2026)
**Stipra stays MIT and remains a small, independent, local-first browser printmaking/separation studio**, not a p5.js reimplementation or a general-purpose AI image generator. Preserve the implemented scene, importer, CLI, and Prehnite case study; finish a coherent v0.9 usable end to end.

Kuşluk integration is optional and must pass a comparison with direct p5.js/ImageMagick/native SVG/Canvas. Related: [Kuşluk #21](https://github.com/interzettel/kushluk/issues/21#issuecomment-6225189079), [Kuşluk #30](https://github.com/interzettel/kushluk/issues/30).

### Product contract / v0.9
- Browser: drop image or select a procedural artwork, choose **2–N distinct spot inks** or CMYK; real editable pixel coverage masks, thresholds and layer behavior—not mere recoloring.
- Visually inspect **source / separate plates / composite / substrate / overprint** at identical pixel origin, crop and scale. Distinguish digital Riso aesthetic from real press calibration.
- Local CLI: machine-readable recipe/seed/palette and safe repeatable import→separate→screen→plate→report→export/batch with meaningful errors.
- Produce aligned full-frame grayscale production plate masters, optional colored proof, print-ready A4 HTML/PDF separation *inspection* sheet, portable PNG/JPEG/WebP/SVG where genuine, recipe/manifests and ZIP.
- Respect DPI/print dimensions, transparency, rights attribution and original file. Have QA for browser/Node parity, determinism, plate alignment, no-clipping, accessibility and output provenance.
- Keep the existing deterministic scene/plate abstraction as an internal contract, **not** a required custom p5.js-compatible language.
- Keep the sample color separation image only as design reference unless distribution rights permit bundling.

### What NOT to build for this v0.9
- No general AI image generation, centralized image storage, arbitrary remote execution, p5.js clone, hosted workflow platform, or mandatory p5.js dependency.
- No unnecessary replications of advanced ImageMagick/p5.js functions. Use genuinely license-compatible dependencies when they reduce maintenance.
- Prehnite-specific gem seam repairs (#3) and elaborate paper fibers/debris (#4) are **optional case-study polish**, not blockers for imported-image separation or a usable app.
- No claims of calibrated spectral Riso color/dot gain before physical measurements.
- **Do not fork, vendor, or mechanically translate/rewrite p5.riso into MIT.** Document its restrictive Anti-Capitalist License, study general publicly documented algorithms and standards, write independent original implementation with provenance and tests. Conduct a component/license audit (#14) before release; seek counsel for commercial distribution if uncertain.

### Priority order (dependencies updated separately)
1. #7 spot/CMYK **coverage mask separation** on top of completed #6 (can initially run without halftoning).
2. #5 apply independent dot/line/reverse screens to existing masks; do not warp layer geometry.
3. #8 aligned monochrome masters, registration and truthful metadata.
4. #9 A4 HTML/PDF separation report following approved reference.
5. #11/#12 same recipe in browser and CLI; batch and export packages.
6. #13/#14 QA and licensing release gates; #10 diagnostics scoped to actionable masks and optional after v0.9.
7. #3/#4 should not block the first integrated demo.

### Acceptance proof
An ordinary user and an agent both take the same rights-cleared raster image, choose two spot inks, change actual mask parameters, preview each plate/overprint, and produce a matching A4 separation sheet, identical-size masters and a reproducible manifest without paid services. Test CMYK and 3+ colors, small text/high contrast, output size, safety and malformed assets. **The acceptance checkboxes supplied by the owner are test definitions, not tests already run.**

Closing this *decision issue* requires publishing a concise roadmap and legal-provenance policy, not pretending product implementation is finished.


## #22 — [Studio] Browser workspace for editable separations, plates and A4 export

- state: closed / completed
- author: yigit-denktas; labels: ['enhancement']; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T21:41:32Z; closedAt: 2026-10-17T16:22:27Z; comments: 7
- url: https://github.com/yigit-denktas/stipra/issues/22

### Body

**Type:** Feature · **Priority:** P0 · **Area:** Browser UX · **Target:** v0.9
**Dependencies:** #6 (completed), #7 (actual coverage masks), #5 (screening for selectable output modes). Related #8, #9, #11, #12, #13.
**Product decision:** #21 · [Roadmap](../blob/main/ROADMAP.md)

## User journey
An artist should not need to write JavaScript. Upload a PNG/JPEG/WebP or supported SVG in a local browser; choose a real 2–N spot or CMYK separation recipe; adjust individual **coverage masks** and screen settings; inspect the source, colored proof, paper-only background and one aligned monochrome plate per ink. Then export masters, the A4 HTML/PDF inspection sheet, the recipe and ZIP package. The current import-only inspector is a foundation, not this workspace.

## Acceptance criteria
- [x] Clean responsive single-workspace import → ink choice → edit → inspect → export flow; accessible labels, keyboard use, contrast and loading/invalid-file states.
- [x] Accurate source aspect/origin, DPI/trim/bleed indication, zoom-to-100%; edits to any mask visibly change the plate, not just its preview color.
- [x] Solo/mute/overprint and paper toggles; 2/3/4+ inks with consistent plate order and same frame dimensions; no component reflow.
- [x] Controls expose thresholds/transfer curves/ink mapping, screen frequency/angles/shape/density and stable seeds *when supported by the engine*; warn on unsupported or out-of-gamut settings rather than bluff.
- [x] Browser uses the same validated recipe/output model as local CLI and doesn't execute untrusted user JavaScript.
- [x] Exports integrate #8, #9, #12; opening the generated separation sheet visibly agrees with its independent plates.
- [x] Local browser smoke, golden samples, responsive regression, accessibility and no-network processing tests.

**Do not build:** a general p5.js IDE, an image-generation model, remote cloud service, arbitrary plugin marketplace or physical Riso color calibration.

**Evidence:** attach a rights-cleared before/after two-ink sample, plate comparisons and exported sheet; record actual browser/CLI parity and performance.

## Completion evidence — #91

Merged follow-through: #91; exact final CI 39048870910 passed on 5e7163a6edc1bfd06edba3ee78e3bb75eb86b46c. 146 Node tests passed, zero skipped. Real Chromium checks covered image/color boundaries, real mask edits, solo/mute/paper/native pixel zoom, 2–8 inks, supported screen controls, keyboard focus/labels, five workspace widths, responsive information pages and marked export pixels/hashes/DPI/PDF recipes. Browser/Node/CLI alpha and named-region replay, real local C2PA fixtures, color references and QR verification passed. Workflow capture recorded zero external processing requests; desktop/mobile studio, roadmap, changelog and sitemap screenshots were reviewed.

README/ROADMAP, docs/STUDIO-WORKFLOW.md and docs/data/delivery-ledger.json preserve scope, version gates and branch reconciliation. Reports #9 are reconciled; #83–#86 were completed in #89. #14 remains open with three exact binary/prebundle provenance findings; publication #70, physical observations #13 and final identity remain separate. No owner photographs or external binaries were committed.


### Comment by yigit-denktas at 2026-10-16T22:05:45Z (https://github.com/yigit-denktas/stipra/issues/22#issuecomment-6225596168)

## Image-to-ink engine handoff (after #7)

The working continuous-tone image separation lab now lives at [`examples/separation-lab/`](https://github.com/yigit-denktas/stipra/tree/main/examples/separation-lab) with shared pure JS `src/separation.js`, two spot inks or CMYK, ink controls, actual grayscale plate previews, simulated multiply proof, per-ink coverage and local PNG/recipe downloads. The CLI `stipra separate --input ... --config ... --out ...` exports full-frame plates plus source/manifest. [PR #26](https://github.com/yigit-denktas/stipra/pull/26) is merged and Chromium browser interactions pass.

This is a **foundation** for #22, not a finished production workspace: unify with image importing, add source/plate show/solo/overprint, DPI/trim/registration inspection, screening controls from #5, A4 report from #9, complete bundles #12, keyboard/mobile QA, and documented agent reproducibility #11. Don't duplicate mask math in UI components.

### Comment by yigit-denktas at 2026-10-16T22:25:42Z (https://github.com/yigit-denktas/stipra/issues/22#issuecomment-6225861515)

## Browser work made progress; unified studio still open

[PR #27](https://github.com/yigit-denktas/stipra/pull/27) added working live screen controls to `examples/separation-lab`: positive dots, reverse paper knockouts, lines, hybrid and paper-only; global seed/pitch/angle/jitter and independent ink angles/registration, plus a separate downloadable screen recipe. Node/browser parity and an actual Chromium edit→plate-change smoke pass. This is **not** closure of #22.

Next #22 needs an end-to-end workspace, optional paper/plate solo, mobile and keyboard accessibility, physical print resolution/trim warnings, non-blocking large-image processing, reliable export packages and integration with #8/#9. Reuse shared `src/separation.js` and `src/screening.js`; no duplicated pixel mapping in the UI.

### Comment by yigit-denktas at 2026-10-16T22:50:44Z (https://github.com/yigit-denktas/stipra/issues/22#issuecomment-6226168553)

## Planned studio dependency: single shared style resolver (#34)

Owner wants usable defaults for **both browser and AI CLI**, not a giant slider wall. [#34](https://github.com/yigit-denktas/stipra/issues/34) proposes declarative input-aware Risograph style recipes that normalize to existing #7 separation and #5 screening schemas, with usage rules, warnings, output size/DPI and provenance.

When building #22, the main flow should be source → style suggestion/selection → large original/overprint compare → ink plates. Keep per-ink adjustments in **Advanced**, without duplicating preset logic in the browser and CLI. Give a neutral fallback and retain the raw original. This is a planning dependency, not a completion claim or an authorization to redesign #31.

### Comment by yigit-denktas at 2026-10-16T22:59:10Z (https://github.com/yigit-denktas/stipra/issues/22#issuecomment-6226268214)

## Research addition: two legitimate input paths and active-layer proof

[Printing knowledge portal](https://github.com/yigit-denktas/stipra/blob/main/docs/references/README.md) and [Dizzy Ink field notes](https://github.com/yigit-denktas/stipra/blob/main/docs/references/DIZZY-INK.md) merged in [PR #36](https://github.com/yigit-denktas/stipra/pull/36).

The eventual workspace should accept either (A) full-color source → Stipra's #7/#5 auto separations **or** (B) **already prepared aligned grayscale ink masters** → color assignment and proof, without destructive re-separation. Both should share solo/mute, active layer, substrate, overprint, screen settings, export and original provenance. Require exact same dimensions/origin for imported masters; no silent scale/rotation. Style defaults/warnings proposed in #34, not implemented. See rules R01, R05, R09.

### Comment by yigit-denktas at 2026-10-16T23:07:50Z (https://github.com/yigit-denktas/stipra/issues/22#issuecomment-6226368751)

## Stipra's human/agent design rules are now consolidated

[PR #38](https://github.com/yigit-denktas/stipra/pull/38) adds root [DESIGN.md](https://github.com/yigit-denktas/stipra/blob/main/DESIGN.md) and [picture-guide field notes](https://github.com/yigit-denktas/stipra/blob/main/docs/references/DIZZY-INK-VISUALS.md). Keep source → layers → proof as the workspace's perceptual hierarchy, ink controls contextual and selection-driven, paper separate, with automatic separation **and**, in a later milestone, user-prepared grayscale plates. This is design guidance, not approval for an additional immediate UI overhaul; visual direction remains to be decided in #31.

README was shortened 63%; detailed setup moved to [docs/GETTING-STARTED.md](https://github.com/yigit-denktas/stipra/blob/main/docs/GETTING-STARTED.md). Avoid restoring implementation matrices into the repository entrance.

### Comment by yigit-denktas at 2026-10-17T00:45:03Z (https://github.com/yigit-denktas/stipra/issues/22#issuecomment-6227517702)

## Integrated browser Styles controls available, larger studio redesign unapproved

Merged [PR #50](https://github.com/yigit-denktas/stipra/pull/50): browser now has an *experimental starting style* chooser backed by the same [src/styles.js](https://github.com/yigit-denktas/stipra/blob/main/src/styles.js) as the CLI. It updates ink and screen settings, retains all manual per-ink options and exposes intended use. Existing Node and Chromium smoke tests passed.

This is **not** the planned one dominant proof + ink strip + progressive tools redesign. Continue UX discussion #31 and owner review before changing the overall layout.

### Comment by yigit-denktas at 2026-10-17T13:15:50Z (https://github.com/yigit-denktas/stipra/issues/22#issuecomment-6234324692)

PR #69 advances the studio's source → style → inspect → export workflow. Browser Print package ZIP uses the same report/package code as CLI; keeps original bytes, native masks, zero-offset production masters, separately shifted proof, normalized recipes, SHA-256 manifest and embedded PDF settings. Runtime image encoders/decoders may differ; identical ZIP bytes across browser and Skia are not claimed. Browser export currently uses recipe paper and no added marks, while CLI retains extra stock/marks controls. Docs: STUDIO-EXPORT.md.

Actual download inspection is covered in the real browser smoke, including master pixels, DPI, hashes and PDF attachments. Shared guide/lab styling and physical-check kit are included. This does not close broader studio acceptance, ICC policy or physical print gates.


## #24 — [Docs] Rewrite README around Stipra's user experience and honest v0.9 roadmap

- state: closed / completed
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T21:48:21Z; closedAt: 2026-10-16T21:51:24Z; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/24

### Body

## Goal
Replace the documentation-heavy repository entrance with a warm, readable introduction to Stipra as a small local-first printmaking studio.

## Keep unchanged
- Native `<h1>stipra</h1>` title, short studio subtitle, original `logo_for_Readme.svg` artwork (unaltered), dotmark caption, strapline, and all five current badges.

## Rewrite
- Open with the human purpose of separations and visual layering, not an engineering status report.
- Put the working browser demos and exact CLI commands upfront.
- Distinguish working Prehnite case study / deterministic SVG plates / secure image importer from **planned** spot/CMYK auto-separation, masks, screens, A4 report, ZIP and full browser studio.
- Explain why the ink/paper/layer model matters; keep p5.js and licensing honest without turning the README into a legal memo.
- Link to the detailed [ROADMAP.md](../blob/main/ROADMAP.md), technical specs and contributing docs; remove redundant backlog tables and repeated disclaimers.
- Make the Markdown readable in GitHub light/dark mode, mobile widths and plain text. No generated header/banner or stock art.

## Acceptance
- [ ] Original dotmark and badge invariants verified by automated tests.
- [ ] Every linked local file/CLI command checked against the repo.
- [ ] CI passes on PR; merge when green.
- [ ] Only documentation and relevant README tests change.


## #28 — [Vector screens] Dot-native SVG facets and analytic vector mask parity

- state: open / None
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T22:20:24Z; closedAt: None; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/28

### Body

**Source:** separated from the original broad #5 acceptance. **Priority:** P1 · **Target:** after raster screening and prepress export stabilize.

## Why separate
Issue #5 delivers deterministic raster screening of **imported-image ink coverage masks** and per-plate registration. Its original geometry-specific promise—independently editable Prehnite facets and true-vector SVG halftone masters—requires a different representation and should not be silently marked implemented by a raster PNG exporter.

## Scope
- [ ] Support positive dots, reverse paper knockouts, solid and hybrid modes as true SVG/path geometry for **supported vector scene layers**, without tracing arbitrary photographs.
- [ ] Control facet-level angle, pitch, density, dot size, seed, jitter and per-ink registration separately from the underlying scene geometry.
- [ ] Shared facet seams remain straight and matched; vary screening without changing the canvas bounds or warping source shapes.
- [ ] Clip screen primitives analytically to their layer/facet. Keep substrate out of physical plate exports.
- [ ] Pixel-rasterize equivalent screen recipes as an acceptance comparison against raster #5 where semantics can be made equivalent; document expected analytic versus pixel-antialias differences.
- [ ] Produce an aligned, proper-resolution SVG master/preview for each vector ink, with source recipe, provenance, CI fixtures and actual print-geometry samples.

Not required for importing raster PNG/JPEG/WebP or completing #9 A4 reports; don't claim arbitrary raster becomes a true vector master.

Related: [#2 vector scene](https://github.com/yigit-denktas/stipra/issues/2), [#5 raster screening](https://github.com/yigit-denktas/stipra/issues/5), [#8 prepress](https://github.com/yigit-denktas/stipra/issues/8), [#3 case-study seams](https://github.com/yigit-denktas/stipra/issues/3).


## #29 — [Deploy] Publish Separation Lab on apps.yigitdenktas.com/stipra via Cloudflare Pages

- state: closed / completed
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T22:31:16Z; closedAt: 2026-10-16T22:34:59Z; comments: 1
- url: https://github.com/yigit-denktas/stipra/issues/29

### Body

Deploy the existing (not redesigned) Stipra Separation Lab to Cloudflare Pages under https://apps.yigitdenktas.com/stipra/.

Acceptance:
- [ ] Host a build artifact in Pages, generated from source without committing dist HTML or duplicate compiled site trees.
- [ ] Isolate project from the production personal website and keep existing hosting unchanged.
- [ ] Keep one canonical app source under web/stipra; remove obsolete examples/separation-lab page duplicates, with Chromium coverage migrated.
- [ ] Deploy under subpath /stipra/ with self-contained relative asset URLs, client-only processing, CSP/no external uploads.
- [ ] Ensure public URL is live before adding it as the primary README link; CI validates package and browser interactions.
- [ ] Do not redesign visual style before owner review; create a separate design discussion tracking issue.

If GitHub integration or custom domain binding is blocked, report the blocker rather than claim the target URL is live.

### Comment by yigit-denktas at 2026-10-16T22:38:11Z (https://github.com/yigit-denktas/stipra/issues/29#issuecomment-6226017476)

## Verified Cloudflare Pages deployment (2026-10-17)

**LIVE:** https://apps.yigitdenktas.com/stipra/

- Cloudflare Pages project: `yigitdenktas-apps` · GitHub source `yigit-denktas/stipra` `main` · build `npm run build:pages` · publish directory `dist`.
- First production deployment `1f0a7576-edb9-4be5-9b14-4bcd12b0400b` completed build and deployment stages with `success`; deploy preview `https://1f0a7576.yigitdenktas-apps.pages.dev/stipra/`.
- Custom domain `apps.yigitdenktas.com` CNAME points to `yigitdenktas-apps.pages.dev`, proxied. Cloudflare Pages domain status and certificate validation report `active`.
- Independently fetched both canonical and Pages-dev URLs and confirmed the HTML title `Stipra · Color separation lab` and expected ink-separation introduction load at `/stipra/`.
- [PR #30](https://github.com/yigit-denktas/stipra/pull/30) merged with passed Node, build, importer Chromium, and separation Chromium smoke checks. Generated `dist/` is ignored; `examples/separation-lab/` duplicates were deleted. Source and smoke tests moved to `web/stipra/`.
- README links to live custom domain; existing UI intentionally unchanged until design consultation.

No changes to the authoritative main website Pages project; the apps host is separate.


## #31 — [Design] Redesign hosted Stipra workspace after owner review

- state: open / None
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T22:38:09Z; closedAt: None; comments: 12
- url: https://github.com/yigit-denktas/stipra/issues/31

### Body

## Status: design discussion needed — do not implement styling before review

**Live baseline:** https://apps.yigitdenktas.com/stipra/
**Canonical source:** `web/stipra/index.html` and `web/stipra/app.js` (Cloudflare Pages auto-builds to ignored `dist/stipra/`).

Keep the functioning image → ink separation → screening → plate preview/export journey, but treat the current UI as a functional prototype, not approved product design.

Topics to discuss with owner before any mockup/code:
- Visual tone and brand relationship to existing Stipra SVG dotmark and printmaking identity.
- Tool-first workspace hierarchy: image preview/composite vs ink plates, desktop/mobile behavior, tool grouping and batch/agent affordances.
- Progressive disclosure of advanced parameters (CMYK, match radius, screening angle/pitch, registration, ink coverage).
- Light/dark color strategy, accessibility/keyboard flow, typography and interaction quality.
- Real-time rendering performance, predictable loading/error states, preview fidelity, and printable scale warnings.
- Design references selected by owner; no invented generic dashboards, ornamental AI-generated artwork or redesign without agreement.

Acceptance: agree on a compact design brief and annotated visual direction, create tested layout iterations, do mobile/desktop browser reviews with owner, then merge. **No interface redesign included in PR #30.**

### Comment by yigit-denktas at 2026-10-16T22:46:04Z (https://github.com/yigit-denktas/stipra/issues/31#issuecomment-6226113108)

## Layout fix shipped; broader style review still open (2026-10-17)

Owner shared a screenshot showing CMYK inspector controls invading the plate preview grid and equal-weight imagery. [PR #33](https://github.com/yigit-denktas/stipra/pull/33) merged and deployed on [Stipra Pages](https://apps.yigitdenktas.com/stipra/) with **layout only**: input moved into header, source+composite promoted as large top-row artwork, individual plates moved into a dedicated gallery, and the right-side inspector has collapsible per-ink settings and advanced screening. Desktop/tablet/mobile tests validate no overlap/overflow at 390,768,1024,1339,1440 px, with original Chromium pixel smoke unchanged.

**Still to discuss with owner:** visual identity, typography, color/background, palette/filter organization, where active-plate editing belongs, and deeper UX flows. Do not mistake the quick placement fix for an approved aesthetic redesign.

### Comment by yigit-denktas at 2026-10-16T22:50:43Z (https://github.com/yigit-denktas/stipra/issues/31#issuecomment-6226168190)

## Design direction: styles before sliders (discussion, not implementation)

Owner's framing: **“The algorithm defines what's possible; the design rules determine what's desirable.”** A professional-looking layout still won't help if default mask/ink/screen combinations ruin the artwork. [#34 — Stipra Styles](https://github.com/yigit-denktas/stipra/issues/34) is the proposed next design dependency: a few authored, input-aware Riso recipes with explicit suitable/unsuitable cases, protective design constraints, honest print warnings and the exact same resolved parameters in browser and CLI.

**Suggested UI hierarchy:** source image → input intent → 3–4 relevant *previewed* style cards (with a neutral baseline) → simple ink/intensity/detail controls → advanced per-plate ink masks, pitch/angle/jitter/registration in disclosure. Don't hide full power, but don't make novices solve four CMYK panels to get a good first result. No aesthetic redesign until the owner reviews style direction and visual references.

Important implementation caveats: existing default spot recipes use simplistic match/darkness channels; those aren't intelligently tuned to arbitrary portrait/illustration data. Existing pitch is **pixels**, so appearance changes with output resolution unless print units are introduced. Separate *simulated* press imperfections from physical production plate registration. See #34 for acceptance and sources.

### Comment by yigit-denktas at 2026-10-16T22:59:07Z (https://github.com/yigit-denktas/stipra/issues/31#issuecomment-6226267746)

## UI art-direction research from Dizzy Ink (not a redesign approval)

Reviewed [Dizzy Ink's color proof tool](https://risograph.co.uk/10-riso-proof-tool) and related print guide. Our [field notes](https://github.com/yigit-denktas/stipra/blob/main/docs/references/DIZZY-INK.md) / [R09 UI rule](https://github.com/yigit-denktas/stipra/blob/main/docs/PRINT-DESIGN-RULES.md) emphasize **one central proof, an active ink/layer, named spots, proof-only registration in mm, and advanced controls per selected ink**. The tool also supports uploading already separated grayscale masters, an alternative worth considering next to automatic separation.

The opportunity isn't to copy Dizzy Ink's visual design. It is to **let the composition dominate** while teaching the physical ink model through contextual controls. Propose intent/style selection before the slider wall, plus a neutral original state. Continue owner discussion about aesthetic balance and one-canvas vs split compare; no art direction has been approved or deployed.

### Comment by yigit-denktas at 2026-10-16T23:07:46Z (https://github.com/yigit-denktas/stipra/issues/31#issuecomment-6226367901)

## Design brief and image-based references now live (2026-10-17)

[PR #38](https://github.com/yigit-denktas/stipra/pull/38) merged a single root [DESIGN.md](https://github.com/yigit-denktas/stipra/blob/main/DESIGN.md) summarizing the studio hierarchy, editable ink-layer model, style defaults, digital-versus-physical output distinctions, browser/CLI parity and unresolved UI decisions. The user highlighted the striking graphics on [Dizzy Ink's illustrated guide](https://www.dizzyink.co.uk/guide-to-risograph); our [original, source-linked visual study](https://github.com/yigit-denktas/stipra/blob/main/docs/references/DIZZY-INK-VISUALS.md) examines individual plate files → composite, translucent ink overlaps, unconventional four-color separations, and varying ink density. No original images are copied into the repo.

**Next owner discussion remains open:** split original/print proof vs one large active canvas, active ink strip, simple style cards, and progressive advanced controls. Research informs choices but is not an approved visual redesign. README stays small; use DESIGN and R01–R10 rules for engineering decisions.

### Comment by yigit-denktas at 2026-10-17T00:45:05Z (https://github.com/yigit-denktas/stipra/issues/31#issuecomment-6227518112)

## Status: report visual language implemented; studio design still requires choice

[PR #48](https://github.com/yigit-denktas/stipra/pull/48) introduced portrait-aware A4 sheets, flat IBM Plex typography, actual procedural paper texture, embedded JSON recipes and QR-to-documentation. [PR #49](https://github.com/yigit-denktas/stipra/pull/49) added a procedural layered mark candidate generated through actual Stiprā vector scene plates (kept original README dotmark). [PR #50](https://github.com/yigit-denktas/stipra/pull/50) added a browser style selector without changing workspace hierarchy.

The **studio** redesign remains pending user judgment: artwork-first single active canvas vs source/proof split, contextual selected-ink inspector, comparison of identical source under competing presets, responsive layout and accessibility; do not declare finished.

### Comment by yigit-denktas at 2026-10-17T00:58:27Z (https://github.com/yigit-denktas/stipra/issues/31#issuecomment-6227667386)

## Procedural identity revised, aesthetic decision still open

Owner rejected the initial generated dot mark as unbalanced. [PR #51](https://github.com/yigit-denktas/stipra/pull/51) rebuilt it geometry-first, with four comparison outputs, strict monochrome fallback, a controlled two-ink overlap and reproducible native SVG plates. [See brand study](https://github.com/yigit-denktas/stipra/blob/main/docs/BRAND-STUDY.md). Original README logo remains unchanged. Do not incorporate the new mark into the redesigned studio until the owner chooses it; report/PDF IBM Plex typography remains separate work.

### Comment by yigit-denktas at 2026-10-17T01:18:47Z (https://github.com/yigit-denktas/stipra/issues/31#issuecomment-6227867278)

## typography design comparison available — pr #53

wordmark-first [ibm plex vs paper mono study](https://apps.yigitdenktas.com/stipra/typography/) is live, with actual lowercase ā outlines, plain/two-ink examples, and same-composition a4 comparison pdfs. the previous standalone s is not the recommended brand direction. fonts are sil ofl 1.1, pinned official font files used at build time, no generated-image references. studio interface layout decision remains separate and unapproved.

### Comment by yigit-denktas at 2026-10-17T10:05:00Z (https://github.com/yigit-denktas/stipra/issues/31#issuecomment-6232616470)

### Identity status and owner decision

The prior S-only variants remain historical. Work now has [three authentic full-wordmark candidates in PR #59](https://github.com/yigit-denktas/stipra/pull/59), under [brand study](https://github.com/yigit-denktas/stipra/blob/feat/wordmark-identity-study-v2/docs/BRAND-IDENTITY-STUDY-v2.md); Paper Mono SemiBold is a real OFL upstream release weight. The demonstration uses original owner dot rows as a separate companion, and limits coral to only the macron. Review actual SVG at 24, 48, 96px and printed before adopting. Do not alter original README logo or use the rejected abstract S as primary. Next UI discussion should use artwork-first hierarchy and the *eventually selected* typographic system.

### Comment by yigit-denktas at 2026-10-17T13:15:49Z (https://github.com/yigit-denktas/stipra/issues/31#issuecomment-6234324478)

The owner explicitly requested guide/lab visual alignment in this session. PR #69 applies the existing guide direction to the lab through shared CSS: authentic Plex fonts, original four-color identity, warm dotted substrate, sharp rules, focus outlines and lowercase stiprā. Preserves the existing source/proof/plate arrangement and progressive advanced controls; no new symbol or generated artwork. Original owner SVG unchanged.

Built preview reviewed in the connected browser; responsive geometry remains covered by the browser suite. Shared package export now replaces multiple loose plate downloads, and invalid settings disable export. UI review caught native range initialization rounding; controls now set constraints before values and the smoke verifies displayed gamma/gain/threshold against each recipe.

Preview: https://feat-13-studio-export-harden.yigitdenktas-apps.pages.dev/stipra/ . PR #69 remains unmerged for owner review. This advances visual consistency without claiming final brand or broader interaction acceptance.

### Comment by yigit-denktas at 2026-10-19T09:19:46Z (https://github.com/yigit-denktas/stipra/issues/31#issuecomment-6263890794)

Owner-authorized bounded Studio usability follow-up is in #111. The concrete friction is locating a plate’s matching collapsed ink settings, particularly below the artwork on phones. Each plate now has a named adjustment button that opens/focuses/scrolls to its existing controls, without changing recipe, inspection state or pixels.

The browser workflow checks dynamic targets for eight manual inks, CMYK and shared Styles, visible focus destinations at five viewport widths, and unchanged artwork before continuing through package validation. Node checks pass; exact-head browser CI is running. This does not resolve the broader workspace/identity design choices in this issue, and it is agent/automated evidence rather than an independent human trial.

### Comment by yigit-denktas at 2026-10-19T09:24:10Z (https://github.com/yigit-denktas/stipra/issues/31#issuecomment-6263972570)

The bounded plate-to-ink navigation improvement is merged in #111 as `e45d4c69cc6ff987b0896d6892a231a808b13a8d`. Exact PR head `e9102837` passed all 75 verification steps and the separate public-page review workflow. Desktop/phone screenshots were visually inspected; the browser workflow verifies that the matching ink summary becomes visible and focused while all artwork pixels stay unchanged, then validates the actual exported package.

README, ROADMAP, the Studio workflow contract and the public development history were reconciled. The current workspace composition and advanced controls remain. This issue stays open for the broader owner-directed design work; independent artist/accessibility and physical acceptance remain separate.

### Comment by yigit-denktas at 2026-10-19T10:37:26Z (https://github.com/yigit-denktas/stipra/issues/31#issuecomment-6265274519)

Owner-authorized recipe comparison and Studio/guide alignment is merged in #115 as `7cb3605c181488c38d9574e37c131841ebc47d1e`. Exact head `06f6fbb0` passed all 75 verification steps (run 39238111387), the separate public-page review and all 189 Node tests locally. Desktop/phone Studio comparison and guide screenshots were visually reviewed.

Current/candidate full proofs share source framing, current paper, DPI and seed. Preview preserves current edits/inspection/exports; Keep current retains them, Use candidate explicitly applies the displayed recipe and updates advanced controls. Setting/source changes invalidate stale comparisons. The browser verifies exact adopted pixels and the exported package. The guide now uses the same labels and explanations.

The owner’s supplied digital forest/beach specimen approval is recorded in docs/OWNER-VISUAL-APPROVAL-2026-10-19.md and #43/#47. Physical prints and independent artist testing are deferred, not passed. This does not settle every broader workspace/identity design choice; #31 remains open.


## #32 — [UI] Fix overlapping sidebar and artwork hierarchy on deployed Separation Lab

- state: closed / completed
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T22:42:47Z; closedAt: 2026-10-16T22:45:30Z; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/32

### Body

Owner screenshot 2026-10-17 shows a severe layout issue: a long narrow left control rail overlaps the artwork gallery, original/proof are the same scale as individual CMYK masks, and control forms dominate the page.

**Scope: placement / information architecture only.** Preserve the current visual style, brand and all separation/screening functionality; reserve a comprehensive visual redesign for #31 and discussion with the owner.

Acceptance:
- [ ] Desktop: original + overprint prominent side-by-side in a flexible workspace; physical ink masks grouped separately in responsive thumbnails; settings are in a width-constrained inspector on the right.
- [ ] Input/upload reachable without forcing file input into a too-narrow sidebar; long filenames cannot force grid overflow.
- [ ] Individual ink controls use accessible collapsible sections; advanced screening/registration is progressively disclosed, export always findable.
- [ ] At 390px, 768px, 1024px, 1440px no horizontal overlap or horizontal page scrolling; dark and light mode, keyboard access preserved.
- [ ] Same canvas dimensions/plate data/exports and all existing Chromium smoke remain green; add automated DOM/layout coverage.
- [ ] Publish automatically on apps.yigitdenktas.com/stipra/ after CI. No unapproved color/brand redesign or print algorithm changes.

Related to the broader design decision #31.


## #34 — [Styles] Opinionated, input-aware Risograph presets for browser and agent CLI

- state: open / None
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T22:50:20Z; closedAt: None; comments: 7
- url: https://github.com/yigit-denktas/stipra/issues/34

### Body

## Product proposal — *Stipra Styles*: image-aware recipes, not a drawer of arbitrary sliders

**Status:** design proposal for owner review; no implementation or styling approved yet.
**Related:** [#31 workspace design](https://github.com/yigit-denktas/stipra/issues/31), [#22 browser studio](https://github.com/yigit-denktas/stipra/issues/22), [#7 actual ink masks](https://github.com/yigit-denktas/stipra/issues/7), [#5 screening](https://github.com/yigit-denktas/stipra/issues/5), [#11 agent CLI](https://github.com/yigit-denktas/stipra/issues/11), [#13 QA](https://github.com/yigit-denktas/stipra/issues/13), [#8 preflight](https://github.com/yigit-denktas/stipra/issues/8).

**Design principle (owner):** *The algorithm defines what's possible; the design rules determine what's desirable.* A preset must declare **who it works for, when it should not be used, which ink topology and masks it needs, what it protects, and how it is evaluated**. Don't simply save today's UI slider states and call them a style.

### Proposed initial families (not promises of completed fidelity)

| Style | Intended input | Separation and screening direction | Preserve / avoid |
| --- | --- | --- | --- |
| **Portrait duotone** | portraits, tonal photographs | 2 inks: coherent light/mid/shadow mapping; fine or adaptive dots and deliberate soft overprint | keep facial detail and highlight/shadow range; avoid crude RGB-color-distance matching |
| **Editorial halftone** | photographs / small newspaper illustrations | 1 dark key + 1 restrained accent; detail-conscious tonal treatment, limited coverage | legibility at target physical size; protect text and diagrams |
| **Bold spot poster** | silhouettes, flat graphics, bold collage | 2–3 strongly contrasted inks, posterized tone regions, controlled coarse dots/overprint | recognizability; no excessive muddy multi-ink coverage |
| **Clean linework** | drawings, black-and-white diagrams, lettering | strong solid key plate, sparse optional tint, none/minimal screen | preserve thin edges and fine type; no automatic misregistration |
| **Faux-CMYK** *(later / experimental)* | broad-color photographic reproduction | 4 aligned CMYK coverage masks + distinct screen angles | label as approximation, never claim calibrated Riso color match |
| **Photocopy zine** *(later / experimental)* | textures, collage | controlled contrast/noise/rough marks and occasional reverse screen | needs true grain/texture behavior before release; not pretend present algorithm makes it |

### Implementation / guardrails

1. **One versioned style contract** stored as human-readable data, with authored `id`, name, intent, allowed input types, good/bad examples, selection rules, ink palette, substrate, separation recipe, screening recipe, print intent, limits, provenance, stable seed and a list of editable controls. No code evaluation, runtime plugins or p5.js clone.
2. **Same resolver in browser + CLI**: `style preset + input characteristics + declared size/DPI + user overrides → normalized existing #7/#5 recipes`. It must reproduce across runtimes and report all resolved parameters, not silently retune a saved recipe.
3. **No fake semantic knowledge.** Start with an explicit user/agent input category (portrait/photo/linework/poster) plus deterministic image analysis (histogram, tonal range, edge fraction, alpha, ink mask coverage). Never claim to detect protected faces/text/artwork semantics without an actual verified method. No paid model or API required.
4. **Safe defaults and explainable warnings**: source tonal clipping; nearly empty/saturated plates; lost edge contrast; excessively dense overprint; out-of-frame registration; tiny or too-coarse halftones at target size; physically unprintable gradients. Treat shop-specific coverage caps as configurable guidance, not universal law.
5. **Physical units, not just pixels.** The existing screen pitch is in pixels; 12px at 300 DPI is 25 lines/inch and is a deliberately coarse effect, not an inherently authentic press profile. Style recipes should declare physical intent (`lpi`, dimensions/DPI, or clearly `digital-only`) and resolve pixel pitch only for output. Do not silently change appearance if output resolution changes.
6. **Don't bake simulated press mistakes into every production master.** Separate optional *digital proof* misregistration/grain from geometry/registration of actual aligned plate exports; real hardware adds its own mechanical registration error.
7. **Progressive UI**: import → choose intent/style using visual comparison → simple intensity/ink/paper controls → **Advanced** per-ink mask and screen settings. Preserve access to every existing knob; do not expose all of them by default.
8. **Agent CLI** (illustrative, **not currently implemented**): `stipra styles list`, `stipra styles explain portrait-duotone`, `stipra separate --style portrait-duotone --input art.png --dpi 300 --out ...`, plus explicit overrides and resolved recipe/manifest exports. No two different implementations of a style.
9. **Validation**: 4+ rights-cleared fixtures (portrait, collage/poster, text-heavy illustration, small editorial photo), intentional golden variants, browser/CLI parity, same settings at two resolutions with equivalent physical screening, mask-source alignment, before/after comparisons and *human art direction review*. A mathematical quality metric cannot certify that a style is attractive.

### Research basis / inspiration (do not copy assets, trademarked artwork, implementation code)

- Real printer guidance: [Out of the Blueprint print guide](https://outoftheblueprint.org/files/) on independent plates, halftones, paper and coverage; [Kaki Press](https://kakipress.uk/riso-print-guide/) on ink opacity and manual registration.
- [Dizzy Ink profiles](https://risograph.co.uk/04-risograph-profiles) show that many recognizable looks come from specific ink pairs/triples and channel choices; [their proof tool](https://risograph.co.uk/10-riso-proof-tool) allows layer-specific proofing.
- [Spectrolite opacity guide](https://spectrolite.app/how-to/color/opacity) shows why adjustable post-separation ink density matters in actual printing.

**Do not redesign page visuals or implement any preset family before reviewing and agreeing on the small starter set with the owner.** Keep MIT-authored implementation, provenance and licensing policy (#14).

## 19 October acceptance follow-up — merged PR #110

The 19 October private review reproduces forest evidence and provides a controlled 50/75-LPI shoreline study. Retain two inks as the forest starting recommendation; do not promote the finer beach screen without intended-size/operator review. Existing variants, source frames, palette and saved goldens are unchanged. Human/physical suitability remains open.

Merged as `9ad3325884e58b401c188750e62169e7803073c9`; exact head `7ff2f5a` passed all [75 CI steps](https://github.com/yigit-denktas/stipra/actions/runs/39222373464). All 187 Node tests pass locally, along with scoped release gates and saved artwork/plate goldens. [Concrete handoff and review](https://github.com/yigit-denktas/stipra/blob/main/docs/ACCEPTANCE-2026-10-19.md) · [numeric evidence only](https://github.com/yigit-denktas/stipra/blob/main/docs/evidence/acceptance-quality-2026-10-19.json). Owner photos and image-bearing outputs remain private; no public image attachment or native redistribution.


### Comment by yigit-denktas at 2026-10-16T22:59:06Z (https://github.com/yigit-denktas/stipra/issues/34#issuecomment-6226267409)

## Curated print-practice basis for Stipra Styles (2026-10-17)

The [Dizzy Ink guide reading room](https://github.com/yigit-denktas/stipra/blob/main/docs/references/README.md), [source-specific field notes](https://github.com/yigit-denktas/stipra/blob/main/docs/references/DIZZY-INK.md), and [10 proposed printmaking rules R01–R10](https://github.com/yigit-denktas/stipra/blob/main/docs/PRINT-DESIGN-RULES.md) are merged under [PR #36](https://github.com/yigit-denktas/stipra/pull/36).

Consequences for presets: author **purpose and unsuitable cases** first; explicit per-ink grayscale masks and tonal strategy, source detail preservation, overlap diagnostics, real print dimensions/LPI (not merely pixel pitch), neutral baseline and warnings with actual assumptions. Test same rights-cleared artwork across the four initial styles; don't automatically invent semantic classification or unmeasured “safe” ink density. Sample palettes can be inspired by the [Profiles guide](https://risograph.co.uk/04-risograph-profiles), but copying its downloadable profiles or visual assets is outside this MIT project. **Research only; no presets are implemented yet.**

### Comment by yigit-denktas at 2026-10-16T23:07:48Z (https://github.com/yigit-denktas/stipra/issues/34#issuecomment-6226368330)

## Styles research grounded in the illustrated Dizzy Ink guide (2026-10-17)

Read root [DESIGN.md](https://github.com/yigit-denktas/stipra/blob/main/DESIGN.md), the [visual analysis of four specific Dizzy Ink images](https://github.com/yigit-denktas/stipra/blob/main/docs/references/DIZZY-INK-VISUALS.md) and the existing [printmaking rules R01–R10](https://github.com/yigit-denktas/stipra/blob/main/docs/PRINT-DESIGN-RULES.md). The reference clearly shows separate ink file geometry, physical overlap, nonstandard spot-color full-color results, and density stepping: styles must choose **sensible tone-to-ink relationships** and keep masks distinct, not just pick fashionable color hexes.

For four proposed initial styles, benchmark identical rights-cleared source artwork, show ink overlays and actual masks, protect critical detail, preserve physical output intent and record warnings. No style algorithms have been implemented or images imported from the guide. Human and CLI defaults must use one resolver.

### Comment by yigit-denktas at 2026-10-16T23:58:03Z (https://github.com/yigit-denktas/stipra/issues/34#issuecomment-6226968009)

First owner photo review after PR #42 demonstrates why styles need input-aware separation rather than arbitrary gains. A sculptural ridges need detail protection; B forest stump/antler installation still produces muddy overlap despite gains and likely needs different channel partitioning; C sky needs smooth gradient and separate dark detail protection. Owner-specific recipes are experimental, NOT approved Styles. Tests/preview binaries remain private.

### Comment by yigit-denktas at 2026-10-17T00:45:01Z (https://github.com/yigit-denktas/stipra/issues/34#issuecomment-6227517279)

## Four runnable Styles v1 now share exact browser/CLI resolver

[PR #50](https://github.com/yigit-denktas/stipra/pull/50) merged four documented strategies with actual channel recipes and target DPI/LPI (not a fake list of palette colors). [Specification and limits](https://github.com/yigit-denktas/stipra/blob/main/docs/STYLES-v1.md). `stipra package --style editorial-halftone --input photo.png --dpi 300 --out photo.zip` generates plate ZIP with style provenance. `stipra styles suggest --intent portrait` ranks by *user-supplied* intent only; there is no image classifier.

**Quality gate still open**: same-input galleries with measurable detail/clipping/overlap, 3 owner-photo canonical previews, 100%-scale print review, physical sample, and safe defaults. Forest #43 remains highest-quality risk. Please do not label all four “genuinely good Styles” until test evidence is reviewed.

### Comment by yigit-denktas at 2026-10-17T02:14:34Z (https://github.com/yigit-denktas/stipra/issues/34#issuecomment-6228376735)

Implemented in PR #55: four authentic stiprā outlines, SVG-derived brand tokens, IBM Plex Sans Bold and Paper Mono ExtraBold finalists, and three private owner-photo PDFs (square A / landscape B / portrait C), two pages each. Original-photo hashes match the fixture catalog; normalized recipes and actual fonts are embedded. Paired pages have identical image pixels and nontext drawing geometry. Separate-directory builds reproduce PDF and recipe hashes. Local validation: 76 Node tests + 9 private Python checks passed. Images/PDFs are delivered privately, never committed or uploaded to Pages. See docs/TYPE-COMPARISON.md in #55 for evaluation and replay instructions. Owner aesthetic approval and physical-print verification remain open; no brand direction adopted. Public CI status is separate from private fixture verification.

### Comment by yigit-denktas at 2026-10-17T10:04:55Z (https://github.com/yigit-denktas/stipra/issues/34#issuecomment-6232615741)

### Stiprā Styles quality gate now has quantitative measurements

Merged [PR #58](https://github.com/yigit-denktas/stipra/pull/58): browser and CLI share nominal plate-coverage, per-pair overlap, additive coverage and effective DPI/pitch LPI metrics, exported as hashed `report/diagnostics.json`. See [rules](https://github.com/yigit-denktas/stipra/blob/main/docs/PLATE-DIAGNOSTICS-v1.md). Next benchmark **the same three owner source photographs** under each suitable style and 2/3-pass candidate with full-frame geometry and recipe locked. Record both metrics **and human preservation of meaningful details**. No number in this report is a press-safe limit or evidence that an artistic style passed.

### Comment by yigit-denktas at 2026-10-17T22:28:13Z (https://github.com/yigit-denktas/stipra/issues/34#issuecomment-6242269936)

Follow-up implementation is in PR #97. Rechecked the original forest SHA-256 and reviewed native full-frame/depth crops privately. Controlled tonal-key/warm-third common plates match byte-for-byte. Coral contributes 1.2416% changed pixels and 0.8861/255 mean encoded-channel difference; the study does not equate that metric with physical ink value. Two inks remain the preferred starting point. Added opt-in forest-contrast v1: same yellow chroma as forest-depth, deeper green key, with explicit shadow-clipping tradeoff; all earlier/default recipes remain unchanged. Public numeric evidence/recipes and private reproduction script are in docs/FOREST-PASS-REVIEW.md and docs/evidence/forest-ink-contribution-2026-10-17.json. No owner imagery/image-bearing documents committed. Beach figures and sculpture background remain print-size/owner review concerns. Local full suite: 162 passed, zero skipped; final CI pending, not claimed. Artistic/physical acceptance stays open.


## #35 — [Research] Curate Dizzy Ink's Risograph guide into Stipra print/design knowledge

- state: closed / completed
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T22:54:37Z; closedAt: 2026-10-16T22:58:41Z; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/35

### Body

Owner highlighted https://risograph.co.uk/ as an exceptional reference for print craft, design rules and the future Stipra user experience.

**Deliver an original, source-linked internal knowledge portal** rather than a mirror of third-party text, designs, screenshots, artwork or code.

Acceptance:
- [ ] Annotate the guide's chapters (file prep, profiles, density, ink overlay, drying, imperfections, print margins, proofing, colors) with URLs and implications for Stipra.
- [ ] Translate print guidance into explicit design rules for ink masks, style presets, proof/plate UI, registration, resolution and machine-specific warnings.
- [ ] Distinguish observations from Dizzy Ink, Stipra's proposed design choices, and claims requiring hardware calibration; no false press-ready assertions.
- [ ] Preserve the guide's source identity, links, and intellectual-property boundaries. No wholesale scraping/mirroring or importing third-party art under MIT.
- [ ] Connect curated documentation from README and roadmap; link to #34 styles, #31 UX, #22 browser studio, #8 physical preflight, #9 A4 report, #13 QA.
- [ ] CI/readme relative links green. Documentation-only; leave hosted app styling unchanged pending owner review.

Guide belongs to Dizzy Ink; read [their original website](https://risograph.co.uk/) for original illustrations and interactivity.


## #37 — [Docs] Short human README, Stipra design principles and Dizzy Ink image study

- state: closed / completed
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T23:03:08Z; closedAt: 2026-10-16T23:07:25Z; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/37

### Body

## Goal
Make the repository entrance human, short and genuinely useful for both artists and coding agents, without losing original logo/badges or verifiable progress.

The owner highlighted the image-rich [Dizzy Ink guide](https://www.dizzyink.co.uk/guide-to-risograph) and wants its lessons preserved as design guidance—not copied images.

## Deliverables
- [ ] Short README: original untouched dotmark/header/badges; what Stipra is; one live app link, one tested CLI example, honest working/not-yet-working summary, concise progress tied to actual issues, and links to roadmap, contribution/agent instructions and design docs.
- [ ] Move detailed usage/CLI and experimentation paths to docs/GETTING-STARTED.md rather than bloating the README.
- [ ] Add root DESIGN.md covering printmaking principles, image-to-masks-to-proof workflow, style defaults, hierarchy/active plate interface, physical-print caveats, common UI/CLI recipe resolver, attribution/IP rules; distinguish decided principles from interface questions still open in #31.
- [ ] Annotate **four exact visuals** from Dizzy Ink's original guide (printing passes, overlap, color separation, ink swatches) with hyperlinks to originals but **no local copies or embedded third-party images**; connect reference portal and #34.
- [ ] Preserve existing detailed [R01–R10 print rules](https://github.com/yigit-denktas/stipra/blob/main/docs/PRINT-DESIGN-RULES.md), don't duplicate or claim they run in code.
- [ ] Update README/tests/docs links and CI; no app UI changes and no source/art assets copied.

Keep original logo SVG bytes unchanged and retain five badges. Do not mislabel backlog issue ratio as engineering percent.


## #39 — [Acceptance] Owner photographs A/B/C — first complete print package validation

- state: closed / completed
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T23:16:42Z; closedAt: 2026-10-16T23:20:18Z; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/39

### Body

Use the three photographs supplied by the owner to define **explicit, auditable** pass/fail criteria for #8 physical plates, #9 A4 inspection sheet and #12 reproducible ZIP. Fixture A sculptural white contours, B complex outdoor installation, C sky/sea/beach horizon.

Do not commit the photographs without explicit distribution rights (some depicted works may be independently copyrighted). Store immutable metadata/SHA-256 only, with a local-only workflow and a `NOT TESTED` baseline. Automatable conditions cover pixel grid, physical print dimensions, source hashes, full-frame grayscale plates, alignment, report/PDF page dimensions, ZIP inventory, replay and no silent upscaling. Human reviews cover sculpture ridge detail, forest stump/antler silhouette and distant image, beach horizon and two figures; physical printer validations are separate and not automatically passed.

Deliverables: `docs/PRINT-PACKAGE-ACCEPTANCE.md`, machine-readable `tests/fixtures/owner-photo-fixtures.json`, tests of specification consistency, and handoff notes on #8/#9/#12/#13. This issue closes on the **specification**, not completion of export engine or proof that all three pictures pass.


## #43 — [Quality] Preserve forest depth and justify each ink pass

- state: open / None
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T23:59:20Z; closedAt: None; comments: 8
- url: https://github.com/yigit-denktas/stipra/issues/43

### Body

## Owner visual approval — 19 October 2026

The owner approved the supplied digital `forest-balanced` and `coast-tonal` specimens from #112 and explicitly asked to record that approval. Physical prints and independent artist testing are **deferred, not passed**; development can continue. Broader family suitability and physical acceptance remain open. Older recipes/defaults are preserved.

The reviews below are historical evidence and retain their original pre-approval status. The scoped decision is recorded in `docs/OWNER-VISUAL-APPROVAL-2026-10-19.md` alongside the Studio comparison follow-up.

---

## Prior review — 18 October 2026

Shared recipes and two-/three-pass comparisons are implemented. The latest controlled study is docs/FOREST-PASS-REVIEW.md (PR #97): tonal-key and warm-third have byte-identical common plates; coral changes a small localized region and is not automatically justified. Opt-in forest-contrast v1 strengthens the background relative to forest-depth, while restoring clipped key shadows in some areas. All older recipes/defaults are preserved.

The study is digital evidence, not artistic/physical acceptance. Owner review of forest stumps/antlers/foliage and beach figures at intended print size remains open. Actual operator observations and independent artist feedback are not performed; see #13/#70. The initial study below is retained as history, not the latest universal recommendation.

---

Follow-up from first private A/B/C preview review, tracked against [owner acceptance G05/B1–B4](https://github.com/yigit-denktas/stipra/blob/main/docs/PRINT-PACKAGE-ACCEPTANCE.md) and [#34 Styles](https://github.com/yigit-denktas/stipra/issues/34).

The local Pillow/ReportLab reference renderer (NOT canonical Node engine) yielded a muddy three-ink forest composite even after tonal gain tuning. Distinct stump/antler silhouettes, distant screen and foreground/background depth lose too much contrast. Simply decreasing gains makes everything too faint. This is an **unapproved reference preview observation**, not proof of an implementation defect in the Node package CLI.

Acceptance:
- [ ] Run real owner fixture B through canonical `node scripts/owner-photo-batch.js` with hash checks and private output.
- [ ] Review 100%-size crops of antler edges, foreground stumps and distant rectangular screen against source and individual grayscale masks.
- [ ] Compare intentional tonal/key partition strategies and screened vs unscreened coverage, not only gain/HEX changes.
- [ ] Document overlap statistics with no fabricated universal Riso safe threshold.
- [ ] Obtain owner visual sign-off and separate printer-specific checks; attach only rights-cleared crops/evidence to public GitHub.

Keep the original source private; do not distribute any user photo as repo fixture.

## Initial shared-style study (historical measurements)

Type: Research / Feature · Area: Separation quality · Priority: P1 · Release target: v0.9 · Assignee: @yigit-denktas. No verified native milestone/Project ID available.

PR #64 adds shared opt-in tonal-key (two-ink) and warm-third variants, physical screen controls, recipe provenance and suitability guidance. Existing four family defaults remain available. Local validation: 100 Node tests passed, zero skipped; private source SHA checks and 24 source/style proofs; forest 1:1 detail crops and two A4 reports reviewed. Named-style packages preserve authored paper, with real CLI proof-pixel parity checked. Private imagery is not committed.

Focused forest evidence: green coverage 76.4034% → 58.6358%; two-plus overlap 29.0288% → 23.3700% for the two-ink candidate. Selective coral contributes 1.1640% and triggers the low-contribution advisory. The two-ink treatment is the current designer preference; fewer inks are allowed to win. Dark foliage still compresses. The beach matrix also exposes weak sky retention. See docs/FOREST-STYLE-STUDY.md in PR #64 for reproduction, full aggregate measurements and limitations.

This issue remains open: owner visual acceptance and physical print checks are unverified; the four style families are not all declared artistically proven. Dependencies/related: #34 #22 #13 #43 #47 #44, as applicable. Expected evidence: private comparison PDFs/masks/crops and shared normalized browser/CLI recipes; public source/tests/docs only.

## 19 October acceptance follow-up — merged PR #110

Reproduced the original forest hashes and prior contribution measurements. Five controlled real-photo packages were generated privately across forest and beach; the common two forest plate pairs are byte-identical between the two-/three-ink treatments. Coral changes about 1.2416% of forest pixels. Digital review retains two-ink forest-contrast as a starting recommendation, with shadow-clipping tradeoffs. Owner/physical acceptance is still pending.

Merged as `9ad3325884e58b401c188750e62169e7803073c9`; exact head `7ff2f5a` passed all [75 CI steps](https://github.com/yigit-denktas/stipra/actions/runs/39222373464). All 187 Node tests pass locally, along with scoped release gates and saved artwork/plate goldens. [Concrete handoff and review](https://github.com/yigit-denktas/stipra/blob/main/docs/ACCEPTANCE-2026-10-19.md) · [numeric evidence only](https://github.com/yigit-denktas/stipra/blob/main/docs/evidence/acceptance-quality-2026-10-19.json). Owner photos and image-bearing outputs remain private; no public image attachment or native redistribution.


### Comment by yigit-denktas at 2026-10-17T10:04:53Z (https://github.com/yigit-denktas/stipra/issues/43#issuecomment-6232615324)

### Next Work-session task · owner fixture B

The shared [plate diagnostics PR #58](https://github.com/yigit-denktas/stipra/pull/58) is merged. Work should run the **canonical Node** `scripts/owner-photo-batch.js` against the private, SHA-verified forest JPEG (not the Python reference render). Save the ZIP, `report/diagnostics.json`, A4 sheet and 100%-pixel crops of antlers, foreground stump, grass and distant rectangular display **privately**. Compare the existing **three-ink** recipe to a deliberate **two-ink** alternative on the *identical* pixels, output DPI, paper, screen target and print size. Report ink mean contribution, >=2 ink overlap, per-pair overlap and per-ink effective LPI. Judge detail retention and contrast against the original; do not just tune the gain slider. Clearly state PASS/FAIL/NOT RUN and do not fabricate physical print evidence or upload owner images publicly. The earlier print-study showed ~76.4% green and 1.8% coral as context, **not** a verified baseline for the new canonical run.

### Comment by yigit-denktas at 2026-10-17T10:22:19Z (https://github.com/yigit-denktas/stipra/issues/43#issuecomment-6232764805)

PR #61 adds a separate opt-in, original-hash-verified forest study (scripts/forest-key-study.js), without replacing default recipes. It compares the frozen three-brand-ink baseline to an existing black-channel continuous green key plus 50-LPI yellow, removing the 1.8%-coverage coral pass. Measured green mean coverage: 76.4% → 58.6%; yellow 35.5% → 25.7%; two-plus overlap 29.0% → 23.4%, at the declared 25% activity threshold. The private comparison shows clearer antler/stump edges but lighter midtones and still-compressed background foliage. This is authored art direction, not automatic repair or aesthetic validation. Full recipes/hash/diagnostic JSON accompany private proof PNGs. #43 remains open for owner review and printer-specific evidence. Public notes: docs/FOREST-KEY-STUDY.md.

### Comment by yigit-denktas at 2026-10-17T12:47:08Z (https://github.com/yigit-denktas/stipra/issues/43#issuecomment-6234057397)

Merged #64 establishes the reproducible baseline; follow-up #68 adds the opt-in forest-depth candidate. The key uses encoded photographic tone with gain below 1 to avoid clipping the darkest foliage; yellow uses complementary blue-channel density with full gray removal rather than normalized CMYK yellow. At matching 300 DPI / seed 42 / 50 LPI accents: green mean 58.6358% → 52.4723%, yellow 25.8164% → 16.6879%, two-plus overlap 23.4856% → 14.3398%.

Native foliage, stump, antler and distant-display crops were visually inspected. Foliage texture opens and stumps remain readable; the display still loses original violet/brown distinctions. Two inks remain the preferred digital candidate; the earlier selective coral pass does not justify a third ink for this image. These are designer observations supported by masks, not an aesthetic score inferred from coverage. The new source suitability measurement flags 32.2799% dark pixels and suggests inspecting an open-shadow key.

All original fixture hashes verified; private full-frame proofs/plates and detail crops retained outside the repository. 107 Node tests passed, zero skipped; CI pending on #68. Reproduce with scripts/review-separation-quality.js and docs/SEPARATION-QUALITY-STUDY.md. Owner/physical-print acceptance remains open; no press-ready claim.

### Comment by yigit-denktas at 2026-10-17T12:48:54Z (https://github.com/yigit-denktas/stipra/issues/43#issuecomment-6234073164)

Follow-up: #68 CI run 39033873386 passed on b2b2c9452c9fb7605d2851e3b3f27b171788bd8a. The private before/after proofs and native detail crops are preserved with source/plate/proof hashes and the exact code revision. Ready for owner review; physical print acceptance remains open.

### Comment by yigit-denktas at 2026-10-17T22:28:14Z (https://github.com/yigit-denktas/stipra/issues/43#issuecomment-6242270228)

Follow-up implementation is in PR #97. Rechecked the original forest SHA-256 and reviewed native full-frame/depth crops privately. Controlled tonal-key/warm-third common plates match byte-for-byte. Coral contributes 1.2416% changed pixels and 0.8861/255 mean encoded-channel difference; the study does not equate that metric with physical ink value. Two inks remain the preferred starting point. Added opt-in forest-contrast v1: same yellow chroma as forest-depth, deeper green key, with explicit shadow-clipping tradeoff; all earlier/default recipes remain unchanged. Public numeric evidence/recipes and private reproduction script are in docs/FOREST-PASS-REVIEW.md and docs/evidence/forest-ink-contribution-2026-10-17.json. No owner imagery/image-bearing documents committed. Beach figures and sculpture background remain print-size/owner review concerns. Local full suite: 162 passed, zero skipped; final CI pending, not claimed. Artistic/physical acceptance stays open.

### Comment by yigit-denktas at 2026-10-19T09:38:37Z (https://github.com/yigit-denktas/stipra/issues/43#issuecomment-6264229319)

New controlled quality work is in #112 (`d691eadb`). `forest-balanced` v1 retains the photographic green key at gain 1 / gamma 1.3, with the yellow plate and screens byte-identical to forest-contrast. On original hash-checked fixture B, full continuous-key coverage falls from 13.1259% to 0.1004%; full coverage where the declared encoded source tone exceeds 0.02 falls from 9.3413% to zero. Native foliage/display/stump/antler review favors its retained shadow gradation, with lighter midtones as the tradeoff.

The controlled two-/three-ink comparison was also reproduced: common plates match; coral still changes about 1.2416% of pixels and is not automatically justified. Two inks remain the starting preference. No earlier recipe/default is changed.

All three original hashes were verified; private full-frame proofs and continuous/screened plates, 60-treatment suitability matrix and four verified canonical old/new forest/beach packages are generated. Eight report pages were rendered/reviewed. Numeric-only evidence and private reproduction instructions: docs/TONAL-DETAIL-REVIEW.md and docs/evidence/tonal-detail-2026-10-19.json in #112. Exact-head CI is running; 189 Node tests, saved artwork goldens and lean/browser release gates pass locally. No photographs are attached publicly. Owner/artist/physical acceptance remains open.

### Comment by yigit-denktas at 2026-10-19T09:47:04Z (https://github.com/yigit-denktas/stipra/issues/43#issuecomment-6264378410)

Merged #112 as `d8806d6ab1c2f69a7f5fe0d1adf344900c62f637`. Exact final head `e44f60f10275b591bc965daff70f75f96ed859f4` passed all 75 [verification steps](https://github.com/yigit-denktas/stipra/actions/runs/39232105650) and the separate public-page review. All 189 Node tests pass locally; all 15 recipe definitions now have frozen hashes, including every previous recipe derived from the prior main source. README, ROADMAP, delivery ledger, changelog and capability history are reconciled.

The private old/new comparison sheets and full review pack are saved for the owner. Public evidence remains numeric-only. The two new recipes are opt-in; earlier defaults and published npm artifacts are unchanged. This issue remains open for owner/artist and physical acceptance; no physical print or independent human trial is claimed.

### Comment by yigit-denktas at 2026-10-19T10:23:09Z (https://github.com/yigit-denktas/stipra/issues/43#issuecomment-6265021949)

Owner visual approval recorded, 19 October 2026. After reviewing the private forest/beach comparisons from #112, the owner said “i really like them” and explicitly requested “record my approval”, adding that physical prints and independent artist testing could await.

Scope: positive visual approval of the supplied digital forest-balanced and coast-tonal specimens and authorization to improve recipe comparison/selection in the Studio. This is not physical-print validation, independent artist testing, a universal recipe-family approval or a request to overwrite earlier defaults. Those acceptance activities are deferred; development continues.


## #44 — [Color] Preserve and verify embedded ICC conversion policy for beach fixture C

- state: closed / completed
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-16T23:59:23Z; closedAt: 2026-10-17T13:52:31Z; comments: 2
- url: https://github.com/yigit-denktas/stipra/issues/44

### Body

The owner's beach JPEG C carries an embedded ICC profile. The local Python reference renderer converts it to sRGB using Pillow ImageCms; the canonical Node import path retains source profile metadata but its decode/normalization and proofing behavior must be explicitly compared. [#39 A/B/C acceptance](https://github.com/yigit-denktas/stipra/blob/main/docs/PRINT-PACKAGE-ACCEPTANCE.md) requires transparent provenance rather than silently losing ICC.

Acceptance:
- [ ] Identify embedded source profile name/metadata without redistributing source.
- [ ] Document exactly how `skia-canvas` decodes/transforms the image and whether sRGB conversion is guaranteed.
- [ ] Assert source original bytes and ICC source presence survive in ZIP+manifest; any normalized sRGB conversion recorded.
- [ ] Compare visual outputs to a separately color-managed reference using numeric patch tests.
- [ ] Never claim measured spot ink/spectral ICC calibration from source RGB profiles.

This is a correctness investigation, not evidence that the current Node output is physically calibrated.

### Comment by yigit-denktas at 2026-10-17T13:47:50Z (https://github.com/yigit-denktas/stipra/issues/44#issuecomment-6234647330)

Implemented in #77: explicit sRGB Canvas/readback and recorded decoder policy; JPEG ICC segment/header/tag validation and profile description; non-sRGB synthetic PNG/JPEG fixtures compared independently with Pillow ImageCms/LittleCMS through Node, plus actual browser-studio coverage in CI. Original bytes and metadata are checked inside the ZIP.

Private owner C SHA-256 matches the fixture. Its embedded 456-byte profile is sRGB/RGB/XYZ. Node v24.19.0 + skia-canvas 3.0.8 versus Pillow 12.3.0 + LittleCMS 2.19: maximum and mean absolute 8-bit RGB difference 0 across all 2,359,296 pixels. No owner image is attached or committed. This establishes the recorded source/environment, not arbitrary-profile equivalence or press calibration.

Local: 116 tests pass, no skips; full public build and independent reference verifier pass. Browser check awaits PR CI. docs/COLOR-MANAGEMENT.md records policy and compatibility limits. Closing is tied to the verified implementation merge.

### Comment by yigit-denktas at 2026-10-17T13:52:32Z (https://github.com/yigit-denktas/stipra/issues/44#issuecomment-6234692592)

#77 passed the final head's complete CI run 39038216087 (133): 116 Node tests, both real-browser suites including the non-sRGB fixtures and package checks, independent LittleCMS reference verification, PDF/font and QR checks. Implementation is merged. The private owner-source comparison and environment are recorded in docs/COLOR-MANAGEMENT.md. Physical print calibration remains outside this issue.


## #45 — [Design] Editorial print sheets v2: ratio-aware layouts, IBM Plex, paper grain, and embedded recipe

- state: closed / completed
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T00:15:15Z; closedAt: 2026-10-17T00:27:59Z; comments: 2
- url: https://github.com/yigit-denktas/stipra/issues/45

### Body

User rejected the white rounded-card appearance of Stiprā PDF inspection reports. Reference: Dizzy Ink multi-plate print specimen, classic paper stock, crisp editorial typography; **do not copy artwork**.

Goals:
- Output A4 portrait for tall source and landscape for wide source; no stretched/cropped artwork, retain all plate ratios, use space efficiently.
- Design language: sharp rules, typographic hierarchy, IBM Plex Sans + Mono with OFL notices, no rounded rectangles, subtle deterministic physical-paper fiber/grain, aligned grids.
- Paper auto-choice based on coarse source palette with clearly named stock and override; decorative paper texture strictly **proof/report only** and no effects on grayscale plate pixels.
- Reproducibility visible: ink names, HEX screen reference, average coverage, mode, pitch, angle, seed, DPI, output sizes, source SHA-256. Embed original normalized JSON recipes **inside PDF attachments** with hashes; QR only to public documentation, not a fictitious private-job URL.
- One engine for HTML and PDF metadata; real automated portrait and landscape geometry, PDF embedded-files, stable output and no extra network calls.
- Human owner review of generated image A/B/C sheets before saying aesthetic quality passed. Physical press verification remains separate.

Replaces overly generic card layout in `src/print-package.js`; preserve existing archive and production-master invariants. Cross-link #8 #9 #12 #13 #34.

### Comment by yigit-denktas at 2026-10-17T02:14:30Z (https://github.com/yigit-denktas/stipra/issues/45#issuecomment-6228376152)

Implemented in PR #55: four authentic stiprā outlines, SVG-derived brand tokens, IBM Plex Sans Bold and Paper Mono ExtraBold finalists, and three private owner-photo PDFs (square A / landscape B / portrait C), two pages each. Original-photo hashes match the fixture catalog; normalized recipes and actual fonts are embedded. Paired pages have identical image pixels and nontext drawing geometry. Separate-directory builds reproduce PDF and recipe hashes. Local validation: 76 Node tests + 9 private Python checks passed. Images/PDFs are delivered privately, never committed or uploaded to Pages. See docs/TYPE-COMPARISON.md in #55 for evaluation and replay instructions. Owner aesthetic approval and physical-print verification remain open; no brand direction adopted. Public CI status is separate from private fixture verification.

### Comment by yigit-denktas at 2026-10-17T10:22:17Z (https://github.com/yigit-denktas/stipra/issues/45#issuecomment-6232764543)

Takeover implemented in PR #61, preserving merged #58/#59 and the separate #55 typography study. Canonical PDFs now use regular/bold/mono roles with a 9pt minimum, full input SHA-256, all 2–8 plates with pagination, actual LPI/screen-off labels, existing overlap warnings and linked guide QRs. Fixed a verified missing-glyph box for ā by merging authentic Latin Extended outlines. Build and 93 Node tests pass (no skips). Three private A4 owner reports each have two pages, match hashes across separate output directories, and all six pages were visually reviewed at 144dpi. Owner photos/report images remain private. No final wordmark or default separation adopted; physical print and owner aesthetic approval remain open.


## #46 — [Brand] Generate a reproducible layered Stiprā mark using its own separation and screening engine

- state: open / None
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T00:15:18Z; closedAt: None; comments: 5
- url: https://github.com/yigit-denktas/stipra/issues/46

### Body

Design a distinctive logo **made through the actual Stiprā renderer**, not imported/generated artwork. Preserve existing owner original `logo_for_Readme.svg` unchanged. Commit script, authored procedural stencil and deterministic SVG/PNG output with a reproducibility test. Use layered physical spot-color masks and screening (StipraSeparation/StipraScreen), not a manually imitated image. Show alternative beside old brand; **do not silently replace the established README dotmark without owner review**. Keep fonts/font files under OFL with notices, no source photos or unauthorized visuals. Connect design direction #31.

### Comment by yigit-denktas at 2026-10-17T00:58:25Z (https://github.com/yigit-denktas/stipra/issues/46#issuecomment-6227667062)

## Geometry-first rebuild delivered for owner review — PR #51 (17 Oct 2026)

Owner rejected initial dot ribbon as unbalanced and supplied focused critique: shifted right-side visual weight, unclear S silhouette, conflicting dot sizes, arbitrary color and decorative black centers. We **replaced** the live generated candidate in [PR #51](https://github.com/yigit-denktas/stipra/pull/51), keeping the original README dotmark untouched.

Now published four structural tests: [solid black S](https://apps.yigitdenktas.com/stipra/brand/stipra-mark-silhouette.svg), [uniform matrix](https://apps.yigitdenktas.com/stipra/brand/stipra-mark-matrix.svg), [geometric radius-weighted matrix](https://apps.yigitdenktas.com/stipra/brand/stipra-mark-density.svg), and [two registered-ink overprint](https://apps.yigitdenktas.com/stipra/brand/stipra-mark-overprint.svg). The two actual separately rendered spot plate masters are [teal](https://apps.yigitdenktas.com/stipra/brand/stipra-mark-teal.svg) and [coral](https://apps.yigitdenktas.com/stipra/brand/stipra-mark-coral.svg); no third black marks. 

**Construction:** a smooth, continuous round-capped Bézier S from overlapping same-width discs; regular 11.8px lattice; deterministic dot-size progression based on edge distance; meaningful shared 42–58% interval along S stroke in **both** physical ink passes; optical area-centroid and L/R weight diagnostics as a CI gate. [Source](https://github.com/yigit-denktas/stipra/blob/main/scripts/generate-stipra-mark.js) and [study](https://github.com/yigit-denktas/stipra/blob/main/docs/BRAND-STUDY.md). All Node/Pages/Chromium checks passed.

**Remaining**: actual owner visual selection and small-size/fabric/paper usage approval. Keep the issue open; do not replace `logo_for_Readme.svg` or call this adopted.

### Comment by yigit-denktas at 2026-10-17T01:18:45Z (https://github.com/yigit-denktas/stipra/issues/46#issuecomment-6227866933)

## full-wordmark-first direction delivered for owner review — pr #53

owner rejected the standalone s and asked for **two real typefaces**, ibm plex and paper mono, with **all-lowercase stiprā**. the [live typography comparison](https://apps.yigitdenktas.com/stipra/typography/) now has true glyph-outline plain and two-ink wordmarks in both families, plus matched a4 pdf proofs ([ibm plex](https://apps.yigitdenktas.com/stipra/typography/ibm-plex-print-study.pdf) / [paper mono](https://apps.yigitdenktas.com/stipra/typography/paper-mono-print-study.pdf)). the full ibm plex ttf and paper mono v1.000 release include the real ā glyph; fonts are sil ofl 1.1, source hash-verified, used only for generating outlined svg and embedded pdf. no ai image generation or fake font approximations.

**do not replace the original logo yet**. these are actual typographic comparison samples awaiting owner evaluation, not brand adoption. the prior standalone s studies are now historical/secondary.

### Comment by yigit-denktas at 2026-10-17T02:01:26Z (https://github.com/yigit-denktas/stipra/issues/46#issuecomment-6228251778)

Follow-up design QA scope is now tracked in [#54](https://github.com/yigit-denktas/stipra/issues/54): extract the **actual four original SVG fills** (#006043, #FF665D, #0D4DAD, #E2A523); compare real lowercase `stiprā` in IBM Plex Sans Bold / Plex Mono Bold / Paper Mono Regular / ExtraBold; choose one documented finalist per family; render **only three private PDFs**, two matched pages each, from the owner’s verified sculpture / forest / beach source files. Square *page* for sculpture without changing its source ratio, landscape forest, portrait beach; consistent ink plates and recipes, embedded metadata, no generated placeholder images. The old #52 font-proof experiment was a technical precursor, not the finished art-direction evaluation. Original README dotmark stays untouched pending approval.

### Comment by yigit-denktas at 2026-10-17T02:14:31Z (https://github.com/yigit-denktas/stipra/issues/46#issuecomment-6228376307)

Implemented in PR #55: four authentic stiprā outlines, SVG-derived brand tokens, IBM Plex Sans Bold and Paper Mono ExtraBold finalists, and three private owner-photo PDFs (square A / landscape B / portrait C), two pages each. Original-photo hashes match the fixture catalog; normalized recipes and actual fonts are embedded. Paired pages have identical image pixels and nontext drawing geometry. Separate-directory builds reproduce PDF and recipe hashes. Local validation: 76 Node tests + 9 private Python checks passed. Images/PDFs are delivered privately, never committed or uploaded to Pages. See docs/TYPE-COMPARISON.md in #55 for evaluation and replay instructions. Owner aesthetic approval and physical-print verification remain open; no brand direction adopted. Public CI status is separate from private fixture verification.

### Comment by yigit-denktas at 2026-10-17T10:06:47Z (https://github.com/yigit-denktas/stipra/issues/46#issuecomment-6232633401)

### Current identity focus — wordmark, not the generated S

The earlier abstract S options are superseded by [PR #59](https://github.com/yigit-denktas/stipra/pull/59) and its [three-face real-font preview](https://apps.yigitdenktas.com/stipra/identity/). Compare IBM Plex Sans Bold, Paper Mono Regular and Paper Mono SemiBold; assess monochrome, coral **macron-only** and the original unchanged colored five-dot-row companion. No automatic replacement of `logo_for_Readme.svg`, physical print evidence or brand selection yet.


## #47 — [Styles] Make the four starter print styles actual shared recipes, with image suitability tests

- state: open / None
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T00:15:21Z; closedAt: None; comments: 7
- url: https://github.com/yigit-denktas/stipra/issues/47

### Body

## Owner visual approval — 19 October 2026

The owner approved the supplied digital `forest-balanced` and `coast-tonal` specimens from #112 and explicitly asked to record that approval. Physical prints and independent artist testing are **deferred, not passed**; development can continue. Broader family suitability and physical acceptance remain open. Older recipes/defaults are preserved.

The reviews below are historical evidence and retain their original pre-approval status. The scoped decision is recorded in `docs/OWNER-VISUAL-APPROVAL-2026-10-19.md` alongside the Studio comparison follow-up.

---

## Prior review — 18 October 2026

Shared recipes and two-/three-pass comparisons are implemented. The latest controlled study is docs/FOREST-PASS-REVIEW.md (PR #97): tonal-key and warm-third have byte-identical common plates; coral changes a small localized region and is not automatically justified. Opt-in forest-contrast v1 strengthens the background relative to forest-depth, while restoring clipped key shadows in some areas. All older recipes/defaults are preserved.

The study is digital evidence, not artistic/physical acceptance. Owner review of forest stumps/antlers/foliage and beach figures at intended print size remains open. Actual operator observations and independent artist feedback are not performed; see #13/#70. The initial study below is retained as history, not the latest universal recommendation.

---

Progress the defined #34 style collection, independently of PDF cosmetics. Implement four proven families (Portrait Duotone, Editorial Halftone, Bold Spot Poster, Clean Linework) as versioned, explainable defaults with documented suitable inputs, screen ink strategies and warnings. One normalized resolver for browser/CLI, with neutral fallback, resolution-aware print intent and saved effective settings. Test sculpture/forest/beach plus a separate rights-cleared type fixture; preserve source/plate bytes. **Do not simply hard-code four random palette recolors or pretend portrait detection exists.** Link #34, #22, #13 and Kuşluk benchmark. This is follow-up after report-v2 work.

## Initial shared-style study (historical measurements)

Type: Feature · Area: Styles / browser / CLI · Priority: P1 · Release target: v0.9 · Assignee: @yigit-denktas. No verified native milestone/Project ID available.

PR #64 adds shared opt-in tonal-key (two-ink) and warm-third variants, physical screen controls, recipe provenance and suitability guidance. Existing four family defaults remain available. Local validation: 100 Node tests passed, zero skipped; private source SHA checks and 24 source/style proofs; forest 1:1 detail crops and two A4 reports reviewed. Named-style packages preserve authored paper, with real CLI proof-pixel parity checked. Private imagery is not committed.

Focused forest evidence: green coverage 76.4034% → 58.6358%; two-plus overlap 29.0288% → 23.3700% for the two-ink candidate. Selective coral contributes 1.1640% and triggers the low-contribution advisory. The two-ink treatment is the current designer preference; fewer inks are allowed to win. Dark foliage still compresses. The beach matrix also exposes weak sky retention. See docs/FOREST-STYLE-STUDY.md in PR #64 for reproduction, full aggregate measurements and limitations.

This issue remains open: owner visual acceptance and physical print checks are unverified; the four style families are not all declared artistically proven. Dependencies/related: #34 #22 #13 #43 #47 #44, as applicable. Expected evidence: private comparison PDFs/masks/crops and shared normalized browser/CLI recipes; public source/tests/docs only.

## 19 October acceptance follow-up — merged PR #110

Added reusable inert compare plans for tonal two-/three-ink forest treatment and beach 50/75 LPI at 300 DPI. Continuous coast masks and the solid blue plate remain fixed; finer dots alone do not solve figure contrast. All five package jobs verify. No existing recipe/default/library byte or golden changed. Four families remain artistically/physically unapproved.

Merged as `9ad3325884e58b401c188750e62169e7803073c9`; exact head `7ff2f5a` passed all [75 CI steps](https://github.com/yigit-denktas/stipra/actions/runs/39222373464). All 187 Node tests pass locally, along with scoped release gates and saved artwork/plate goldens. [Concrete handoff and review](https://github.com/yigit-denktas/stipra/blob/main/docs/ACCEPTANCE-2026-10-19.md) · [numeric evidence only](https://github.com/yigit-denktas/stipra/blob/main/docs/evidence/acceptance-quality-2026-10-19.json). Owner photos and image-bearing outputs remain private; no public image attachment or native redistribution.


### Comment by yigit-denktas at 2026-10-17T00:44:59Z (https://github.com/yigit-denktas/stipra/issues/47#issuecomment-6227516764)

## Shared Styles v1 technical milestone merged (PR #50, 17 Oct 2026)

A **real shared browser + agent CLI module** now exists at [src/styles.js](https://github.com/yigit-denktas/stipra/blob/main/src/styles.js). Four strategies are executable: Portrait Duotone, Editorial Halftone, Bold Spot Poster, Clean Linework. Each sets distinct ink channels, tone transfers, swatches, screening, target LPI and warnings, with DPI→physical pitch conversion. Browser selects presets; CLI supports `styles list|explain|suggest` and `package --style ID`; ZIP preserves the resolved recipe. Same UMD code for Node and browser; Node, Pages, two Chromium smoke checks green. [Read how to use them](https://github.com/yigit-denktas/stipra/blob/main/docs/STYLES-v1.md).

**Do not mistake technical completeness for visual quality.** Image-suitability scoring, same-photo side-by-side comparisons, critical-detail preservation, 100% print-size QA, forest depth fixes #43, beach ICC #44 and real printer tests remain **NOT VERIFIED**. Recommend keeping this issue open as aesthetic release acceptance, or split its benchmark into #34 / #13 once verified.

### Comment by yigit-denktas at 2026-10-17T12:47:07Z (https://github.com/yigit-denktas/stipra/issues/47#issuecomment-6234057248)

PR #64 is merged as e32cb6006e5da8f57a11ae0634d29bdf81f662c5. Follow-up #68 adds six opt-in variants: four attributed channel-separation recipes (blue/pink, teal/orange, three-ink process, four-ink process) plus forest-depth and coast-duotone. Browser and CLI share catalog discovery, versioned normalized recipes, physical screens, editable photographic tone/density/gray-removal controls, and measured source suitability guidance. Source attribution, formulas and preview-swatches provenance are in docs/references/SEPARATION-RECIPES.md; no profiles/code/artwork were copied.

Evidence: build:github-pages and 107 Node tests pass with zero skipped. Complete UMD-versus-Node mask/proof parity across all variants at 150/300/600 DPI; actual CLI package recipe/source/proof-pixel parity on five treatments; fingerprints preserve the four family defaults and both earlier variants. Real-browser CI covers each new variant.

Private validation: all three owner SHA-256 checks, 48 native same-source proofs and grayscale plates plus six focused before/after proofs and native detail crops. New forest key opens dense foliage; coast treatment retains sky/cloud structure and both figures. Sculpture remains an explicit unsuitable case. Full findings and reproduction commands: docs/SEPARATION-QUALITY-STUDY.md. No private photos or derivative proofs committed/hosted. This issue stays open for owner and physical-print acceptance, broader recipe quality and ICC policy #44. Lab/guide visual alignment remains deferred.

### Comment by yigit-denktas at 2026-10-17T12:48:53Z (https://github.com/yigit-denktas/stipra/issues/47#issuecomment-6234073031)

Follow-up validation: #68 CI run 39033873386 passed on b2b2c9452c9fb7605d2851e3b3f27b171788bd8a, including all new browser variant interactions, 107 Node tests, PDF/type checks and QR decoding. Private recipe/proof bundle is preserved with the exact code revision. #68 is ready for review and remains unmerged; acceptance gates above remain open.

### Comment by yigit-denktas at 2026-10-17T22:28:15Z (https://github.com/yigit-denktas/stipra/issues/47#issuecomment-6242270495)

Follow-up implementation is in PR #97. Rechecked the original forest SHA-256 and reviewed native full-frame/depth crops privately. Controlled tonal-key/warm-third common plates match byte-for-byte. Coral contributes 1.2416% changed pixels and 0.8861/255 mean encoded-channel difference; the study does not equate that metric with physical ink value. Two inks remain the preferred starting point. Added opt-in forest-contrast v1: same yellow chroma as forest-depth, deeper green key, with explicit shadow-clipping tradeoff; all earlier/default recipes remain unchanged. Public numeric evidence/recipes and private reproduction script are in docs/FOREST-PASS-REVIEW.md and docs/evidence/forest-ink-contribution-2026-10-17.json. No owner imagery/image-bearing documents committed. Beach figures and sculpture background remain print-size/owner review concerns. Local full suite: 162 passed, zero skipped; final CI pending, not claimed. Artistic/physical acceptance stays open.

### Comment by yigit-denktas at 2026-10-19T09:38:38Z (https://github.com/yigit-denktas/stipra/issues/47#issuecomment-6264229588)

Shared-quality follow-up is in #112. Two explicitly versioned opt-in variants use the existing browser/CLI/core resolver: `forest-balanced` preserves dark key steps; `coast-tonal` changes the blue pass from complementary red density to photographic tone so dark silhouettes separate more clearly from saturated blue water. Their respective yellow/coral masks and screen settings remain byte-identical to the previous comparison recipes. All previous normalized recipe hashes are preserved; the two new v1 recipes receive their own frozen hashes.

Suitability limits are explicit: lighter forest midtones, slightly paler coastal sky, no semantic object detection, and the sculpture’s heavy dark background remains a counterexample. The 60-treatment matrix covers every current family/variant on all three hash-verified owner originals plus authored linework. Synthetic tests check dark-tone ordering and silhouette/water distinction, and full browser/Node parity covers both additions; actual CLI package pixels/recipes are also checked.

Four canonical packages and eight rendered report pages remain private. Public formulas, numeric evidence and reproduction instructions are in docs/TONAL-DETAIL-REVIEW.md. 189 Node tests and lean/browser/golden checks pass locally; exact-head browser CI is running. No new npm publication or family-wide artistic/physical acceptance is claimed. This issue stays open for that acceptance.

### Comment by yigit-denktas at 2026-10-19T09:47:05Z (https://github.com/yigit-denktas/stipra/issues/47#issuecomment-6264378701)

Merged #112 as `d8806d6ab1c2f69a7f5fe0d1adf344900c62f637`. Exact final head `e44f60f10275b591bc965daff70f75f96ed859f4` passed all 75 [verification steps](https://github.com/yigit-denktas/stipra/actions/runs/39232105650) and the separate public-page review. All 189 Node tests pass locally; all 15 recipe definitions now have frozen hashes, including every previous recipe derived from the prior main source. README, ROADMAP, delivery ledger, changelog and capability history are reconciled.

The private old/new comparison sheets and full review pack are saved for the owner. Public evidence remains numeric-only. The two new recipes are opt-in; earlier defaults and published npm artifacts are unchanged. This issue remains open for owner/artist and physical acceptance; no physical print or independent human trial is claimed.

### Comment by yigit-denktas at 2026-10-19T10:23:10Z (https://github.com/yigit-denktas/stipra/issues/47#issuecomment-6265022260)

Owner visual approval recorded, 19 October 2026: the owner likes the #112 digital forest/beach specimens and explicitly asked to record approval. They authorized side-by-side recipe comparison, brief explanations/tradeoffs and Studio/guide alignment, and stated physical prints and independent artist testing could await.

Record this as owner approval of these digital specimens. Independent artist and physical-print acceptance are deferred, not passed; older recipes/defaults remain preserved. The next UI work will make choosing and keeping a treatment explicit.


## #52 — [Typography] Real IBM Plex vs Paper Mono lowercase wordmark and A4 PDF proofs

- state: closed / completed
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T01:10:35Z; closedAt: 2026-10-17T01:17:46Z; comments: 2
- url: https://github.com/yigit-denktas/stipra/issues/52

### Body

Owner requests true typographic juxtaposition of full lowercase **stiprā** wordmarks and print-report PDFs in **IBM Plex** and **Paper Mono**; all displayed example copy lowercase. **Absolutely no image-generation tools or synthetic approximations of the typefaces.**

- [ ] Use actual IBM Plex Sans/Mono fonts already in dependencies, and real Paper Mono v1.000 regular/extra-bold TTF from official paper-design/paper-mono OFL-1.1 project (SHA-pinned retrieval at build; cache ignored, no font binaries committed).
- [ ] Generate two matched wordmark SVGs from real type outlines, lowercase "stiprā" with intact ā, black and a restrained two-ink treatment.
- [ ] Generate two A4 specimen PDFs from the existing report layout with identical composition/data/paper, changing **only typography**. Include actual settings, ink plates and reproducibility notes; use lowercase text everywhere in these experimental proofs.
- [ ] Ship a tidy comparison page/assets generated by `npm run build:pages`; avoid a duplicate handwritten HTML demo and do not replace original dotmark/logo in README.
- [ ] Tests: actual font identity/coverage of U+0101, PDFs contain embedded corresponding fonts, identical report geometry across variants, correct hyperlinks and license attribution; real Node+browser CI green.
- [ ] Put designer-friendly comparisons alongside a license/source note; not adopted without owner visual approval.

Reference Paper Mono official repository: https://github.com/paper-design/paper-mono, OFL: https://github.com/paper-design/paper-mono/blob/v1.000/OFL.txt; IBM Plex license SIL OFL-1.1.

### Comment by yigit-denktas at 2026-10-17T02:01:24Z (https://github.com/yigit-denktas/stipra/issues/52#issuecomment-6228251436)

Follow-up design QA scope is now tracked in [#54](https://github.com/yigit-denktas/stipra/issues/54): extract the **actual four original SVG fills** (#006043, #FF665D, #0D4DAD, #E2A523); compare real lowercase `stiprā` in IBM Plex Sans Bold / Plex Mono Bold / Paper Mono Regular / ExtraBold; choose one documented finalist per family; render **only three private PDFs**, two matched pages each, from the owner’s verified sculpture / forest / beach source files. Square *page* for sculpture without changing its source ratio, landscape forest, portrait beach; consistent ink plates and recipes, embedded metadata, no generated placeholder images. The old #52 font-proof experiment was a technical precursor, not the finished art-direction evaluation. Original README dotmark stays untouched pending approval.

### Comment by yigit-denktas at 2026-10-17T02:14:29Z (https://github.com/yigit-denktas/stipra/issues/52#issuecomment-6228376031)

Implemented in PR #55: four authentic stiprā outlines, SVG-derived brand tokens, IBM Plex Sans Bold and Paper Mono ExtraBold finalists, and three private owner-photo PDFs (square A / landscape B / portrait C), two pages each. Original-photo hashes match the fixture catalog; normalized recipes and actual fonts are embedded. Paired pages have identical image pixels and nontext drawing geometry. Separate-directory builds reproduce PDF and recipe hashes. Local validation: 76 Node tests + 9 private Python checks passed. Images/PDFs are delivered privately, never committed or uploaded to Pages. See docs/TYPE-COMPARISON.md in #55 for evaluation and replay instructions. Owner aesthetic approval and physical-print verification remain open; no brand direction adopted. Public CI status is separate from private fixture verification.


## #54 — [Design QA] Real Stiprā palette + four authentic wordmarks + three owner-photo comparison PDFs

- state: closed / completed
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T02:01:10Z; closedAt: 2026-10-17T11:07:44Z; comments: 5
- url: https://github.com/yigit-denktas/stipra/issues/54

### Body

## Goal
Replace the preliminary typography demo with a **fair, brand-faithful** comparison using actual lowercase **stiprā** wordmarks, the four colors from the original owner SVG, and the owner's three original photographs. **No image-generation tools, substitute artworks, placeholder photos, or invented palette.**

This issue extends [#52](https://github.com/yigit-denktas/stipra/issues/52) (technical font proof). Links: [#46 branding](https://github.com/yigit-denktas/stipra/issues/46), [#9 A4 sheets](https://github.com/yigit-denktas/stipra/issues/9), [#13 quality](https://github.com/yigit-denktas/stipra/issues/13), [#34 styles](https://github.com/yigit-denktas/stipra/issues/34).

## 1. Canonical brand colors: read them from the original SVG
Source: `logo_for_Readme.svg` on `main`, blob SHA `c792b8c24df29c8bc0e59909f810115044095038`. The verified **fill** colors are:

- `#006043` — green
- `#FF665D` — coral
- `#0D4DAD` — blue
- `#E2A523` — golden yellow

Preserve original per-dot **opacity** as part of the artwork's visual system. The SVG uses these four colors, not the arbitrary cyan/teal/vermilion of previous generated proofs. Extract programmatically from the canonical file into a reusable design token object; do not type unrelated substitutes into individual reports. Do not modify original SVG bytes. Neutral black/white and justified paper stock colors can exist as **supporting materials**, not unapproved new brand swatches. Explain role choices (e.g. brand accent, ink color, registration/key, paper) and distinguish screen approximation from physical spot inks.

## 2. Fair, four-candidate lowercase wordmark comparison
**Same exact string in all samples:** `stiprā` (real U+0101 lowercase macron). No all caps, no standalone S as the primary identity.

IBM Plex family:
- **IBM Plex Sans Bold** — verify real full-font glyph coverage;
- **IBM Plex Mono Bold** — same-size comparison candidate.

Paper Mono family:
- **Paper Mono Regular**;
- **Paper Mono ExtraBold**.

Use **real upstream font outlines** and the existing OFL-licensed, version/hash-verified font resolution workflow. Do not simulate fonts, rasterize wordmarks, embed an external screenshot or distribute raw font files. Compare equal optical cap/x-height or measured visual bounds, baseline, kerning, and 24/48/96px legibility. Show each version (a) solid dark and (b) restrained use of the **actual four SVG colors** (not mandatory to put all four inks in every glyph). The texture must support letterforms, not destroy them.

**Select exactly one finalist per family** with brief written justification from concrete criteria: balance, word recognition, macron design, printability, color restraint, and reduced-size legibility. The prior working hypotheses are IBM Plex Sans Bold and Paper Mono ExtraBold, **but do not declare winners until comparing**.

## 3. Actual owner photo fixtures — private only
Reuse byte-identical original files from the private fixture catalog `tests/fixtures/owner-photo-fixtures.json`, verifying SHA-256 **before** processing:

- **A / sculpture:** `1680898969919.jpg`, 805×644 — near-square object study; use a **square PDF page layout**, but **do not square-crop, distort, stretch, or hallucinate the photograph**.
- **B / forest:** `SPK-Skulpturenpark-04.web_-2048x1365.jpg`, 2048×1365 — **landscape PDF**, native composition.
- **C / beach:** `IMG_9087.jpg`, 1152×2048 — **portrait PDF**, retain the horizon and tiny figures, no landscape letterbox.
  
Run real Stiprā source import / separation / screening where needed. Reuse a **single frozen ink/screen recipe, paper stock, DPI, and proof** for both finalists within each fixture; do not regenerate with different artistic treatment when changing font. Label outputs digital approximations, not press-calibrated. Preserve input ICC handling and source dimensions; show any resizing in metadata. No owner photographs or generated image-bearing PDFs/ZIPs should be committed to public GitHub or uploaded to public Pages without the owner's explicit redistribution permission.

## 4. Exactly three comparison PDFs, two pages each
Deliver **only three PDFs** (six pages total):

1. `stipra-type-comparison-a-square.pdf` — sculpture, square page (e.g. 210×210 mm).
2. `stipra-type-comparison-b-landscape.pdf` — forest, A4 landscape 297×210 mm.
3. `stipra-type-comparison-c-portrait.pdf` — beach, A4 portrait 210×297 mm.

Within **each** PDF:
- page 1: chosen IBM Plex finalist;
- page 2: chosen Paper Mono finalist.
  
Maintain the **identical** page grid, image framing, crop (prefer uncropped), per-plate thumbnail positions, actual paper/ink/background choices, margins, settings/QR location, and photo treatment between the two pages. Only font family and necessary typographic metrics change. Strong image-first editorial composition; sharp rules, restrained authentic paper grain, **no rounded cards**. A square *page* does not license modification of the rectangular sculpture source.

Each page shows: main source/proof, independently meaningful grayscale ink plates, correct ink-name/palette swatches, channel/screen/gain/angle/pitch/seed, DPI and true print dimensions, source SHA-256, paper stock, digital-proof disclaimer, and a QR to public **how-to** instructions (not an inaccessible private-file URL). Embed normalized recipes as PDF attachments and/or include accessible machine-readable reproducibility details. Explicitly state that replay also requires authorized possession of the original photo.

## 5. Acceptance and evidence
- [ ] Brand palette **exactly** extracted from unchanged original SVG, with test asserting the four HEX fills and original SVG SHA.
- [ ] Four genuine lowercase wordmarks (real `ā` glyph); no substitutions; font names/weights/versions and OFL attribution documented.
- [ ] One documented finalist per family, **chosen after** visual comparison.
- [ ] All three original owner photo SHA-256 values match the existing fixture manifest, and **no substitutions** are used.
- [ ] Exactly **3 PDF files × 2 pages**; correct square/landscape/portrait page boxes; full photo never stretched or accidentally cropped.
- [ ] Within a fixture, page 1 and 2 have identical photo/proof pixel hashes, ink masks, plate order, paper, design tokens, DPI and recipe; only font-related state changes.
- [ ] Typeface identity verifiable in actual embedded PDF fonts; all visible report copy lowercase.
- [ ] Embedded recipe(s) valid and QR resolves to real public reproduction instructions.
- [ ] Image-specific visual reviews per [owner acceptance criteria](https://github.com/yigit-denktas/stipra/blob/main/docs/PRINT-PACKAGE-ACCEPTANCE.md): sculpture ridges, forest detail/depth, beach gradient/horizon/people.
- [ ] PDF legibility at 100% and deterministic re-run evidence, with automated geometry/hash assertions and saved local artifact manifest. Do not mark physical-print tests passed without hardware evidence.
- [ ] Place original photographs and output PDFs in **private local artifacts only**; source scripts/tests/docs may go in MIT repository. Keep the README concise and original dotmark unchanged.
- [ ] Link a concise designer-facing comparison note, update #46/#9/#13/#34, and submit a tested PR. Do not adopt a brand font or replace the logo without owner visual approval.

## Out of scope
No new S-only logo, no 16-PDF explosion, no random color replacements, no generated placeholder imagery, no public uploading of owner images, no claim that a screen proof is an actual Risograph calibration. The job is **faithful comparison and reproducibility**, not a new style engine.

## Suggested implementation order
1. Extract and test SVG color tokens.
2. Render the 4 actual-font wordmarks and record the 2 finalists.
3. Hash-verify and load all 3 private owner photographs.
4. Freeze each fixture's image processing/plates/stock **once**.
5. Render the 6 matched pages into **3 PDFs**.
6. Programmatically verify page dimensions, PDF font objects, embedded recipes and per-fixture hashes; visually review all six pages; hand over locally.

**Completion gate:** three inspectable private PDFs and four authentic wordmark comparisons, not just an issue, mockup, test fixture or README change.

### Comment by yigit-denktas at 2026-10-17T02:14:28Z (https://github.com/yigit-denktas/stipra/issues/54#issuecomment-6228375866)

Implemented in PR #55: four authentic stiprā outlines, SVG-derived brand tokens, IBM Plex Sans Bold and Paper Mono ExtraBold finalists, and three private owner-photo PDFs (square A / landscape B / portrait C), two pages each. Original-photo hashes match the fixture catalog; normalized recipes and actual fonts are embedded. Paired pages have identical image pixels and nontext drawing geometry. Separate-directory builds reproduce PDF and recipe hashes. Local validation: 76 Node tests + 9 private Python checks passed. Images/PDFs are delivered privately, never committed or uploaded to Pages. See docs/TYPE-COMPARISON.md in #55 for evaluation and replay instructions. Owner aesthetic approval and physical-print verification remain open; no brand direction adopted. Public CI status is separate from private fixture verification.

### Comment by yigit-denktas at 2026-10-17T02:15:57Z (https://github.com/yigit-denktas/stipra/issues/54#issuecomment-6228391346)

Final verification: PR #55 is green in Verify Stipra run 38994120182 (https://github.com/yigit-denktas/stipra/actions/runs/38994120182), including the existing browser smoke checks and the new public Python source-contract checks. Private artifact suite: 9/9 passed; Node suite: 76/76 passed, no skips. Three exact two-page PDFs and the four-wordmark sheet are complete and privately delivered, with source/evidence bundle. All six pages visually inspected at 144 dpi. Separate output directories reproduce identical PDF, recipe, manifest, sheet and paper hashes. Technical deliverable complete; PR remains unmerged and branding remains provisional.

### Comment by yigit-denktas at 2026-10-17T10:06:50Z (https://github.com/yigit-denktas/stipra/issues/54#issuecomment-6232633747)

### Brand QA next review gate

The source-font/identity foundation is now merged as [PR #59](https://github.com/yigit-denktas/stipra/pull/59), adding real Paper Mono SemiBold and a macron-only accent in a clean three-contender study. This does **not** replace or invalidate the earlier three owner-photo PDFs, and does not complete their private visual/physical acceptance. Continue A/B/C two-page comparisons using original source hashes, canonical four SVG colors, and reported paper/ink recipes; maintain a strict public/private boundary around the photographs.

### Comment by yigit-denktas at 2026-10-17T10:22:18Z (https://github.com/yigit-denktas/stipra/issues/54#issuecomment-6232764663)

Takeover implemented in PR #61, preserving merged #58/#59 and the separate #55 typography study. Canonical PDFs now use regular/bold/mono roles with a 9pt minimum, full input SHA-256, all 2–8 plates with pagination, actual LPI/screen-off labels, existing overlap warnings and linked guide QRs. Fixed a verified missing-glyph box for ā by merging authentic Latin Extended outlines. Build and 93 Node tests pass (no skips). Three private A4 owner reports each have two pages, match hashes across separate output directories, and all six pages were visually reviewed at 144dpi. Owner photos/report images remain private. No final wordmark or default separation adopted; physical print and owner aesthetic approval remain open.

### Comment by yigit-denktas at 2026-10-17T11:07:50Z (https://github.com/yigit-denktas/stipra/issues/54#issuecomment-6233175651)

Reconciled PR #55 with current main and merged as 92b582e13b4206a8b349d63294c0c3e45c751540 after successful CI run 39027426379 (including browser smoke and Python source-contract tests). Locally: 96 Node tests passed, zero skips; 8 private artifact checks passed, repeat-build check skipped in this reconciliation run. Existing owner-photo PDF files were inspected in the earlier study and rechecked technically; no photo, raw font or image-bearing PDF was committed. docs/TYPE-COMPARISON.md now explicitly distinguishes this original controlled single-weight study from the later #61/#63 editorial report system and #59 identity study. Technical deliverable landed; branding remains provisional and physical print quality unverified.


## #56 — [Quality] Shared ink contribution, overlap and effective LPI diagnostics

- state: closed / completed
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T09:51:41Z; closedAt: 2026-10-17T09:57:10Z; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/56

### Body

Build an original dependency-free browser/Node diagnostics module that interprets independently separated ink coverage and screen configuration for artists and CLI agents. Report true numeric metrics, not fabricated machine-safe thresholds.

Acceptance:
- [ ] Per ink mean coverage, nonzero area, high-density fraction, mean-on-printed-area, and share of total nominal ink consumption (clearly labelled additive coverage, not physical ink volume).
- [ ] Joint ink overlap: fraction of pixels with ≥2 active inks, and ≥3 inks when applicable; strongest overlaps and per-pair overlap fractions.
- [ ] Effective per-plate LPI based on actual output DPI and actual pixel pitch (not guessed global LPI); solid screens report no LPI.
- [ ] Configurable *editorial review* warnings for near-unused passes, extreme overlaps and broad heavy fields; avoid universal press thresholds.
- [ ] Source grid and alpha/paper exclusion respected. No mutation of any original source, plate, recipe or output masks.
- [ ] Used by canonical `stipra package` manifest and documentation; use the same module in browser when integration is justified; tests for 2 and 3 ink masks, edge cases and pure calculations.
- [ ] Explicit limitations: numbers cannot identify antlers, faces, fine lettering, moiré or print outcome; actual A/B/C visual and physical QA remain open.

Connected to #43 forest depth, #34 Styles, #8/#9/#12 print exports, #13 QA and #10 diagnostic overlays.


## #57 — [Identity] Three-contender wordmark, macron-only accent and original dotmark cohesion

- state: open / None
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T09:51:44Z; closedAt: None; comments: 2
- url: https://github.com/yigit-denktas/stipra/issues/57

### Body

Owner declined the standalone S. Two design reviews disagree on Paper Mono Regular vs ExtraBold; do not settle it by assertion. Preserve current `logo_for_Readme.svg` in README and use the actual 4 original SVG swatches.

Controlled candidate set: IBM Plex Sans Bold; Paper Mono Regular; Paper Mono intermediate weight **only if an authentic upstream SIL OFL face exists**. If no genuine intermediate Paper Mono weight exists, explain it and compare Regular and ExtraBold as-is rather than synthesizing a fake medium/bold font. Ensure real `ā` glyph, text shaping/kerning verified, proper optical spacing.

For each candidate: true monochrome wordmark, whole-word green with only coral macron, restrained 2-ink overprint with evidence the word stays one unit, and optional wordmark+original five-row dotmark relationship. No invented standalone S; use source asset, not a redrawn imitation. Test 24/48/96 px and full-size physical paper, geometric optical balance, crisp dot rendering. Document which version wins *and why*, not just color preference. Do not adopt/change README logo without explicit owner approval.

Use real vector/PDF assets through Stiprā code; do not use image generation or redistribute standalone font files. Keep three owner photos private. Refer to #46, #52, #54, #31.

### Comment by yigit-denktas at 2026-10-17T10:04:58Z (https://github.com/yigit-denktas/stipra/issues/57#issuecomment-6232616112)

### Typeface source verification

The official [Paper Mono v1.000 release](https://github.com/paper-design/paper-mono/releases/tag/v1.000) contains genuine Medium, SemiBold and Bold weights, so interpolating a fake intermediate or blindly choosing ExtraBold is unnecessary. [PR #59](https://github.com/yigit-denktas/stipra/pull/59) creates a comparison using actual **IBM Plex Sans Bold**, **Paper Mono Regular**, and **Paper Mono SemiBold**, normalized by x-height, with independent monochrome, coral **macron-only** overlay and original five-row dotmark as companion. Tests assert unmodified original SVG, true glyph outlines, font checksum and source palette. Aesthetic result pending owner decision and real-small-print judgment; no approved logo change. Current CI rerun in progress following one browser smoke timeout, not a font source/build failure.

### Comment by yigit-denktas at 2026-10-17T10:06:45Z (https://github.com/yigit-denktas/stipra/issues/57#issuecomment-6232633063)

### Update — PR #59 merged, 17 Oct 2026

Real identity generator and study have shipped on `main`: [PR #59](https://github.com/yigit-denktas/stipra/pull/59), [live three-font comparison](https://apps.yigitdenktas.com/stipra/identity/), [design review protocol](https://github.com/yigit-denktas/stipra/blob/main/docs/BRAND-IDENTITY-STUDY-v2.md). Real IBM Plex Sans Bold, Paper Mono Regular and verified v1.000 SemiBold, all actual lowercase `stiprā` outlines. Black one-ink vs full green word with **coral macron only**, and companion original five-row dotmark at 24/48/96px. No image generation, no raw font binaries published. Node/Pages/Chromium CI succeeded after a transient second-import smoke timeout in the first attempt; rerun passed. **Issue remains open intentionally** for optical spacing, visual glyph/micron clipping checks and physical small-print owner approval. Original README logo remains unchanged.


## #60 — [Reports] Readable editorial hierarchy and complete physical-screen settings

- state: closed / completed
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T10:12:28Z; closedAt: 2026-10-17T10:28:56Z; comments: 2
- url: https://github.com/yigit-denktas/stipra/issues/60

### Body

Type: Feature · Area: Reports · Priority: P1 · Target: v0.9

Takeover follow-up after owner review: canonical report text is 7.2–8pt, while the separate #55 study intentionally uses one heavy face throughout. Improve the production report without changing separation recipes or adopting a final logo.

Dependencies/related: #9 #45 #54 #55 #56 #43; diagnostics merged in #58; identity study merged in #59. Existing original SVG and private owner-photo policy remain unchanged. No project/milestone identifier has been verified for this issue.

Acceptance:
- [ ] Real role-based typography: display, headings, regular body and numeric settings; technical text at least 9pt.
- [ ] Separate visual inspection from recipe/provenance information instead of shrinking content to one sheet.
- [ ] All 2–8 ink plates and settings retained, with bounded pagination and no overlapping/out-of-page text.
- [ ] Full source SHA-256, embedded normalized recipes, actual DPI/physical size, LPI (off for solid), and existing overlap/contribution diagnostics visible.
- [ ] Source, masks, plate geometry, paper and frozen recipes unchanged by report-only changes.
- [ ] Tests cover 2/3/8 inks, portrait/landscape, long names, actual PDF font sizes/bounds and deterministic output.
- [ ] Private original A/B/C reports rendered and visually inspected; publish source/tests only; owner aesthetic approval and physical-print validation remain open.

Expected outputs: a tested PR and privately delivered revised owner-photo reports with reproducibility evidence. This is a report improvement, not a new wordmark or a claimed automatic forest repair.

### Comment by yigit-denktas at 2026-10-17T10:22:15Z (https://github.com/yigit-denktas/stipra/issues/60#issuecomment-6232764261)

Takeover implemented in PR #61, preserving merged #58/#59 and the separate #55 typography study. Canonical PDFs now use regular/bold/mono roles with a 9pt minimum, full input SHA-256, all 2–8 plates with pagination, actual LPI/screen-off labels, existing overlap warnings and linked guide QRs. Fixed a verified missing-glyph box for ā by merging authentic Latin Extended outlines. Build and 93 Node tests pass (no skips). Three private A4 owner reports each have two pages, match hashes across separate output directories, and all six pages were visually reviewed at 144dpi. Owner photos/report images remain private. No final wordmark or default separation adopted; physical print and owner aesthetic approval remain open.

### Comment by yigit-denktas at 2026-10-17T10:23:33Z (https://github.com/yigit-denktas/stipra/issues/60#issuecomment-6232775794)

Final evidence: Verify Stipra run 39024589390 passed on PR #61 (https://github.com/yigit-denktas/stipra/actions/runs/39024589390), including existing browser smoke checks. Local suite: 93/93, no skips. Three two-page canonical A4 reports, private forest comparison, and verification/recipe evidence bundle are delivered privately. #61 remains unmerged; no logo adoption, default forest recipe change, physical-print claim or owner aesthetic sign-off was made.


## #62 — [Reports] Ink-linked annotations and deterministic speckled paper

- state: closed / completed
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T10:32:57Z; closedAt: 2026-10-17T11:05:24Z; comments: 2
- url: https://github.com/yigit-denktas/stipra/issues/62

### Body

Type: Feature · Area: Reports / paper · Priority: P1 · Target: v0.9

Owner reference: private annotated print-separation sheet, discussed after #61. Adapt the numbered labels, sharp framing, ink-linked annotation colors and warm dotted stock; do not copy its artwork or imply its Pantone/press claims. Logo stays lowercase stiprā; other text casing is editorial discretion.

Related #9 #45 #60 #34. No verified project/milestone ID available.

Acceptance:
- [ ] Report annotations/rules derive from actual chosen separation inks; pale inks retain readable key text.
- [ ] Deterministic speckled/fibrous report paper, with consistent physical texture scale across portrait/landscape.
- [ ] Keep existing stocks and add explicit, named paper options without altering default automatic stock selection or brand swatches.
- [ ] Presentation texture never modifies source bytes, normalized recipes, continuous masks or screened production plates.
- [ ] Preserve #61 legibility, full hashes, real ā, pagination and recipe evidence; no rounded cards.
- [ ] Render and review private owner-photo examples; tests and CI pass; photographs stay private.

Expected outputs: a reviewable PR, private revised PDF examples and a paper/theme comparison. Physical paper/ink simulation remains uncalibrated.

### Comment by yigit-denktas at 2026-10-17T10:39:58Z (https://github.com/yigit-denktas/stipra/issues/62#issuecomment-6232924246)

Implemented in PR #63. Reports now use actual separation colors for readable annotation keys, bars, rules and plate borders; lowercase logo preserved. Deterministic 144dpi micrograin/fibres/ink-colored speckles use existing Canvas, with speckled/fibre/none controls. Existing auto stock decisions unchanged; explicit Rose Pulp, Sage Stock and Blue Mist added alongside the existing four. Build and 96 tests pass (zero skips), including byte-identical source, proof, normalized recipes and production masters when only report texture changes. Three two-page owner reports and seven-stock swatch preview reviewed privately; all six PDF pages rendered at 144dpi. Art/reference screenshot not committed; physical texture remains a simulation. Private review bundle delivered for owner review.

### Comment by yigit-denktas at 2026-10-17T10:40:28Z (https://github.com/yigit-denktas/stipra/issues/62#issuecomment-6232929770)

CI verification: Verify Stipra run 39025717468 test job completed successfully, including browser smoke checks. PR #63 remains unmerged for review of the private PDF/paper examples; no automatic brand adoption or physical-print certification.


## #65 — [Feature] Public reproduction guide, dual Pages build and branded QR specimens

- state: closed / completed
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T11:48:06Z; closedAt: 2026-10-17T12:06:17Z; comments: 2
- url: https://github.com/yigit-denktas/stipra/issues/65

### Body

Type: Feature · Area: Reports / documentation / hosting · Priority: P1 · Release target: v0.9 · Assignee: @yigit-denktas. No verified native Project/milestone IDs available.

Implemented and deployed via #66, squash commit 3e42173dfbd5c34e085ec5688357997de51be32d.

- [x] Primary app retained: https://apps.yigitdenktas.com/stipra/
- [x] Public guide live and inspected: https://apps.yigitdenktas.com/stipra/guide/
- [x] Free GitHub Pages app mirror live: https://yigit-denktas.github.io/stipra/
- [x] Mirror guide and its return-to-studio navigation verified at https://yigit-denktas.github.io/stipra/guide/ ; canonical link retains primary guide.
- [x] Separate Pages workflow, same source build, project-root staging avoids doubled path. Pages source actually configured as GitHub Actions; no DNS/custom-domain change.
- [x] Three deterministic branded QR specimens with authentic lowercase stiprā outlines, coral macron, original SVG palette, structural protection, H correction and four-module clean margin. Default brand-dots at 25.4 mm; explicit square and ink-linked alternatives.
- [x] 98 Node tests passed, zero skips; 58 PDF specimen/report decode checks passed at documented sizes/resolutions. Responsive built-guide/browser smoke passed. Final CI run 39030873739 and Pages deployment 39031068233 succeeded.
- [x] Report layout version 5 records QR treatment/destination. Source/tests/docs only committed; owner photos and image-bearing reports stay private.

Related #9 #22 #47 #62. Photo-free QR PDF, preview and SVG/review bundle delivered privately. Physical phone/paper scanning is still unverified and is not claimed by digital decoding acceptance.

### Comment by yigit-denktas at 2026-10-17T12:03:07Z (https://github.com/yigit-denktas/stipra/issues/65#issuecomment-6233659219)

Implemented in #66: designed public guide, one source for Cloudflare /stipra and GitHub project-root deployment, true lowercase shaped wordmark QR in three styles and 25.4 mm report QR. GitHub Pages source was actually changed from disabled/branch publishing to GitHub Actions through repository settings; existing Cloudflare main deployment/DNS retained. Preview visually reviewed; no owner imagery published. Local 98 Node tests pass; all 58 PDF specimen/report decode checks pass. CI run 111 passed including responsive guide/browser tests; current final metadata-version head is awaiting rerun after a transient pre-existing PNG-input smoke timeout. Live production/mirror destination verification still pending.

### Comment by yigit-denktas at 2026-10-17T12:13:12Z (https://github.com/yigit-denktas/stipra/issues/65#issuecomment-6233745865)

Owner selected ink-dots. Applied consistently to renderer, report fallback/audit, package API and CLI defaults in #67; merged after successful CI run 39031475425 including QR decode checks. QR color follows the readable report theme. Square and green-dot styles remain available explicitly; encoding, wordmark and geometry are unchanged. The pending Styles PR #64 also preserves this selection.


## #70 — [Feature] Creative coding alpha: sketch → ink proof → reproducible plates

- state: open / None
- author: yigit-denktas; labels: ['enhancement']; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T13:21:48Z; closedAt: None; comments: 10
- url: https://github.com/yigit-denktas/stipra/issues/70

### Body

## Agent-authored creative-use trial — PR #118, 19 October 2026

[PR #118](https://github.com/yigit-denktas/stipra/pull/118) exercises the published core alpha.1 in a clean one-package consumer with original two-ink editorial artwork. Repeat masks are identical; the published-core proof matches the shared exporter after decoding. The authored snapshot replays to identical decoded proof and continuous/screened plates. The package verifier passes and both portrait report pages were visually reviewed. Full site build and 189 Node tests pass locally, zero skipped. Source/evidence are in the PR; no owner photographs or generated image-bearing package is committed.

Concrete finding: existing solid/hybrid per-ink screens preserve contour/fine-line intent better than all-dot screening for this drawing. The optional report exporter required the documented verified-font cache; the lean core remains font/PDF/ZIP independent. No new effect, dependency or shared default was needed.

This is an agent-authored workflow trial, not independent artist feedback, a p5 runtime trial, Kushluk integration or physical validation. Keep #70 open for its remaining usefulness scope. Studio v0.9.0-rc.1 publication is separate from the unchanged npm alpha.1.

---

## Studio candidate follow-up — 19 October 2026

[PR #116](https://github.com/yigit-denktas/stipra/pull/116) prepares a separate experimental browser Studio candidate and exact-run site artifact. The three npm packages remain published at immutable alpha.1; this preparation neither republishes them nor creates a GitHub release. Independent artist usefulness testing is explicitly owner-deferred, not performed or passed. #70 remains open for that evidence; human accessibility and physical acceptance remain separately tracked in #13, native notices in #14.

---

**Type:** Feature tracking · **Area:** Creative coding / public API · **Priority:** P1 · **Scope:** small JavaScript library alpha · **Release target:** Experimental creative coding alpha 0.1.0-alpha.1 · **Owner:** @yigit-denktas
**Native tracking:** [private Project #3](https://github.com/users/yigit-denktas/projects/3) is reused; original studio backlog is in [v0.9](https://github.com/yigit-denktas/stipra/milestone/1). #17 retains board/workflow checks. This issue is a milestone tracker, not a native GitHub milestone.

## Current status — 18 October 2026

The three `@yigit-denktas/stipra-core`, `stipra-canvas` and `stipra-inputs` packages are public at `0.1.0-alpha.1`. Fresh downloads match the original upload record in SHA-256, SHA-512 and byte count. An initially empty-cache registry consumer installs exactly those three packages with lifecycle scripts disabled and passes public runtime/replay, ESM/CJS and strict TypeScript checks. This supersedes the earlier registry 404 observation. Evidence and documentation reconciliation: PR #104, docs/evidence/npm-alpha-registry-2026-10-18.json; original upload record preserved.

Both `alpha` and `latest` currently point to alpha.1. Public `0.0.0-stage` versions are also observed; their origin is not established by verification. No registry tags, versions or packages were changed by this work.

Independent artist usefulness feedback remains unperformed; this tracker remains open for that review. The supplied AI-assisted rendering/artifact review does not count as an artist trial. Physical-print and human accessibility observations remain open in #13. Native Skia is excluded from these lean packages and retains its separate #14 finding. No additional framework or Processing Java implementation is required for this alpha.

## Owner's goal

Inputs include photographs, scans/photographs of handmade artwork, and generated Canvas/p5.js drawings. Keep photographic file color/alpha/provenance handling and artist-authored ink assignments as two explicit paths.

Use Stiprā directly inside an existing p5.js sketch: draw artwork, apply an ink/paper/screen treatment, draw the proof back into the sketch, then optionally export real aligned ink plates and a reproducible recipe. Ordinary Canvas users should use the same engine. Processing Java requires a separate bridge investigation.

## Sequence and gates
1. Finish the bounded foundation: resolve report/export PR #69; document and test the normalized RGBA/alpha/color contract (#44); verify shared mask/master geometry and export semantics (#8, #12, #13); complete the shipped dependency/asset audit (#14).
2. Build one end-to-end Canvas/p5.js alpha using the existing engine and shared Styles (#47), with explicit experimental status until its own release checks pass. Pure RGBA prototyping may proceed before file-decoder ICC policy is finished; no silent claim of browser/CLI source-file parity.
3. Measure usefulness before adding GPU execution, more frameworks or a Java port.

Physical-print observations remain required for print-quality claims (#13), but do not block a clearly experimental screen-effect demo. Broad format/vector work (#12, #28), optional paper realism (#4) and identity polish are not prerequisites.

## Candidate value, to validate

Commercial-use requirement: Kuşluk must not depend on restricted p5.riso code. p5.grain's actual upstream LICENSE was verified on 17 October 2026 as MIT; compatible reuse with notices is an option and does not require a license-driven rewrite. No p5.grain dependency has been added.

Existing p5.riso, p5.grain and canvas-sketch already cover substantial drawing, texture and print-export workflows. p5.riso also documents LPI-based halftones; physical-frequency controls alone are not a differentiator. Test whether Stiprā adds a useful connection between an existing sketch, independently inspectable plates, physical LPI/DPI, versioned styles and reproducible browser/CLI packages. This is a product hypothesis, not a claim of an empty market.

## Alpha acceptance
- [x] Public-input/output contract and lean JS packaging, with optional heavy export dependencies.
- [x] Existing Canvas and p5.js sketches can display a treatment without downloading and reimporting a file.
- [x] Both flattened-artwork separation and artist-authored ink masks are supported.
- [x] Same frozen source/layers + recipe + seed yield the validated production masks; proof texture/registration remain separate from master geometry.
- [x] Runnable Canvas, p5 global and p5 instance examples, measured performance and explicit compatibility limits.
- [x] Release evidence includes public rights-cleared samples, diagnostics, aligned plates, normalized recipes and package contents; no owner photographs.
- [x] Compare one fixed artwork/task with direct existing tools; narrow or stop the SDK if it provides no useful improvement.

No drawing-language replacement, sketch IDE, cloud service or unconditional 60fps promise. API names/package names remain design work; publication follows alpha acceptance.

## Sources
- https://antiboredom.github.io/p5.riso/
- https://github.com/josephmiclaus/p5.grain
- https://github.com/mattdesl/canvas-sketch
- https://p5js.org/reference/p5/pixelDensity/
- https://processing.org/environment/

## Work breakdown
- [x] #71 — Lean engine contract and packaging
- [x] #72 — Canvas/p5.js in-sketch adapter
- [x] #73 — Artist-authored ink layers
- [x] #74 — Performance, export parity and usefulness gate
- [ ] #75 — Processing Java feasibility (later; outside alpha)

Processing research is deliberately outside the alpha completion criteria.

## Historical implementation record

The notes below describe earlier private candidates; current identity, authorization and upload status are stated above.

### Recorded plan
Roadmap and design note: #76 (documentation only; SDK implementation remains open).

Core foundation #71 is merged in #78 (private local package, zero runtime dependencies). Host integration and authored-layer export #72/#73 are merged in #79. Canvas, p5 global and p5 instance examples are at https://apps.yigitdenktas.com/stipra/sketches/ . CI run 39041596085 passed. The overall alpha remains open: #74 engineering/evaluation is merged in #80: measured performance, six browser/Node/CLI parity cases, a bounded frozen-frame draft/final helper and a documented existing-tool workflow comparison. Evidence: https://github.com/yigit-denktas/stipra/blob/main/docs/CREATIVE-CODING-ALPHA.md . Final CI 39043114456 passed. This tracker remains open for the owner's alpha/publication acceptance; the external-tool comparison is documentation-based, not an independent artist trial. Packages remain private. Full export notices (#14) and print calibration (#13) remain open.

## Structured-input research after the alpha
#81/#82 are merged in #87: current architecture and PNG interpretation are documented/tested. #83–#86 are now completed in #89: named-region mapping, optional inert source projects, exact snapshot/region replay and bounded C2PA/OpenRaster/auxiliary pilots with explicit deferrals. This is additional post-alpha scope, not retroactively part of the completed #71–#74 engineering tasks or a registry-release claim. Preserve existing source structure when available, map regions into final ink masks outside the core, and keep codecs/provenance validation optional. See docs/STRUCTURED-ARTWORK.md. Owner alpha/publication acceptance and existing #14/#13 gates remain open.

## Unified delivery record

#91/#90 reconcile studio acceptance, the notice audit and a source-backed dependency/version map, changelog and site navigation. #14 is down from five findings to three; no broad export-distribution clearance is claimed. Owner/artist acceptance and the publication decision remain here. Library version targets and studio v0.9 acceptance are separate; optional #75/#28/identity work do not become alpha prerequisites. See docs/data/delivery-ledger.json after #91 lands.

## Exact lean candidate — PR #94

`npm run check:library-candidate` produces the three private 0.1.0-alpha.0 archives and a library-candidate.json evidence report. It installs those same audited archives together offline, checks the installed graph contains exactly core/Canvas/inputs, and exercises public package export maps, strict NodeNext types, ESM/CJS parity, capture → regions → authored inks → core, and inert source-project replay. The synthetic Canvas fixture checks capture/mapping; real Chromium/p5 remains separate CI evidence. Local Node24 and CI Node20 produce matching bytes for all three archives. CI artifact: lean-distribution-audit in the PR #94 run.

This is a usable review candidate, not registry publication or a completed independent artist trial. Packages remain private; no version tag, final branding, owner-photo rights or calibrated print approval is implied. Optional exporter/native distribution retains #14's separate three findings. Current decision and artifact scope: docs/RELEASE-CANDIDATE.md.

### Historical pre-authentication handoff (superseded)

PR #95 removes opaque fontkit/fonteditor artifacts from intended distributions; native Skia remains a separate broad-export finding. The lean three-package candidate remains private. Artist task/blank observation record is prepared, not performed. A real `npm whoami --registry=https://registry.npmjs.org` check returned ENEEDAUTH; an authenticated publisher and authority over the final npm scope are not established. No registry release/tag or simulated artist acceptance. See docs/ARTIST-TRIAL.md in the follow-up package.


## 19 October acceptance follow-up — merged PR #110

The exact alpha.1 library remains published. A concrete independent trial handoff with exact-version setup and a blank observation record is prepared. No independent participant or completed artist record is supplied, and no invitation was sent to an unnamed person. Agent/software rehearsals do not satisfy this gate. Keep the usefulness acceptance open.

Merged as `9ad3325884e58b401c188750e62169e7803073c9`; exact head `7ff2f5a` passed all [75 CI steps](https://github.com/yigit-denktas/stipra/actions/runs/39222373464). All 187 Node tests pass locally, along with scoped release gates and saved artwork/plate goldens. [Concrete handoff and review](https://github.com/yigit-denktas/stipra/blob/main/docs/ACCEPTANCE-2026-10-19.md) · [numeric evidence only](https://github.com/yigit-denktas/stipra/blob/main/docs/evidence/acceptance-quality-2026-10-19.json). Owner photos and image-bearing outputs remain private; no public image attachment or native redistribution.


### Comment by yigit-denktas at 2026-10-17T21:03:36Z (https://github.com/yigit-denktas/stipra/issues/70#issuecomment-6241015255)

Merged PR #94 as 3d1cb3d42ab76e7c7bd8121e8d32b0fa5874a449. Exact reviewed head 4ad95c4: https://github.com/yigit-denktas/stipra/actions/runs/39069080661 passed all 67 steps. Local full suite: 159 passed, zero skipped. Review evidence: procedural-acceptance-goldens artifact 12114054416; lean-distribution-audit artifact 12114800654 contains the three tested private tarballs and library-candidate.json. Downloaded candidate archive hashes match the report and are identical between local Node24 and CI Node20. Actual operator printing, wider human/artist acceptance, the three upstream inventories and registry publication remain separate open work, as specified in docs/RELEASE-CANDIDATE.md. No owner imagery or new runtime dependencies were committed.

### Comment by yigit-denktas at 2026-10-17T22:32:00Z (https://github.com/yigit-denktas/stipra/issues/70#issuecomment-6242326617)

Release handoff is now merged in #97: docs/ARTIST-TRIAL.md and examples/alpha/artist-trial-record.json provide the bounded real-user task/empty record. CI 39075159757 passed all 74 steps; exact core/Canvas/inputs tarballs in lean-distribution-audit artifact 12115908894 install offline, exercise public ESM/CJS/types/replay, and match local Node24 / CI Node20 byte-for-byte. These remain private 0.1.0-alpha.0 candidates. Actual npm publisher check returned ENEEDAUTH; final account/scope authority is unestablished. No registry release/tag or independent artist/owner acceptance claimed. Native Skia remains isolated from the lean packages; physical tests gate print claims separately.

### Comment by yigit-denktas at 2026-10-18T02:48:30Z (https://github.com/yigit-denktas/stipra/issues/70#issuecomment-6244883164)

Owner selected a personal npm scope in this session. The exact npm username is still needed; do not assume it matches the GitHub login or rename packages to an unverified account. Current npm whoami still returns ENEEDAUTH. Existing @stipra/* names remain private review placeholders until the actual personal scope is supplied and authenticated. No registry publication claimed.

### Comment by yigit-denktas at 2026-10-18T02:53:00Z (https://github.com/yigit-denktas/stipra/issues/70#issuecomment-6244917493)

Publisher setup clarified: personal npm scope selected, but no npm account exists yet. Account creation must precede exact namespace selection and authentication. The packages remain private; do not infer a username from GitHub or create/store passwords, tokens or one-time codes in repository/chat. The candidate and independent artist task remain available. #100 records the handoff; no registry publication or artist/physical acceptance is claimed.

### Comment by yigit-denktas at 2026-10-18T10:31:01Z (https://github.com/yigit-denktas/stipra/issues/70#issuecomment-6248779318)

The owner supplied verified npm account yigit-denktas and authorized the experimental release. PR #101 prepares @yigit-denktas/stipra-core, stipra-canvas and stipra-inputs at 0.1.0-alpha.1, matching peers and public import examples. The audit now rejects altered publication identity/version/registry/tag. All 163 local tests and the exact-tarball combined offline consumer pass; CI is running. CLI web authentication is awaiting the owner; nothing has been published. Physical prints and independent artist/human accessibility acceptance remain open.

### Comment by yigit-denktas at 2026-10-18T10:34:32Z (https://github.com/yigit-denktas/stipra/issues/70#issuecomment-6248809872)

PR #101 passed all 74 CI steps (run 39119530086) and is merged. All 163 local tests, saved geometry/artwork goldens, exact offline consumer, and npm publication dry-runs pass. Prepared packages are @yigit-denktas/stipra-core, @yigit-denktas/stipra-canvas and @yigit-denktas/stipra-inputs at 0.1.0-alpha.1. Dry-run integrity matches each audited tarball. Nothing is published yet: npm web authorization is pending. This issue remains open for registry verification and independent artist acceptance; no physical-print quality claim is made.

### Comment by yigit-denktas at 2026-10-18T11:24:42Z (https://github.com/yigit-denktas/stipra/issues/70#issuecomment-6249337061)

npm web login now succeeds and npm whoami confirms yigit-denktas. Account reports active auth-and-writes 2FA. Attempted publication of the exact audited core alpha.1 archive was rejected by npm with E403: 'Two-factor authentication or granular access token with bypass 2fa enabled is required to publish packages.' The CLI did not issue an EOTP/browser approval challenge. No successful package publication occurred; Canvas and inputs were not attempted. Registry publication remains blocked on publication authorization, separate from successful login and passing package/CI checks. No credentials are included in this record.

### Comment by yigit-denktas at 2026-10-18T11:32:13Z (https://github.com/yigit-denktas/stipra/issues/70#issuecomment-6249404616)

The owner approved the npm passkey challenge. Explicit --auth-type=web --browser=false produced the normal browser challenge and core publication returned success; Canvas and inputs then returned success using the approved session. npm reports all three uploads are processing. Public registry lookup still returns 404, so downloadable hashes and a clean registry install are not yet verified. PR #102 records the exact accepted tarball SHA-256/integrity values and this status. Do not republish or bump the accepted versions merely to get past registry processing.

### Comment by yigit-denktas at 2026-10-18T11:36:29Z (https://github.com/yigit-denktas/stipra/issues/70#issuecomment-6249443104)

PR #102 is merged at 09b6ebdd24605ae0e645c0767c2c98ee82e2ff2d after all 74 CI steps passed (run 39123624472). Accepted-upload SHA-256/integrity records are committed in docs/evidence/npm-alpha-upload-2026-10-18.json. Registry still returns 404 on the subsequent availability checks, including a no-cache request; downloadable archive identity and clean registry installation therefore remain unverified. Upload acceptance is recorded without claiming public availability, complete release acceptance or physical validation. No further owner approval has been requested by npm.

### Comment by yigit-denktas at 2026-10-18T11:46:21Z (https://github.com/yigit-denktas/stipra/issues/70#issuecomment-6249530632)

Reconciliation PR #103 merged at 71358d551e4ac0fa86070d8edd40b19b8c1e027b after all 74 CI steps passed (run 39124373627); seven focused local checks passed. Removed obsolete account-creation instructions and updated current bodies for #13/#14/#43/#47/#70. Exact alpha.1 uploads remain accepted but registry availability/download identity/clean install remain unverified (404 on latest check). Independent artist and physical observations remain unperformed. Existing roadmap/design PR #98 was not changed. Owner-authorized native request could not be posted: GitHub integration returned HTTP 403; browser fallback is pending.


## #71 — [Feature] Define the lean JavaScript engine contract and package boundary

- state: closed / completed
- author: yigit-denktas; labels: ['enhancement']; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T13:22:33Z; closedAt: 2026-10-17T14:12:27Z; comments: 1
- url: https://github.com/yigit-denktas/stipra/issues/71

### Body

**Area:** Engine / packaging · **Priority:** P1 · **Scope:** public JS contract · **Release target:** Creative coding alpha
**Owner:** @yigit-denktas · **Tracking:** #70 · **Native milestone / Project:** pending #17; this release target is planning text.

**Dependencies:** #69 integration outcome; #44 normalized color contract; #14 shipped license audit. Related #11, #47.
## Work and acceptance
- [x] Inventory and reuse existing separation, screen, Styles and diagnostics modules; keep a single implementation for studio, CLI and SDK.
- [x] Define versioned inputs/outputs: explicit width/height, normalized sRGB RGBA/alpha semantics, typed-array ownership, recipes/seeds, physical DPI/LPI, errors and unsupported settings.
- [x] Define separate render/proof and production-mask results; preserve full-frame origin, alpha and independent substrate.
- [x] Provide a browser ESM entry and TypeScript declarations; select other entry formats only against runnable host needs. Keep p5 optional.
- [x] Core import is DOM-independent and does not pull in PDF, fonts, QR, ZIP, Node codecs or UI. Audit actual packed contents and transitive dependency graph, not only tree-shaking assumptions.
- [x] Document deterministic guarantees and decoder differences; no cross-host byte-equality promise for encoded PNG/PDF.
- [x] Contract tests cover repeatability, invalid dimensions, alpha edges, non-square frames and shared browser/Node masks.
**Evidence:** API design document, packed-file/dependency report, rights-cleared RGBA fixture and contract test output. No registry publication in this task.

## Verification
Implemented and merged in #78. CI run [39039527003](https://github.com/yigit-denktas/stipra/actions/runs/39039527003) passed: 124 Node tests without skips, real-browser core ESM parity plus existing browser workflows, independent color-reference verification and PDF/font/QR checks. The tested core tarball and build/package report are attached to that run as `core-package-report`.

Private local package, not a registry release. ESM measured locally at 37,989 bytes / 13,954 gzip, CJS 37,272 / 13,646; tarball 34,984 bytes. Exact graph/file hashes and clean offline installation/TypeScript checks are in the generated report. Only Stiprā-authored modules are bundled; zero runtime dependencies. The broader application audit #14 remains open. Host adapters, transparent effects, authored-layer export integration and performance/usefulness acceptance remain #72–#74.

### Comment by yigit-denktas at 2026-10-17T14:10:02Z (https://github.com/yigit-denktas/stipra/issues/71#issuecomment-6234895924)

Implemented in #78. The private local @stipra/core alpha wraps the existing separation/screen/Styles/diagnostics/geometry modules; no second rendering implementation. Inputs are declared sRGB RGBA or authored full-frame coverage. Proof and production buffers are separately owned, with proof offsets excluded from master masks.

Local verification: 124 tests, no skips; full public build; clean offline tarball installation with exactly one installed package and zero runtime dependencies; ESM/CJS and strict TypeScript consumers; isolated VM without DOM/process/Buffer; malformed input, alpha, ownership, non-square frame, repeatability and shared-engine parity checks.

Measured ESM 37,989 bytes / 13,954 gzip; CJS 37,272 / 13,646; tarball 34,984 bytes (actual file list and hashes in the generated package report). CI adds a real-browser ESM check and uploads the tested tarball/report. No registry publication or physical-print claims. Final CI pending.


## #72 — [Feature] Apply Stiprā treatments inside existing Canvas and p5.js sketches

- state: closed / completed
- author: yigit-denktas; labels: ['enhancement']; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T13:22:34Z; closedAt: 2026-10-17T14:41:29Z; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/72

### Body

**Area:** Canvas / p5.js adapter · **Priority:** P1 · **Scope:** in-sketch treatment · **Release target:** Creative coding alpha
**Owner:** @yigit-denktas · **Tracking:** #70 · **Native milestone / Project:** pending #17; this release target is planning text.

**Dependencies:** engine contract #71. Related #22, #47.
## Work and acceptance
- [x] Thin adapter accepts an existing HTML canvas or p5.Graphics/main sketch canvas, with no export/reimport step or new drawing API.
- [x] Return a drawable proof plus access to plates/diagnostics; support both whole-image processing and compositable treatment over an existing sketch where meaningful.
- [x] Prove p5 global and instance modes without patching the artist's random/noise state or polluting global names.
- [x] Handle logical versus backing-pixel dimensions explicitly at pixelDensity 1 and 2; document 2D support and test supported p5 versions. WEBGL capture support must be demonstrated or explicitly limited.
- [x] Treat source and destination separately so repeated draw() calls do not accidentally feed the treated proof back into its own separation.
- [x] Freeze texture by default with explicit seed/frame controls for animation; preserve artist alpha. Explain which effects are proof-only.
- [x] Report tainted/cross-origin canvas and unsupported-color errors clearly. No uploading artwork.
**Evidence:** runnable vanilla Canvas, p5 global and p5 instance examples; screenshot/plate fixtures; browser tests including density, alpha and a changing sketch frame.

Implemented in #79 (merge 7395e38b553ca8fd8cf3d1a7fd918b1e0e8b79a2). CI run 39041596085 passed: 130 Node tests, actual p5 1.11.11/2.2.2 at density 1/2, global/instance examples, frozen-frame image/authored exports and real tainted-canvas rejection. Authored mask bytes, screened masters, raw hashes and Node replay are verified. Hosted examples and a rendered authored PDF were visually reviewed.

Try https://apps.yigitdenktas.com/stipra/sketches/ . Adapter documentation: https://github.com/yigit-denktas/stipra/blob/main/packages/canvas/README.md . Experimental 2D support; performance/usefulness acceptance remains #74, full export notice findings remain #14 and physical print validation remains #13.


## #73 — [Feature] Accept artist-authored ink layers without reverse-separating the composite

- state: closed / completed
- author: yigit-denktas; labels: ['enhancement']; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T13:22:35Z; closedAt: 2026-10-17T14:41:29Z; comments: 1
- url: https://github.com/yigit-denktas/stipra/issues/73

### Body

**Area:** Ink layers / creative coding · **Priority:** P1 · **Scope:** authored-mask input · **Release target:** Creative coding alpha
**Owner:** @yigit-denktas · **Tracking:** #70 · **Native milestone / Project:** pending #17; this release target is planning text.

**Dependencies:** engine contract #71. Related #8, #10, #47.
## Why
A creative coder often already knows which shapes belong to each ink. Flattening that knowledge into RGB and estimating the layers again loses useful information.
## Work and acceptance
- [x] Accept independently authored grayscale coverage buffers/canvases with ink identities and one explicit shared frame.
- [x] Define coverage polarity, numeric range, alpha handling, layer order and mask precision; reject mismatched dimensions instead of cropping/rescaling silently.
- [x] Use the same screening, physical frequency, compositing, diagnostics and export path as image-derived masks.
- [x] Paper texture and preview registration never contaminate production plate geometry.
- [x] Preserve solid marks when requested; do not screen text automatically.
- [x] Demonstrate artist-authored two/three-ink graphics plus flattened-canvas separation as distinct workflows.
**Evidence:** rights-cleared procedural example, per-ink unscreened/screened masks, proof, normalized recipe and tests proving expected authored coverage survives export.

Implemented in #79 (merge 7395e38b553ca8fd8cf3d1a7fd918b1e0e8b79a2). CI run 39041596085 passed: 130 Node tests, actual p5 1.11.11/2.2.2 at density 1/2, global/instance examples, frozen-frame image/authored exports and real tainted-canvas rejection. Authored mask bytes, screened masters, raw hashes and Node replay are verified. Hosted examples and a rendered authored PDF were visually reviewed.

Try https://apps.yigitdenktas.com/stipra/sketches/ . Adapter documentation: https://github.com/yigit-denktas/stipra/blob/main/packages/canvas/README.md . Experimental 2D support; performance/usefulness acceptance remains #74, full export notice findings remain #14 and physical print validation remains #13.

### Comment by yigit-denktas at 2026-10-17T14:10:03Z (https://github.com/yigit-denktas/stipra/issues/73#issuecomment-6234896139)

#78 implements the core authored-mask input contract: one to eight independent full-frame masks, validated identities, nominal coverage polarity, same screening/diagnostics and proof-only registration. This is the #71 foundation, not completion of #73. Host canvas/layer capture, authored-layer package/export integration and the end-to-end two/three-ink example remain in this issue. Reuse renderLayers() rather than building another separation path.


## #74 — [Chore] Validate creative coding alpha: performance, exports and usefulness

- state: closed / completed
- author: yigit-denktas; labels: ['enhancement']; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T13:22:36Z; closedAt: 2026-10-17T15:02:49Z; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/74

### Body

**Area:** SDK QA / release · **Priority:** P1 · **Scope:** experimental alpha acceptance · **Release target:** Creative coding alpha
**Owner:** @yigit-denktas · **Tracking:** #70 · **Native milestone / Project:** pending #17; this release target is planning text.

**Dependencies:** #71, #72 and #73; tracker #70; relevant export/master checks #8/#12/#13 and shipped-license audit #14. File import claims also depend on #44.
## Work and acceptance
- [x] Measure preview latency, final-render time, memory and bundle bytes at declared artwork size, ink count, browser/device and pixel density; publish actual numbers and supported limits.
- [x] Keep a deterministic CPU reference. Use caching, bounded preview resolution and explicit final-render mode first; add workers/GPU only for a measured bottleneck, with documented numerical differences.
- [x] A frozen source/layer snapshot and normalized recipe export the same production masks through SDK, studio and CLI; previews may use lower resolution, which must be declared.
- [x] Heavy ZIP/PDF/report dependencies load only for optional export, never every animation frame.
- [x] Include recipe/seed/style version, physical scale, source provenance, aligned plates, diagnostics and notices in the optional package.
- [x] Three working examples: Canvas, p5 global, p5 instance; include static artwork and a changing draw loop with explicit capture.
- [x] Compare one fixed artwork/task with documented direct use of p5.riso/p5.grain/canvas-sketch where applicable, respecting each license. Record where Stiprā helps and where it adds cost; narrow scope if it adds no value.
- [x] Package/version/API compatibility and dependency notices reviewed before a separate publication decision; no owner photographs in examples.
- [x] State physical-print validation status. #13 print measurements gate print-quality claims, not an explicitly experimental digital effect.
**Evidence:** benchmark JSON, compatibility table, installable local package, public procedural examples and reproducible proof/plate package; no unsupported 60fps promise.

## Completed evidence
Merged in #80 (`df5fa99739f16a5c47ff7c2bd01310cb482c18bb`). Final CI run https://github.com/yigit-denktas/stipra/actions/runs/39043114456 passed: 132 Node tests, all existing browser checks and the measured alpha/browser-to-CLI parity matrix. Artifact `creative-coding-alpha-evidence` includes six procedural browser packages, CLI replays, benchmark JSON and decoded-mask/proof checks. Committed baselines and the source-linked workflow evaluation: https://github.com/yigit-denktas/stipra/blob/main/docs/CREATIVE-CODING-ALPHA.md .

Actual workload limits, heap/RSS limitations and optional exporter size/load costs are recorded. A bounded draft helper freezes the original, caches explicit revisions, labels resampling and exports the full-resolution final. Physical DPI and corrupted-master rejection are tested. Existing-tool comparison is documentation-based; independent artist preference and other tools' performance have not been measured.

This closes the bounded engineering/evaluation work, not publication or physical acceptance. Both packages remain private alpha. Tracker #70 remains open for the owner's publication/usefulness acceptance. The five full-export distribution findings remain #14; print calibration remains #13. No registry release, calibrated-print claim or owner photographs.


## #75 — [Research] Evaluate a Processing Java bridge after the JavaScript alpha

- state: open / None
- author: yigit-denktas; labels: ['documentation']; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T13:22:37Z; closedAt: None; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/75

### Body

**Area:** Processing integration · **Priority:** P2 · **Scope:** feasibility only · **Release target:** after Creative coding alpha; not scheduled
**Owner:** @yigit-denktas · **Tracking:** #70 · **Native milestone / Project:** pending #17; this release target is planning text.

**Dependencies:** #70 usefulness evidence. Related #11.
## Question
Processing Java cannot directly import a browser JavaScript library like p5.js. Determine whether a file/CLI handoff, local inter-process bridge or independently scoped Java adapter earns its maintenance cost.
## Acceptance
- [ ] Review current Processing PImage/PGraphics capture and supported integration mechanisms from official documentation.
- [ ] Demonstrate a rights-cleared sketch handoff and inspect alpha/frame/color/seed/provenance fidelity.
- [ ] Distinguish offline frame processing from an interactive overlay; measure latency rather than implying the CLI bridge is real-time.
- [ ] Compare bridge options, installation burden, licensing, offline operation and cross-platform maintenance.
- [ ] Recommend one bounded follow-up or explicitly defer. No Java rewrite or second render engine in this research task.
**Evidence:** feasibility note, minimal reproducible handoff and measured limitations.
**Reference:** https://processing.org/environment/


## #81 — [Research] Preserve structured artwork without expanding the print core

- state: closed / completed
- author: yigit-denktas; labels: ['enhancement']; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T15:07:17Z; closedAt: 2026-10-17T15:16:31Z; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/81

### Body

**Area:** Architecture / structured inputs · **Priority:** P2 · **Scope:** source-informed ink separation, research and bounded follow-ups · **Release target:** post-alpha structured-input pilot (unreleased)
**Owner:** @yigit-denktas · **Native milestone / Project:** pending #17; this is planning text, not a configured milestone.

The owner supplied a discussion comparing flattened images, procedural construction, auxiliary depth/object passes and provenance. Verify relevant claims using primary specifications and compare them with the existing #71–#74 implementation. Record findings and a small work breakdown before adding codecs, classifiers or scene editors.

Dependencies / related: #70, #73, #74, #75, #12, #28, #44, #14.

Acceptance:
- [x] Current image, authored-ink and vector paths accurately documented; distinguish preservation from reconstruction.
- [x] Source-backed findings on PNG precision/HDR, depth/disparity, object/material mattes, layered interchange and C2PA.
- [x] Keep format decoders, metadata verification and source-project attachments outside the lean core.
- [x] Define useful next tasks with concrete tests, dependencies and explicit deferrals; no native scene reconstruction, AI-origin detector or photo-editor expansion.
- [x] Correct any bounded import metadata/correctness gap found during the review.

Evidence: an original, source-linked architecture note and reproducible procedural tests; no owner photographs or attached private discussion committed.

## Work breakdown
- #82 — bounded PNG precision/signal handling; implementation and CI in #87.
- #83 — next candidate: named source regions mapped explicitly into physical inks.
- #84 — optional data-only source-project sidecars and source/frame relationships.
- #85 — optional local C2PA validation feasibility; reuse established tools.
- #86 — deferred layered/auxiliary format adapters and precision/orientation expansion.

Research and current architecture: docs/STRUCTURED-ARTWORK.md in #87. Native HEIF/RAW/EXR/OpenRaster parsing and source-code execution are not implemented or added to the core. Existing vector #28, interchange #12 and Processing #75 work remain the related workstreams.

## Completed
Merged in #87 (`f8f68f634f023327d3cfa02ed55096bbbafc3dc6`). CI https://github.com/yigit-denktas/stipra/actions/runs/39044097496 passed all checks: 136 Node tests, real-browser PNG precision/rejection, existing profile references, and six browser/Node/CLI export parity cases. Documentation: https://github.com/yigit-denktas/stipra/blob/main/docs/STRUCTURED-ARTWORK.md .

This completes the bounded research/current PNG interpretation fix. Proposed region mapping #83, source sidecars #84, local provenance validation #85 and format/auxiliary feasibility #86 remain open. No native HDR/HEIC/RAW/EXR/OpenRaster/C2PA decoder, model inference, source-code execution or new core API has been implemented. Original private discussion and owner photographs remain uncommitted.


## #82 — [Bug] Declare PNG precision and reject unvalidated image signals before decoding

- state: closed / completed
- author: yigit-denktas; labels: ['bug']; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T15:07:54Z; closedAt: 2026-10-17T15:16:31Z; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/82

### Body

**Area:** Import / color semantics · **Priority:** P1 · **Scope:** bounded PNG interpretation · **Release target:** correctness follow-up (unreleased)
**Owner:** @yigit-denktas · **Native milestone / Project:** pending #17; planning text only.

**Dependencies / related:** #81, #44, #6.

## Acceptance
- Record original PNG sample bit depth separately from the 8-bit sRGB working representation; warn on 16→8 reduction.
- Reject animated PNG and unvalidated cICP/mastering/light-level signals rather than relying on implicit decoder behavior.
- Reject nonidentity PNG EXIF orientation until there is a tested exactly-once normalization path; keep the original unchanged.
- Use CRC-valid original procedural fixtures in Node and browser tests; prove rejected inputs never reach decoding.
- Document the conservative allowlist and limits; this is not complete HDR or depth detection.

Evidence: source-linked design note, declared limits and reproducible original fixtures; no owner photos. Parent research #81. Native HEIF/RAW/EXR/OpenRaster codecs and broader vector export remain separately scoped; this issue does not authorize a photo or scene editor.

## Completed
Merged in #87 (`f8f68f634f023327d3cfa02ed55096bbbafc3dc6`). CI https://github.com/yigit-denktas/stipra/actions/runs/39044097496 passed all checks: 136 Node tests, real-browser PNG precision/rejection, existing profile references, and six browser/Node/CLI export parity cases. Documentation: https://github.com/yigit-denktas/stipra/blob/main/docs/STRUCTURED-ARTWORK.md .

This completes the bounded research/current PNG interpretation fix. Proposed region mapping #83, source sidecars #84, local provenance validation #85 and format/auxiliary feasibility #86 remain open. No native HDR/HEIC/RAW/EXR/OpenRaster/C2PA decoder, model inference, source-code execution or new core API has been implemented. Original private discussion and owner photographs remain uncommitted.


## #83 — [Feature] Map named artwork regions to physical ink coverage

- state: closed / completed
- author: yigit-denktas; labels: ['enhancement']; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T15:07:56Z; closedAt: 2026-10-17T15:52:20Z; comments: 1
- url: https://github.com/yigit-denktas/stipra/issues/83

### Body

**Area:** Creative coding / mask adapter · **Priority:** P2 · **Scope:** data-only region-to-ink mapping · **Release target:** post-alpha structured-input pilot (unreleased)
**Owner:** @yigit-denktas · **Native milestone / Project:** pending #17; planning text only.

**Dependencies / related:** #81; existing #71/#72/#73/#74; related #43/#47.

## Acceptance
- Accept same-frame named grayscale/opacity masks from an existing sketch; distinguish region masks from final ink coverage.
- Map many regions into one to eight named inks with explicit operation (for example maximum or alpha-over), strength and layer order; version the mapping recipe.
- Require caller-declared mask provenance (authored, captured, renderer-provided or estimated); retain producer/parameters when supplied without treating labels as verified truth.
- Do not treat RGB object-ID images, depth, disparity or normals as grayscale masks. Require a separate explicit conversion.
- Test overlaps and antialiased edges: two half masks differ under max versus alpha-over; do not double-screen or alter aligned masters.
- Demonstrate a rights-cleared procedural forest with deliberate foreground/background passes and CLI/browser replay, compared to flattened separation.
- No geometry engine, segmentation model, GPU host dependency or new drawing language.

Evidence: source-linked design note, declared limits and reproducible original fixtures; no owner photos. Parent research #81. Native HEIF/RAW/EXR/OpenRaster codecs and broader vector export remain separately scoped; this issue does not authorize a photo or scene editor.

### Comment by yigit-denktas at 2026-10-17T15:53:24Z (https://github.com/yigit-denktas/stipra/issues/83#issuecomment-6236131334)

Completed in #89, merged as 40968a16858694836740929c3583da3f430695e7. Final CI run 39046711929 passed: 143 Node tests, existing browser/alpha parity, two-/three-ink named-region browser/Node/CLI replay, five real offline C2PA fixture cases, color references and QR checks. Desktop/mobile region specimens reviewed. See docs/STRUCTURED-INPUTS.md for contracts, exact limits and research decisions. #85/#86 completion is bounded feasibility/pilots; browser C2PA and native Apple/EXR/Cryptomatte support remain explicitly deferred. No owner photographs, external binaries or signing keys were committed. Packages remain unpublished; physical validation is separate.


## #84 — [Feature] Preserve optional source-project sidecars in reproducible packages

- state: closed / completed
- author: yigit-denktas; labels: ['enhancement']; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T15:07:57Z; closedAt: 2026-10-17T15:52:20Z; comments: 1
- url: https://github.com/yigit-denktas/stipra/issues/84

### Body

**Area:** Package / provenance · **Priority:** P2 · **Scope:** opt-in data-only source attachments · **Release target:** post-alpha structured-input pilot (unreleased)
**Owner:** @yigit-denktas · **Native milestone / Project:** pending #17; planning text only.

**Dependencies / related:** #81; existing #73/#74; related #12/#75/#28/#14.

## Acceptance
- Define an optional versioned source-project descriptor and explicit attachment allowlist, sizes, SHA-256, media type, roles, relationships and source-frame transform.
- Keep rendered snapshot replay independent of the original sketch runtime. Source code/scene JSON/SVG are optional evidence, never automatically evaluated or rendered.
- Separate byte identity, normalized pixels, declared creation information and independently verified credentials. A seed alone does not guarantee generator replay.
- Attach only explicitly selected local bytes; reject traversal, duplicate identifiers, oversized archives, implicit network fetches and unsafe active content execution.
- Preserve original and attachment bytes privately; sharing/export rules must expose that source files may contain GPS, prompts, credentials or proprietary code. No automatic public upload.
- Test snapshot-only backwards compatibility, opt-in attachment hashes, exclusion by default and byte-identical retrieval without execution.
- Reuse the existing ZIP writer; do not create an authoring project standard or move ZIP/metadata dependencies into core.

Evidence: source-linked design note, declared limits and reproducible original fixtures; no owner photos. Parent research #81. Native HEIF/RAW/EXR/OpenRaster codecs and broader vector export remain separately scoped; this issue does not authorize a photo or scene editor.

### Comment by yigit-denktas at 2026-10-17T15:53:25Z (https://github.com/yigit-denktas/stipra/issues/84#issuecomment-6236131595)

Completed in #89, merged as 40968a16858694836740929c3583da3f430695e7. Final CI run 39046711929 passed: 143 Node tests, existing browser/alpha parity, two-/three-ink named-region browser/Node/CLI replay, five real offline C2PA fixture cases, color references and QR checks. Desktop/mobile region specimens reviewed. See docs/STRUCTURED-INPUTS.md for contracts, exact limits and research decisions. #85/#86 completion is bounded feasibility/pilots; browser C2PA and native Apple/EXR/Cryptomatte support remain explicitly deferred. No owner photographs, external binaries or signing keys were committed. Packages remain unpublished; physical validation is separate.


## #85 — [Research] Add optional local provenance validation through established C2PA tools

- state: closed / completed
- author: yigit-denktas; labels: ['enhancement']; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T15:07:58Z; closedAt: 2026-10-17T15:52:21Z; comments: 1
- url: https://github.com/yigit-denktas/stipra/issues/85

### Body

**Area:** Metadata / optional adapter · **Priority:** P3 · **Scope:** read-only local credential validation feasibility · **Release target:** deferred optional provenance pilot (unreleased)
**Owner:** @yigit-denktas · **Native milestone / Project:** pending #17; planning text only.

**Dependencies / related:** #81; #84 source sidecar descriptor; related #14/#44.

## Acceptance
- Evaluate current CAI c2pa-web/c2patool compatibility, license/notice obligations, WASM/worker size and offline behavior without adding a core dependency.
- Distinguish not inspected, absent, valid/invalid asset binding and signer trust; record tool/version, trust policy and validation time.
- Disable remote ingredient/manifest fetches by default; no upload to OpenAI Verify or another service as an implicit import step.
- Preserve source credentials as source evidence. Do not claim that signatures authenticate the new screened derivative or prove depicted events, copyright or AI absence.
- If later implemented, test official or original rights-cleared signed/tampered fixtures and offline unknown-trust cases. A readme/source-code lookup is not executed conformance evidence.
- Do not implement an AI-origin classifier or rewrite cryptographic validation.

Evidence: source-linked design note, declared limits and reproducible original fixtures; no owner photos. Parent research #81. Native HEIF/RAW/EXR/OpenRaster codecs and broader vector export remain separately scoped; this issue does not authorize a photo or scene editor.

### Comment by yigit-denktas at 2026-10-17T15:53:26Z (https://github.com/yigit-denktas/stipra/issues/85#issuecomment-6236131849)

Completed in #89, merged as 40968a16858694836740929c3583da3f430695e7. Final CI run 39046711929 passed: 143 Node tests, existing browser/alpha parity, two-/three-ink named-region browser/Node/CLI replay, five real offline C2PA fixture cases, color references and QR checks. Desktop/mobile region specimens reviewed. See docs/STRUCTURED-INPUTS.md for contracts, exact limits and research decisions. #85/#86 completion is bounded feasibility/pilots; browser C2PA and native Apple/EXR/Cryptomatte support remain explicitly deferred. No owner photographs, external binaries or signing keys were committed. Packages remain unpublished; physical validation is separate.


## #86 — [Research] Evaluate layered and auxiliary-pass interchange adapters

- state: closed / completed
- author: yigit-denktas; labels: ['enhancement']; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T15:11:47Z; closedAt: 2026-10-17T15:52:21Z; comments: 1
- url: https://github.com/yigit-denktas/stipra/issues/86

### Body

**Area:** Optional import adapters · **Priority:** P3 · **Scope:** interoperability feasibility, no bundled codecs yet · **Release target:** deferred post-alpha adapters (unreleased)
**Owner:** @yigit-denktas · **Native milestone / Project:** pending #17; planning text only.

**Dependencies / related:** #81, #83, #84, #14; existing #12/#28 export/vector work and #75 Processing bridge. #82 bounds current PNG input; it does not implement HDR tone mapping or rotated-PNG support.

## Acceptance
- Compare OpenRaster's specified layer stack against the actual masks/offsets/opacity/blend modes we can preserve. Start with explicitly selected authored masks if full stack semantics cannot be supported.
- Evaluate host-side Apple ImageIO/AVDepthData and established OpenEXR/Cryptomatte tooling as converters, not dependencies of the lean core. No native HEIC/RAW/EXR decoder until there is a concrete sample/user workflow and license/size review.
- Require explicit data/display windows, pixel origin, frame transform, orientation, units, depth versus disparity, near/far meaning, invalid values, alpha association and measured/estimated provenance. No guessed interpretation from a filename.
- Test a data-window offset, mismatched orientation, occluded edge and fractional matte. Any permitted resampling is explicit and recorded; never smooth object IDs or depth with a color-image filter.
- For future HDR/high-bit input or rotated PNG, establish independent color/orientation reference tests and a declared conversion policy before widening #82's conservative boundary.
- Record reuse/version/notice choices and a measured recommendation or deferral. No photos uploaded or 3D reconstruction/AI inference added.

Evidence: source-linked feasibility table and original or explicitly rights-cleared fixtures. Prototype support is not production or decoder-parity acceptance.

### Comment by yigit-denktas at 2026-10-17T15:53:26Z (https://github.com/yigit-denktas/stipra/issues/86#issuecomment-6236132117)

Completed in #89, merged as 40968a16858694836740929c3583da3f430695e7. Final CI run 39046711929 passed: 143 Node tests, existing browser/alpha parity, two-/three-ink named-region browser/Node/CLI replay, five real offline C2PA fixture cases, color references and QR checks. Desktop/mobile region specimens reviewed. See docs/STRUCTURED-INPUTS.md for contracts, exact limits and research decisions. #85/#86 completion is bounded feasibility/pilots; browser C2PA and native Apple/EXR/Cryptomatte support remain explicitly deferred. No owner photographs, external binaries or signing keys were committed. Packages remain unpublished; physical validation is separate.


## #90 — [Project] Unify delivery dependencies, version targets, changelog and site navigation

- state: closed / completed
- author: yigit-denktas; labels: []; milestone: None; assignees: ['yigit-denktas']
- createdAt: 2026-10-17T15:57:35Z; closedAt: 2026-10-17T16:22:27Z; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/90

### Body

**Type:** Feature / Documentation
**Area:** Release planning / public website
**Priority:** P1
**Scope:** Requested consolidation after #83–#86, #22 studio acceptance and #14 distribution audit.
**Release target:** v0.9 studio acceptance and the separate JavaScript alpha publication track; version labels are targets until release gates pass.
**Assignee:** @yigit-denktas
**GitHub Project / native milestone:** unavailable in the current connector; #17 remains the setup tracker. Do not invent project or milestone IDs.

## Dependencies and related work
#83–#86 are implemented/researched in #89. #22 and #14 provide the active workflow and distribution gates. Preserve original v0.9 #1–#14 scope; #70–#75 are the separate creative-coding track. #31/#34/#43/#47, #28, #46/#57 and physical validation #13 retain their actual remaining acceptance.

## Acceptance
- [x] One source-backed dependency ledger covers every open roadmap task, hard prerequisites versus parallel/quality work, version/milestone targets and measurable exit conditions.
- [x] Reconcile merged work into main and record remaining active/parked branches without deleting unmerged owner work.
- [x] Dedicated public changelog distinguishes merged development changes from published releases; source PR/commit links and release gates remain visible.
- [x] Human sitemap and shared navigation reach studio, guide, examples, roadmap and changelog on both hosts; machine sitemap uses the primary host.
- [x] README/ROADMAP current; dependency graph validation rejects missing tasks/cycles; public routes and local links tested; desktop/mobile pages reviewed.
- [x] No invented release tags, physical-print evidence or owner approval.

## Completion evidence — #91

Merged follow-through: #91; exact final CI 39048870910 passed on 5e7163a6edc1bfd06edba3ee78e3bb75eb86b46c. 146 Node tests passed, zero skipped. Real Chromium checks covered image/color boundaries, real mask edits, solo/mute/paper/native pixel zoom, 2–8 inks, supported screen controls, keyboard focus/labels, five workspace widths, responsive information pages and marked export pixels/hashes/DPI/PDF recipes. Browser/Node/CLI alpha and named-region replay, real local C2PA fixtures, color references and QR verification passed. Workflow capture recorded zero external processing requests; desktop/mobile studio, roadmap, changelog and sitemap screenshots were reviewed.

README/ROADMAP, docs/STUDIO-WORKFLOW.md and docs/data/delivery-ledger.json preserve scope, version gates and branch reconciliation. Reports #9 are reconciled; #83–#86 were completed in #89. #14 remains open with three exact binary/prebundle provenance findings; publication #70, physical observations #13 and final identity remain separate. No owner photographs or external binaries were committed.



## #109 — [Research] Explore image reconstruction methods beyond Risograph — Stiprā Reconstruction Study 01

- state: open / None
- author: yigit-denktas; labels: []; milestone: None; assignees: []
- createdAt: 2026-10-18T19:38:41Z; closedAt: None; comments: 6
- url: https://github.com/yigit-denktas/stipra/issues/109

### Body

## Proposal

Explore **Stiprā as a programmable image reconstruction and printmaking studio**, while keeping the existing local-first, deterministic ink separation, screening and reproducible export workflow intact.

**Product intent:** support both (1) practical preparation of artwork for physical printing and, longer term, (2) creation of original art by reconstructing images through marks, paths, regions, textures and layers. Risograph is **one output process**, not the organizing principle for all creative methods.

**Type:** Research / bounded prototype · **Priority:** P2 exploration · **Release:** post-alpha / **non-blocking** · **Status:** proposal, not implementation approval.

### Key distinction

Keep these concepts separate rather than making a giant effects gallery:

- **Interpretation:** extract or derive tone, edges, texture, local orientation, regions and (when actually supplied) depth.
- **Reconstruction:** convert those signals into points, strokes, hatching, vector shapes, fields, pixel patterns or authored ink layers.
- **Composition:** selectively combine methods, masks, palettes, marks and material assignments.
- **Production:** send compatible representations to the established ink/proof/plate/CLI pipeline, or later to an independently scoped plotter/vector exporter.

A reconstruction algorithm is not a physical print process. For example, stippled geometry might be rendered onto Riso plates, screen-printed or plotted.

### External landscape to evaluate (research candidates, **not approved dependencies**)

| Reference | What to learn / test |
| --- | --- |
| [Plottter](https://github.com/pywkt/plottter) | Breadth of image-to-path techniques and artist-facing workflow (stippling, hatching, TSP, spiral, Voronoi) |
| [PlotterForge](https://plotterforge.com/) | Multi-method user experience and output-oriented creation; product reference rather than a presumed reusable dependency |
| [StippleGen](https://www.evilmadscientist.com/2012/stipplegen-weighted-voronoi-stippling-and-tsp-paths-in-processing/) | Weighted-Voronoi dots and TSP/continuous-line representations |
| [penfill](https://github.com/piLeoni/penfill) | Editable geometric fills: hatching, spirals, stippling and pattern fields |
| [DoGPack](https://github.com/dpfens/dogpack) | Edge-aware/engraving-style processing and practical GPU implications |
| [VTracer](https://github.com/visioncortex/vtracer) | Image-to-vector color-region representation, with explicit fidelity/editability tradeoffs |
| [vpype](https://github.com/abey79/vpype) / [vpype-js](https://github.com/plottertools/vpype-js) | Composable vector operations, path optimization and plotter-oriented export |
| [G'MIC](https://gmic.eu/), [GEGL](https://gegl.org/), [Image Sequencer](https://github.com/publiclab/image-sequencer) | Photo transformations, graph/sequence processing and reproducible intermediate steps |
| [Paper.js](https://paperjs.org/) / [p5.plotSvg](https://github.com/golanlevin/p5.plotSvg) | Build geometry within existing creative coding hosts without inventing a new sketch runtime |

For each candidate record **license and notice obligations, maintenance/release state, runtime/size, input/output contracts, browser/Node feasibility, performance, and whether genuinely editable geometric or per-ink data survives**. Do not copy external code/assets or assume MIT compatibility.

### Bounded first experiment: Reconstruction Study 01

Use **two rights-cleared source fixtures** (one portrait/organic subject, one architecture/linework; original or licensed) and a simple existing Stiprā separation as a baseline.

1. Produce a compact, illustrated comparison of **six distinct approaches**: weighted stippling, directional hatching, continuous/TSP line, vector-region reconstruction, dithering/screened ink, and one *hybrid* composition.
2. Choose **at most two external techniques** for a small opt-in, locally executable proof of concept. Prefer a **loose adapter/CLI boundary** or an isolated example; no changes to the production core API in this phase.
3. For each technique, show the **same input**, comparable framing and physical size, named method and parameters, reproducible seed where applicable, plus source attribution/rights.
4. Preserve the **native meaning of the artwork** where practical (vector paths, dots, regions, authored coverage). Clearly label when the result is raster-only, sampled SVG or a digital proof, not truly editable vectors or calibrated print.
5. Try **two authoring routes**: a human choosing/combining techniques visually, and an AI agent invoking documented commands to generate → inspect → revise → export. Do not execute arbitrary untrusted generated code in the studio.
6. Compare perceived usefulness against simpler established tools instead of presuming a new framework is warranted. Record a short independent first-reader/artist trial if feasible; owner/agent approval is not equivalent to artist validation.

### Proposed evaluation criteria

- **Discoverability:** can a newcomer obtain meaningfully different artworks without understanding advanced separation parameters?
- **Agency:** can a person understand what each method contributed, revise it, and meaningfully combine two methods?
- **Reconstruction quality:** legibility, expressive character and significant source detail at the declared output size; compare actual outputs, not only attractive thumbnails.
- **Data quality:** meaningful editable representation where claimed; explicit intermediate forms, saved versioned recipe and provenance.
- **Production:** aligned physical dimensions and ink masks when routed through current Stiprā export; no inferred printer calibration.
- **Reliability:** determinism/replay where promised, bounded runtime/memory, browser/CLI parity for supported inputs, and no regressions to existing goldens.
- **Economics/rights:** cost of dependency, licenses, compatibility and maintenance justify any additional complexity.

### Deliverables / exit criteria

- [ ] Source-linked **comparison matrix** of candidate tools (capabilities, license, interfaces, constraints, technical evidence, integration verdict).
- [ ] Short **representation/adapter design note** locating boundaries between interpretation, reconstruction, composition and production; describe where current authored ink masks, regions and vector scenes are reused.
- [ ] Runnable **Study 01** with two rights-cleared inputs, six same-source comparisons, original/digital proof/mark or plate views, recipes, and documented constraints. Six comparisons **do not require six new engines**; existing tools or offline studies are allowed.
- [ ] At most two isolated proof-of-concept adapters if licensing, maintenance and runtime checks pass; otherwise document why no adapter is justified.
- [ ] A short **human + agent workflow evaluation** with failures, useful outcomes and evidence (including CLI commands and actual output files where redistribution rights permit).
- [ ] Recommendation to **adopt, defer or reject** each candidate; if useful, open **separately bounded implementation issues** with explicit release/performance/rights gates.
- [ ] No changes to existing core contracts, production plates, licensing policy or release claims unless approved and separately tested.

### Out of scope

- Replacing Stiprā's current separation/screening engine or restructuring the studio around a general-purpose image editor.
- Building our own p5.js, Photoshop, G'MIC, node editor, hosted AI generator or unlimited plugin marketplace.
- Shipping dozens of stylistically similar presets; inferring image semantics without validated inputs/models; integrating Handwired/differentiable optimization without demonstrated need.
- Claiming print-ready quality before physical acceptance or bundling any third-party source assets without redistribution rights.

### Existing Stiprā work to preserve / coordinate

- [Architecture](https://github.com/yigit-denktas/stipra/blob/main/docs/ARCHITECTURE.md), [design principles](https://github.com/yigit-denktas/stipra/blob/main/DESIGN.md), [roadmap](https://github.com/yigit-denktas/stipra/blob/main/ROADMAP.md).
- #70–#74: lean core, Canvas/p5 adapter, authored ink, measured alpha and artist usefulness gate.
- #81, #83–#86: structured input/region mapping/source preservation (not new drawing engines).
- #28: analytic vector screening is distinct from sampled-path SVG.
- #34, #47: editable Styles/recipe selection rather than algorithm proliferation.
- #11, #13, #14: safe reproducible CLI, physical/visual acceptance, licensing and provenance.

**Decision gate:** do not commit to a new runtime/dependency, universal intermediate representation or UI redesign until Study 01 establishes a user-facing advantage over the smaller existing tools.

### Comment by yigit-denktas at 2026-10-19T09:58:09Z (https://github.com/yigit-denktas/stipra/issues/109#issuecomment-6264578257)

**Related process-research intake (19 Oct 2026):** [#114 — Printmaking beyond Riso: xerography, screenprint and relief process feasibility](https://github.com/yigit-denktas/stipra/issues/114). This is *not* a second image-to-geometry/reconstruction study: #109 retains stippling, hatching, path/region representations and their adapter selection; #114 investigates the actual print processes, constraints, possible proof exports and separate physical acceptance. Coordinate sample artwork/recipes and prevent duplicate rendering code. #114 is P2 research only.

### Comment by yigit-denktas at 2026-10-19T20:45:23Z (https://github.com/yigit-denktas/stipra/issues/109#issuecomment-6276933454)

Controlled Study 01 is executed in PR #119: the same two public-domain photographs, six different methods, full-frame normalized inputs, native SVG geometry where available, existing Stiprā baseline and deterministic geometry/raster replay. Scripts, hashes, rights and limitations are recorded in docs/RECONSTRUCTION-STUDY-01.md. No production dependency or defaults changed. Vector regions warrant further evaluation; the naive greedy continuous route is rejected. Independent usefulness/adoption and physical evidence remain unperformed, so #109 stays open and is partial in the consolidated ledger. #113/#114 are proposed research without release dates.

### Comment by yigit-denktas at 2026-10-19T21:03:23Z (https://github.com/yigit-denktas/stipra/issues/109#issuecomment-6277267928)

Independent review identified a confound in Study 01: v1 sparse marks were compared with much denser outputs. That ranking is withdrawn. PR #119 now includes coverage-controlled v2 at commit 1ddd32e4b529a0211ff077cf2e50669a915c7409: area-based stipple, tone-based directional hatch, a hybrid of the actual parent elements, and route width matched to the same source darkness. All four mark methods match within 0.01 percentage point. VTracer now preserves all four palette bands; architecture remains +1.76 pp darker and its error is disclosed. Add authored single-black solid baseline, unconstrained dither reference, frozen sites, measured complexity/tone tables, scoped replay and complete archive hashes/links. All 192 local tests pass; 32 SVG/decoded-pixel checks match on same-environment replay. No overall adapter winner, cross-build guarantee, human blind ranking or physical acceptance claimed. #109 remains partial/open.

### Comment by yigit-denktas at 2026-10-19T21:40:13Z (https://github.com/yigit-denktas/stipra/issues/109#issuecomment-6277999432)

Integrated pushed review branch 3deeab8 into PR #119 at 944127260e46f43c391ffa0fdb62d0370eee049a, preserving its authorship. Independent integration found and corrected pairs/N mislabeled as circles-touched fraction, a two-neighbour boundary implementation, reversed coverage-error polarity, and the missing four-band failure guard. Replay now fails closed unless the exact expected 32 artifacts pass. Regenerated expanded Linux evidence includes real local histograms/spatial diagnostics/split timing and ships replay-check.json; original evidence remains byte-identical (cc2a9b4...). Correct four-neighbour boundary mismatch is 28.31% / 35.15% on this Linux build; this is a definition change, not improved rendering. 193 Node tests and four synthetic Python tests pass locally, with 32/32 replay. Experiment 2, radius cap, adapter approval and human rankings remain unperformed.

### Comment by yigit-denktas at 2026-10-19T21:51:23Z (https://github.com/yigit-denktas/stipra/issues/109#issuecomment-6278186487)

Resolved integration review's delivery/CI gaps at PR #119 head 4312d7aceeeccb3b9af3026c2dfff080f7d62104. Actual standalone PDF download is beefb39b3306eb678910c53262f53b86989ecabdd1e8bff84d3b5e43f9b619ee, 2,959,918 bytes: the original 2,934,943-byte PDF (535352b1ba153ce76a29b42d8b030bfdb2a94f291520d60556891c6971d19624) is an exact byte prefix followed by C2PA incremental provenance. ZIP PDF identity matches canonical evidence; no rerender or stale hash. A separately truncated saved ZIP was replaced, then downloaded and verified: 18,963,987 bytes; SHA-256 47d5f55f9d8c41e640856974c05f79df7b7a34d5e0d436e277f733d2282b2f10; all 59 manifested entries pass. Record both PDF identities and source-script resolution to 9441272 in supplemental delivery evidence. CI explicitly runs four Python metric/replay tests with pinned numerical dependencies. Local 193 Node / 4 Python tests pass; new-head CI is pending. Prior canonical evidence and original recording remain unchanged; Experiment 2 remains unrun.

### Comment by yigit-denktas at 2026-10-19T22:03:19Z (https://github.com/yigit-denktas/stipra/issues/109#issuecomment-6278376770)

PR #119 merged after rechecking all five successful checks at exact reviewed head 4312d7aceeeccb3b9af3026c2dfff080f7d62104. Merge commit: d033ce7c923507c607786ca141fb532500964c60 (2026-10-19T22:03:02Z / 20 October 00:03 Berlin). No study artifacts regenerated and no evidence rewritten for the merge.

#109 remains open. Carry forward Windows portability (npm subprocess resolution, non-study vendor CRLF hashes, README newline counting; TEMP ACL and symlink privileges are host-sensitive), human blind evaluation and physical acceptance. Small non-blocking dependency follow-up: make examples/reconstruction-study/requirements-test.txt self-contained with Pillow==12.3.0 and reportlab==4.4.9, and include the requirements file via an explicit .txt packaging rule in future self-testing archives. Keep that outside the reviewed #119 artifact identities.

Experiment 2 remains a separate decision and was not run. The 0.45×NN radius cap is not adopted. Merge implies no adapter adoption, production-default change or human/physical acceptance.


## #113 — [Prepress] Print proof annotations, ink legends and registration test sheets

- state: open / None
- author: yigit-denktas; labels: ['enhancement']; milestone: None; assignees: []
- createdAt: 2026-10-19T09:46:33Z; closedAt: None; comments: 1
- url: https://github.com/yigit-denktas/stipra/issues/113

### Body

## Proposal: useful print-production notation, not fake industrial decoration

**Type:** Feature / print QA · **Priority:** P2 · **Status:** scoped proposal; does not reopen completed separation/prepress work.

**Companion:** [Kushluk — three-layer production annotations](https://github.com/interzettel/kushluk/issues/155). Related: [#8 aligned prepress masters](https://github.com/yigit-denktas/stipra/issues/8) (**closed; already supports optional crop/registration marks and registration metadata**), [#5 screening](https://github.com/yigit-denktas/stipra/issues/5), [#7 separations](https://github.com/yigit-denktas/stipra/issues/7), [#13 print QA](https://github.com/yigit-denktas/stipra/issues/13), [#34 styles](https://github.com/yigit-denktas/stipra/issues/34), [#28 vector halftones](https://github.com/yigit-denktas/stipra/issues/28).

### Why

Risograph / offset workflows have real production language: plate IDs, register targets, ink keys, grayscale separation previews, density ramps, trapping/overprint checks, fold/trim references, feed orientation, proof revision and technical legends. Today Stiprā's spot-ink composition and #8 prepress export exist; the missing opportunity is **a coherent operator-facing proof/annotation kit** that explains and verifies the artwork without duplicating those engines.

### Proposed deliverables

- [ ] Inventory existing #8 crop/registration/bleed/export features and exact schema; **reuse**, don't rebuild.
- [ ] Design an opt-in **proof-sheet overlay / margin legend system** for browser preview, CLI, and exported proof/report. Distinguish `artwork`, `plate master`, `operator proof`, and `editorial decoration`; keep marks off production masters or in the specified outside-trim area as required by the target printer.
- [ ] Print marks: precise register targets, trim/crop references, fold/feed-direction arrows, optional centerlines/rulers. Validate geometry and label when a mark is merely decorative vs a true press/operator aid.
- [ ] Ink key: per-plate spot names/identifiers and order, source palette and layer mapping, grayscale coverage, optional test swatches and tonal ramps. Support 1/2/3/N spot inks and CMYK **when actually selected**; substrate is not an ink.
- [ ] Calibration/test modules (clearly optional): single-ink density ramps, 2-ink overprint matrices, knockout vs overprint, trapping/misregistration comparison, halftone line/screen-angle samples and alignment tolerances. Clearly mark digital simulation vs physically measured proof; **no invented dot gain, ink density or press limits**.
- [ ] Machine-readable internal artwork/run IDs in the report or proof footer (e.g. QR/code 128): use a real encoded identifier with validation/quiet zones; no fabricated GS1/ISSN/ISBN or certification claims.
- [ ] Versioned metadata for source hash/recipe/seed/ink configuration, intended print size, actual device/stock **if supplied**, and proof revision; unknown device/stock must remain unknown, not filled with marketing copy.
- [ ] Low-ink, accessible default; clear text labels adjacent to swatches; original artwork remains unchanged. Printer/export profile must preserve dimensions, physical offsets, origin and accurate plate alignment. Prefer no new runtime dependencies.
- [ ] Provide one genuine studio proof sheet and one optional compact footer/legend **component** usable by clients (Kushluk can opt in). Do not couple Stiprā to Kushluk or mandate a new publishing format.

### Acceptance / test matrix

- [ ] Deterministic fixtures for 1, 2, 3 and 4 ink outputs, including overlapping/knockout plates; export/preview/CLI share equivalent label data and dimensions.
- [ ] Pixel/geometry tests assert marks outside trim when appropriate, plate content and origin unchanged, correct feed/fold/rotation, no clipping and correct quiet zones.
- [ ] Real scanner tests for QR/Code 128, valid edition IDs, offline operation and no hidden personal content in codes.
- [ ] A4 proof PDF works at 100% physical scale on ordinary home paper; optional A3 when target dimensions permit. No claim of real Risograph/offset calibration without physical measurements.
- [ ] Capture physical operator feedback under #13, separate observed press behavior from simulated results. Include print-shop-specific export guidance (some shops explicitly request **no** crop/registration marks in source artwork).
- [ ] Complete original-implementation/dependency licensing check under existing release governance; avoid copying trademarked certification graphics or third-party proprietary symbol files.

**Out of scope:** redoing #5/#7/#8, a mandatory separate-sheet ritual for casual users, pretending a CMYK inkjet mimics real Riso ink behavior, building a general-purpose pagination engine, or automatically treating these marks as valid for every print shop.

**Suggested sequence:** inventory + one standalone proof design → shared metadata schema → proof rendering → deterministic tests → real print feedback → optional Kushluk integration.


### Comment by yigit-denktas at 2026-10-19T09:58:11Z (https://github.com/yigit-denktas/stipra/issues/113#issuecomment-6264579166)

**Companion print-process research (19 Oct 2026):** [#114 — Printmaking beyond Riso](https://github.com/yigit-denktas/stipra/issues/114) compares xerography, screen-print stencil preparation, relief processes and further candidates. Keep #113 responsible for reusable register/trim legends, ink swatches, proof metadata and test strips; #114 should use these contracts instead of implementing a second marks system. Editorial application: [Kushluk #156](https://github.com/interzettel/kushluk/issues/156).


## #114 — [Research] Printmaking beyond Riso: xerography, screenprint and relief process feasibility

- state: open / None
- author: yigit-denktas; labels: ['enhancement']; milestone: None; assignees: []
- createdAt: 2026-10-19T09:56:02Z; closedAt: None; comments: 0
- url: https://github.com/yigit-denktas/stipra/issues/114

### Body

## Research question

**Which printing processes beyond Risograph offer genuinely distinct, understandable ways to reconstruct artwork — and which deserve a small experimental tool in Stiprā?**

**Type:** bounded research / process investigation · **Priority:** P2 / exploration · **State:** proposed, **not** implementation approval or v0.9 release gate.

**Adjacent, but distinct:**
- [#109 — Reconstruction Study 01](https://github.com/yigit-denktas/stipra/issues/109) evaluates *representations and computational image-making methods* (stipple, hatching, vector regions, continuous lines, etc.). This issue evaluates **historical/physical printing processes, required outputs, and artist-readable proofing**. A woodcut-like line reconstruction could be printed by an inkjet, as relief, or through a stencil; the algorithm ≠ physical process.
- [#113 — Production annotations and proof sheets](https://github.com/yigit-denktas/stipra/issues/113) owns plate legends, registration targets, color/test strips; **reuse it** when relevant.
- [#5 raster screening](https://github.com/yigit-denktas/stipra/issues/5), [#7 separation](https://github.com/yigit-denktas/stipra/issues/7), [#8 aligned masters](https://github.com/yigit-denktas/stipra/issues/8) already provide foundations and are **closed**. Do not reopen or relabel existing abilities.
- [#34 Styles](https://github.com/yigit-denktas/stipra/issues/34), [#13 physical print QA](https://github.com/yigit-denktas/stipra/issues/13), [#14 licenses](https://github.com/yigit-denktas/stipra/issues/14), [#21 product scope](https://github.com/yigit-denktas/stipra/issues/21).

## Initial process taxonomy and research candidates

| Family | Characteristic source of appearance | Possible computational investigation | Real-world output boundary |
| --- | --- | --- | --- |
| **Xerography / photocopier art** | toner transfer, thresholding, rescanning, copy-of-copy artifacts, hard contrast | repeatable tone/threshold/reproduction generations and masks, separate from arbitrary noise filters | inkjet approximation is not actual photocopy/toner behavior |
| **Screen printing / serigraphy** | mesh stencil, independent color screens, opaque/translucent ink and registration | printable binary/continuous stencil layers; minimum feature widths; trapping/overprint tests | real inks, mesh/exposure/press determine achievable detail |
| **Relief: woodcut / linocut** | carved-away non-printing regions, carved mark vocabulary, directional gouges, substantial black/white masses | vector cut regions, negative space, oriented cut marks; **differentiate invented “wood grain” texture from actual relief geometry** | inkjet imitation has no carved block/ink relief |
| **Letterpress / movable type** | type/plate relief impression and ink transfer, alignment, type-bearing geometry | typographic composition and possible plate-ready positive artwork; no fake deboss claims | actual pressure/embossing is physical and paper/press-dependent |
| **Cyanotype** | photosensitive coating, UV-negative exposure, blue/white image | negative/exposure mask export; blue digital proof as *preview only* | wet chemistry/UV processing distinct; do not promise quantitative tonal match |
| **Spirit duplicator / mimeograph** | historical wax/dye transfer and stencil duplication, often distinctive color/artifacts | rights-cleared visual study and duplication-process diagrams; consider whether effect creates value beyond xerography | obsolete equipment, chemistry/solvent and archival safety; no advice to recreate hazardous historical materials |
| **Dot-matrix / impact print** | discrete pin lattice, low-resolution ribbons, continuous feed | variable pin-grid raster, non-square glyph matrices, impact-style dot primitives, continuous roll/page composition | ribbon impact/mechanical dents aren't produced by software |
| **Direct thermal** | heat-activated narrow media and dot columns | width-constrained dither/raster; continuous report strips; readability+archival warnings | physical chemistry fades; unsuitable as permanent master |
| **Collagraph / gel monoprint / mokuhanga** | hand-built texture and transfer variability; water-based block printing | qualitative reference boards / artist studies, not speculative calibrated shaders | hands-on process; physical unpredictability and texture are the point |
| **Emboss/deboss / foil / specialty finishes** | relief and reflective surfaces | possible **separate physical finish-mask geometry**, preview labeled conceptual | inkjet printing alone cannot reproduce relief/foil |

These are **candidates**, not equal priorities or a commitment to ship ten modes. Keep techniques, appearance, export feasibility and physical authenticity in separate fields.

## Shortlist for the first controlled spike

1. **Photocopy / xerographic reconstruction** — most practical as a low-cost, black/white first study; test whether a process-model with explicit copy-generation steps beats a generic contrast/grain slider.
2. **Screenprint stencil generation** — leverage current editable masks and spot-color plates; evaluate negative/positive stencil export, mesh/feature-size constraints, trapping and overprint proofing. Avoid rewriting current separation.
3. **Computational relief / woodcut** — compare carved-away regions, oriented cut marks, and proper vector shapes to a simple edge-threshold or hatching filter. Coordinate with #109; do not duplicate its generic hatching renderer.

**Secondary documentary research:** cyanotype negatives, mimeograph/ditto, dot-matrix, thermal and letterpress. Test physical workflows only with a suitably equipped maker/studio and appropriate safety review.

## Research deliverables

- [ ] **Reference atlas:** for each family, show a rights-cleared example and explain its actual image/ink/paper transfer mechanism; name its authentic failure modes, material and geometric limits, historical publishing uses.
- [ ] **Comparison matrix:** physical equipment/availability, everyday A4/A3 feasibility, color model, required master or stencil data, editable vector vs raster semantics, printer/studio compatibility, likely recurring material/time costs (estimates labeled), archival durability, hazards, accessible reproduction.
- [ ] **Three controlled same-source studies:** two rights-cleared source images (e.g. tonal portrait and detailed architectural image), same final print dimensions, (a) baseline native Stiprā proof, (b) process-inspired digital proof, (c) if justified, physically executable mask/master/output for the chosen process. Keep identical crop and measure legibility at true size.
- [ ] Evaluate **representation**, not just appearance: masks, separations, paths, stencils, layers, process settings, versioned recipe, seed and exports. Say explicitly when a preview is raster-only or does not produce physical-process-ready files.
- [ ] Investigate the difference between **simulated effect**, **useful prep for real workshop printing**, and **measured real print**; do not promise reproducible physical textures where each impression is unique.
- [ ] Small real first-reader/artist review: can an unfamiliar creator recognize the process, get a meaningful result, revise the outcome and understand the physical limitations?
- [ ] Compare native JS/Canvas/SVG/ImageMagick/GEGL/G'MIC/open-source options **before adopting libraries**. Record license/notice obligations, maintenance, browser/Node fit, provenance and runtime costs; no copying existing visual assets or restrictive code.
- [ ] Reconcile differences/overlap with #109, #113 and existing style presets. Propose at most **one** follow-on implementation issue initially, or conclude that zero new modes are justified.

## Exit gate: evidence-based process decision

- [ ] Reproducible visual comparison set with per-method source, parameters, output dimensions and honest preview/print status.
- [ ] Print/readability tests at A4 physical size; when claims involve real Riso/screen/relief/cyanotype, secure actual workshop evidence or state **untested**.
- [ ] Written **adopt / prototype later / reject** judgment for the three shortlist techniques based on distinctiveness, usefulness, maintainability, licensing, physical feasibility and baseline comparison.
- [ ] Existing v0.9 pipeline, CLI, golden fixtures and privacy/rights boundaries remain intact.

## Sources to read (starting evidence, not exhaustive)

- [Met: Screenprint (mesh/stencil and registration)](https://www.metmuseum.org/perspectives/materials-and-techniques-printmaking-screenprint)
- [Met: Woodcut (carved relief)](https://www.metmuseum.org/ja/perspectives/materials-and-techniques-printmaking-woodcut)
- [University of Texas: Letterpress/wood type](https://rrk.finearts.utexas.edu/info/what-is-wood-type/)
- [National Portrait Gallery: Cyanotype](https://www.npg.org.uk/collections/explore/glossary-of-art-terms/cyanotype)
- [University of Iowa: Spirit duplicators and independent fanzines](https://blog.lib.uiowa.edu/speccoll/2021/07/23/spirit-duplicators-early-20th-century-copier-art-fanzines-and-the-mimeograph-revolution/)
- [University of Maryland Baltimore County: fanzine reproduction methods](https://library.umbc.edu/fanzines/the-coslet-sapienza-fantasy-and-science-fiction-fanzine-collection/production-of-zines/printing-methods/)
- [US National Archives: thermal/xerographic archival behavior](https://www.archives.gov/preservation/holdings-maintenance/paper)
- [Reprographixxx Risograph guide: real file/print-shop constraints](https://reprographix.ink/risograph-printing/guide/)

**Non-goals:** a one-click “12 filters” gallery, compulsory new UI framework, print calibration by visual guesswork, recreating legacy hazardous chemical processes, using third-party artwork without permission, or claiming physical-process fidelity based on screen previews.

**Cross-project editorial experiment:** [Kushluk #156 — Alternative print cultures and experimental A4 newspaper editions](https://github.com/interzettel/kushluk/issues/156). The Kushluk issue owns actual newspaper uses and reading tests; this Stiprā issue owns technical process research and reusable proof/export boundaries.

