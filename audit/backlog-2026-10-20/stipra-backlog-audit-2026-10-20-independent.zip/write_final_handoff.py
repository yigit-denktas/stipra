"""Assemble the final independent audit handoff (cloud recommendation file absent)."""
import json
from pathlib import Path

A = Path(r"C:\Users\yigit\Documents\repos\stipra-backlog-audit-d033ce7")
AD = A / "audit-data"
raw = json.loads((AD / "backlog-raw.json").read_text(encoding="utf-8"))
issues = {i["number"]: i for i in raw["issues"]}
initial = (AD / "initial-findings.md").read_text(encoding="utf-8")
# Import the per-issue dispositions by executing the initial findings generator data.
ledger = json.loads((A / "docs/data/delivery-ledger.json").read_text(encoding="utf-8"))
tasks = {t["issue"]: t for t in ledger["tasks"]}
D = AD / "dispositions.json"
dispositions = {}

# Per-issue row data: use the initial table verbatim as the auditable record.
row_lines = [l for l in initial.splitlines() if l.startswith("| #") and "State" not in l]
# Add comment counts and issue URLs for coverage.
coverage_numbers = ", ".join(f"#{n}({len(issues[n]['_comments'])}c)" for n in sorted(issues))
comment_total = sum(len(i["_comments"]) for i in issues.values())

def evidence_for(n):
    i = issues[n]
    return i.get("state_reason") or ""

lines = []
lines += ["# Stiprā backlog audit — independent handoff", "",
          "**Status:** independent first pass complete. **Cloud audit file `stipra-complete-issue-audit-2026-10-20.md` was not found** in Downloads, documents, desktop, temp, DSH attachments, or the repository; therefore the cloud recommendation/agreement table is **BLOCKED, not invented**. Provide the file (or paste its recommendations) to complete reconciliation.", "",
          "Read-only audit. No issue closure/label/Status Done, merge, branch deletion, publication, production change, evidence edit, or Experiment 2 was performed. Preserve all dirty work: the source worktree existed already and was not reset; the audit used a separate detached worktree at fetched main.", "",
          "## 1. Coverage manifest", "",
          f"- Repository: https://github.com/yigit-denktas/stipra",
          "- Exact inspected main SHA: `d033ce7c923507c607786ca141fb532500964c60` — merge commit for PR #119, parents include reviewed head `4312d7a`; fetched `origin/main` at inspection time.",
          "- Audit source worktree: `C:\\Users\\yigit\\Documents\\repos\\stipra-backlog-audit-d033ce7` (detached at d033ce7, read-only source inspection).",
          f"- Retrieval window: {raw['retrievalStarted']} → {raw['retrievalFinished']}; GitHub REST via authenticated `gh api --paginate --slurp`; full body + every comment.",
          f"- Genuine issues: **{len(issues)}** (open **{sum(i['state']=='open' for i in issues.values())}**, closed **{sum(i['state']=='closed' for i in issues.values())}**); comments: **{comment_total}**. PRs: **64**, all merged; **0 open PRs**. PR #119 merged at d033ce7 (2026-10-19T22:03:02Z).",
          "- Environment: Windows 11 host, OS NT 10.0.26300.0; Node v22.15.0; npm 11.7.0; git 2.49.0.windows.1; gh 2.89.0; Python 3.12.14.",
          f"- Issue numbers and comment counts read: {coverage_numbers}.",
          "- Milestone `v0.9` exists (milestone #1) but API counters report **0 open / 0 closed** while 14 issues reference it (5 open, 9 closed) — recorded as an API/counter inconsistency, not progress. Private Project #3 and its fields/statuses are owner-only and **unavailable** to this audit; do not infer Project IDs or Status values.",
          "- Upstream read-only check: https://github.com/samizdatco/skia-canvas/issues/309 is OPEN with 0 comments (created 2026-10-19T08:10:59Z); no maintainer response/clearance observed.",
          "- Release/registry read-only check: one experimental prerelease `v0.9.0-rc.1`; npm `@yigit-denktas/stipra-core@0.1.0-alpha.1` resolves with documented integrity. No publication/merge by this audit.",
          "- Not available/inspectable here: owner photographs and private evidence, Project #3 views/Status, physical prints, human keyboard/screen-reader observations, independent artist records, cloud audit recommendations. These are marked NOT RUN / unavailable, never passed.",
          "- Not executed in this audit: Windows test suite, Python metric tests, rendering/browser/CI reruns, owner-fixture runs. Source/records inspected only.", "",
          "## 2. Per-issue rows", "",
          "The complete row table is preserved in the auditable first-pass report; the table below is the same disposition set (state, scope, remaining criteria, disposition, dependencies, confidence).", ""]
# Use initial table rows; add issue URLs as state labels already contain #n.
lines += ["| Issue | State | Scope / implementation evidence | Remaining criteria | Proposed disposition | Dependencies | Confidence |", "|---|---|---|---|---|---|---|"]
for line in row_lines:
    lines.append(line)
lines += ["", "## 3. Prioritized actionable packages", "",
          "### P1 — Acceptance-record reconciliation (owner + cloud; no code)", "",
          "**Why now:** the strongest concrete discrepancy is that #8/#9/#12 are closed while the canonical acceptance record is still unexecuted. `docs/PRINT-PACKAGE-ACCEPTANCE.md` says `NOT YET RUN`, every G01–G11 and A/B/C box is unchecked, `PROGRESS: 0 of 3 owner-photo packages`; `tests/fixtures/owner-photo-fixtures.json` status is `SPECIFICATION_ONLY_NOT_EVALUATED`; `tests/owner-print-acceptance.test.js` enforces the unchecked/0-of-3 state. This is not a claim that the delivered software is absent; it is a closure/acceptance semantic mismatch.", "",
          "- **Proposal:** keep #8/#9/#12 closed for their delivered implementation scopes, but add one explicit child issue under #13: “Owner-photo G01–G11 package acceptance (private evidence)” with owner-photo inputs unavailable publicly; or reopen them if the owner prefers the original ‘do not close until fixtures verify’ instruction. Do not silently edit closed evidence or rewrite historical comments.",
          "- **Files/branch:** cloud/owner doc reconciliation only (`docs/PRINT-PACKAGE-ACCEPTANCE.md`, ledger note, README/ROADMAP wording); no code branch. Local agent does not touch acceptance records.",
          "- **Acceptance:** owner confirms closure semantics; new child has explicit private evidence fields, G01–G11 statuses PASS/FAIL/NOT RUN, and does not claim physical/artist acceptance. #13 stays open.",
          "- **Confidence:** high on the documentary mismatch; medium on whether to reopen vs child (needs owner/cloud).", "",
          "### P2 — Windows portability reproduction and bounded fixes (local agent)", "",
          "**Why:** the Windows review at 3deeab8 left 14 failures, but their causes are mixed. Code-portable items: npm subprocess resolution; non-study vendor CRLF hashes; README newline counting. Host-sensitive items: TEMP ACL/access-denied writes during browser/page builds; symlink EPERM. No blanket “Windows broken” or “host-only” claim should be accepted without reproduction.", "",
          "- **Branch:** `fix/windows-portability-<new-issue>`; **files:** `src/import/*`, `scripts/*`, `.gitattributes` (scoped), `package.json` test wiring, `examples/reconstruction-study/requirements-test.txt`, `examples/reconstruction-study/package.py`, `tests/*`; no docs/ledger/issue edits.",
          "- **Acceptance:** each of the 14 has a minimal reproduction, a code-fix or documented host-sensitive cause, a regression test where portable, and a Windows rerun summary. Do not claim full Windows parity if host ACL/symlink constraints remain.",
          "- **Owner:** local agent (owner approval to start; no changes during audit).", "",
          "### P3 — Reconstruction test-requirements/archive follow-up (local/cloud; separate from #119 identities)", "",
          "- Make `examples/reconstruction-study/requirements-test.txt` self-contained: add `Pillow==12.3.0` and `reportlab==4.4.9` alongside `numpy==2.3.5` and `scipy==1.17.0`.",
          "- Add an explicit `.txt` inclusion rule (or named allowlist) so future self-testing archives include intended requirements files; do not rewrite the already delivered #119 evidence/archives.",
          "- **Owner/branch:** local agent if agreed; branch `chore/reconstruction-test-requirements`; file claim only above plus `tests/` for a requirements/archive test. Cloud reviews Linux CI.",
          "- **Acceptance:** fresh env can install requirements alone; archive includes intended txt; CI runs the four metric tests; no evidence hash changes.", "",
          "### P4 — Owner decisions on closure/split candidates (owner)", "",
          "| Issue(s) | Proposal | Owner decision needed |",
          "|---|---|---|",
          "| #8/#9/#12 | keep closed implementation + new #13 acceptance child (recommended) vs reopen | yes |",
          "| #34 | close as superseded by #47 + #13 after confirmation; keep future-family ideas in #47/research | yes |",
          "| #43 | close after confirmation; transfer physical/independent evidence to #13/#70 | yes |",
          "| #46 | close as superseded by #57; parked branch/artifacts historical only | yes |",
          "| #3/#4/#10/#28/#75 | remain parked/optional; owner may close as not-planned if cleanup is wanted | yes |",
          "| #113/#114 | remain proposed/deferred research; no implementation/version promise | yes |",
          "| #31/#57 | keep open; owner-directed design/identity decisions | yes |",
          "| #47 | keep open for family-wide suitability/physical/artist evidence | no (already open) |",
          "| #13/#14/#70/#109 | keep open; acceptance/notice/artist/Study 01 residual scopes | no |", "",
          "### P5 — Human/physical/artist evidence (owner; no agent fabrication)", "",
          "- Owner-photo G01–G11 private package acceptance; physical operator record per `docs/PHYSICAL-PRINT-CHECK.md`; human accessibility observations; independent artist trial per `docs/ARTIST-TRIAL.md`; final identity per #57 and style family decisions #47.",
          "- #13 and #70 remain open until these exist. Physical prints and independent artist trials are owner-deferred, not passed. Do not convert CI green into human acceptance.", "",
          "### P6 — Native notice gate (upstream; no agent action)", "",
          "- #14 stays open for the single attributable native Skia compiled-component notice inventory. The approved request is posted at https://github.com/samizdatco/skia-canvas/issues/309 and has no response/comments. Native bundle/executable/container distribution remains blocked; no refusal/permission framing.", "",
          "## 4. Cloud/local reconciliation", "",
          "**Cloud recommendation file: MISSING.** `stipra-complete-issue-audit-2026-10-20.md` was not found in Downloads, Documents, Desktop, Temp, DSH attachments, or the repository. No agreement/disagreement table can be truthfully completed without it. Template to fill after the file is supplied:", "",
          "| Cloud recommendation | Agree/Disagree/Needs-owner | Independent evidence | Proposed resolution |",
          "|---|---|---|---|",
          "| (file not supplied) | blocked | Coverage/rows above; acceptance mismatch on #8/#9/#12; optional/deferred dispositions; no Project #3 access | Provide cloud file; then fill row by row without weakening evidence/human gates |", "",
          "Known likely reconciliation topics where independent evidence is ready: closed #8/#9/#12 acceptance gap; #13 split; #34/#43/#46 closure candidates; #3/#4/#10/#28/#75 parked optional; #14 upstream open; #70 artist trial; #109 keep open/no rerun; requirements .txt follow-up. Do not accept a cloud recommendation that treats Linux CI as Windows acceptance or implementation closure as human/physical acceptance.", "",
          "## 5. Proposed work allocation and non-overlap", "",
          "| Owner | Work | Branch / file claim | Gate |",
          "|---|---|---|---|",
          "| Local agent | Windows reproduction/triage; bounded fixes; optional requirements/archive follow-up | `fix/windows-portability-<issue>` (`src/import/*`, `scripts/*`, `.gitattributes`, `package.json`, `tests/*`); `chore/reconstruction-test-requirements` (`examples/reconstruction-study/requirements-test.txt`, `package.py`, relevant test) | Owner/cloud agreement; no docs/issue/ledger edits; no merge |",
          "| Cloud agent | Independent Linux checks/patch review; one coordinated issue/ledger/README/roadmap/changelog/acceptance-record reconciliation | docs/metadata branch after agreement (`docs/data/*`, `docs/PRINT-PACKAGE-ACCEPTANCE.md`, `README.md`, `ROADMAP.md`); issue text/closure proposals only | Agreement/owner approval; no concurrent edit of local code branch; no evidence/archive rewrite |",
          "| Owner/human | Private G01–G11 acceptance, physical operator record, accessibility trial, independent artist trial, identity/style decisions, actual issue Status Done | private evidence only; issue administration | Real observations only; no fabricated fields/dates/percentages |", "",
          "Project automation note: status Done can close child issues; keep acceptance parent #13 and #14/#70/#109 open until their own criteria are met. Do not close #13 merely because implementation children are complete.", "",
          "## 6. Necessary owner questions", "",
          "1. **Where is `stipra-complete-issue-audit-2026-10-20.md`?** It was not found on this host; attach/paste it so the agreement table can be completed. Without it, cloud reconciliation is blocked.",
          "2. **Closure posture for #8/#9/#12:** keep closed implementation records plus one explicit #13 acceptance child (recommended), or reopen the closed issues?",
          "3. **Confirm owner closures/supersessions:** #34 (→#47), #43 (→#13/#70 for physical/artist), #46 (→#57), and whether #3/#4/#10/#28/#75 should be closed as not-planned or remain parked.",
          "4. **Authorize local Windows portability work** (after agreement) and the small requirements/archive follow-up; confirm no production-default/evidence changes. Do not ask for physical/artist dates or tests; those remain deferred.",
          "", "## 7. Paste-ready message for the cloud agent", "", "```text",
          "Independent Stiprā backlog audit completed against main d033ce7 (PR #119 merge; 55 issues: 17 open / 38 closed / 123 comments; 64 merged PRs; 0 open PRs). Read-only; no issue/PR mutations.",
          "Copied issue/PR links are live; no local paths required. The cloud recommendation file stipra-complete-issue-audit-2026-10-20.md was not accessible here, so reconciliation is blocked rather than invented.",
          "Independent key findings:",
          "1) #8/#9/#12 are closed, but docs/PRINT-PACKAGE-ACCEPTANCE.md remains NOT YET RUN, all G01-G11/A1-C5 boxes unchecked, 0 of 3 owner-photo packages, and tests/fixtures/owner-photo-fixtures.json says SPECIFICATION_ONLY_NOT_EVALUATED. Proposal: keep implementation closures if owner agrees, add one explicit #13 G01-G11 acceptance child (private evidence); otherwise reopen. Do not treat closure as acceptance.",
          "2) #13 is an acceptance parent and should stay open; split owner-photo G01-G11, human accessibility, physical operator record, and Windows portability. #70 remains the independent-artist track; do not conflate.",
          "3) The 14 Windows failures are mixed: npm subprocess resolution, non-study CRLF hashes, README newline counting are code-portable; TEMP ACL/access-denied and symlink EPERM are host-sensitive, not proven app defects. Repro is needed before fixes; no Linux-CI-as-Windows claim.",
          "4) #34/#43/#46 look like owner-closable/superseded items only after owner confirmation (#47 owns family acceptance, #57 owns identity, #13/#70 own physical/artist). #3/#4/#10/#28/#75 remain parked optional; #113/#114 proposed/deferred.",
          "5) #14 remains open for the one native Skia notice inventory; samizdatco/skia-canvas#309 is open with 0 comments, not a refusal. #109 stays open per owner: bounded Study 01 complete, no rerun/Experiment 2, Windows/human/physical residual.",
          "6) Small follow-up: pin Pillow==12.3.0 and reportlab==4.4.9 in examples/reconstruction-study/requirements-test.txt and include intended .txt requirements in future self-testing archives; do not rewrite #119 evidence/archives.",
          "Please provide your audit recommendations or confirm these dispositions; then we can agree closures/splits and a single docs/metadata reconciliation, while I take Windows portability and the local requirements branch. Proposed split: local agent Windows/code; cloud agent Linux review + one coordinated issue/ledger/README/roadmap/changelog reconciliation; owner/human only real private/physical/artist evidence. No merge/closure during this phase.",
          "```", "",
          "## 8. Report files", "",
          "- `audit-data/initial-findings.md` — full independent first pass (recorded before the cloud file was searched/read; cloud file absent).",
          "- `audit-data/backlog-raw.json` — complete API retrieval (issues, comments, PRs, milestone/label metadata).",
          "- `audit-data/issues-full.md` — every issue body and comment in readable form.",
          "- `audit-data/coverage.json` — retrieval/coverage counts.",
          "- `audit-data/final-handoff.md` — this handoff.",
          "", "**Limits:** no cloud file; no Project #3 access; no owner-photo/private evidence; no physical/human trials; no Windows rerun during audit; milestone API counters inconsistent with issue data; private artifact state unverified. Unavailable checks are marked, not passed.", ""]

(A / "audit-data/final-handoff.md").write_text("\n".join(lines), encoding="utf-8")
print("wrote final-handoff.md", len(lines), "lines")
